# script.module.cloudscraper

Venomous cloudscraper repacked for Kodi 18+.

Usage: 
```
from cloudscraper2 import CloudScraper
scraper = CloudScraper()
```

or

```
import cloudscraper2
scraper = cloudscraper2.create_scraper()
```





For more info see here: https://github.com/VeNoMouS/cloudscraper
