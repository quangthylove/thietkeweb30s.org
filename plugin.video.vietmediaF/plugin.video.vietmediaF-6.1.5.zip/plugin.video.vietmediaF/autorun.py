# -*- coding: utf-8 -*-

import xbmc, xbmcaddon

addon = xbmcaddon.Addon(id='plugin.video.vietmediaF')

on_off = addon.getSetting('on_off')

if on_off == 'false':				
    xbmc.executebuiltin("RunAddon(plugin.video.vietmediaF)")