﻿#!/usr/bin/python
#coding=utf-8
import requests
import re
import time
import json
requests.packages.urllib3.disable_warnings()
from xbmcswift2 import Plugin, xbmc, xbmcgui, xbmcaddon
import hashlib

plugin = Plugin()
pluginrootpath = "plugin://plugin.video.thietkeweb30s.sctv"

headers = {
	"X-Requested-With": "XMLHttpRequest",
	"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Safari/537.36",
	"Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
	"Accept-Encoding": "gzip, deflate"
}


@plugin.route('/')
def Home():
	items = [
		{'label': '[COLOR yellow]SCTV HD - Phim Tổng Hợp[/COLOR]', 'path': 'plugin://plugin.video.thietkeweb30s.sctv/play/108', 'thumbnail': 'https://static-stage.tv24.vn/channel/108/PhimTongHopSD.png', 'is_playable': True},
		{'label': '[COLOR yellow]SCTV 1 HD - Hài[/COLOR]', 'path': 'plugin://plugin.video.thietkeweb30s.sctv/play/85', 'thumbnail': 'https://static-stage.tv24.vn/channel/85/s1-hd-kbg.png', 'is_playable': True},
		{'label': '[COLOR yellow]SCTV 2 HD - Yan TV[/COLOR]', 'path': 'plugin://plugin.video.thietkeweb30s.sctv/play/2', 'thumbnail': 'https://static-stage.tv24.vn/channel/2/s2-hd-kbg.png', 'is_playable': True},
		{'label': '[COLOR yellow]SCTV 3 HD - SEE TV[/COLOR]', 'path': 'plugin://plugin.video.thietkeweb30s.sctv/play/112', 'thumbnail': 'https://static-stage.tv24.vn/channel/112/s3-hd-kbg.png', 'is_playable': True},
		{'label': '[COLOR yellow]SCTV 4 HD - Giải trí tổng hợp[/COLOR]', 'path': 'plugin://plugin.video.thietkeweb30s.sctv/play/109', 'thumbnail': 'https://static-stage.tv24.vn/channel/109/s4-hd-kbg.png', 'is_playable': True},
		{'label': '[COLOR yellow]SCTV 6 HD[/COLOR]', 'path': 'plugin://plugin.video.thietkeweb30s.sctv/play/16', 'thumbnail': 'https://static-stage.tv24.vn/channel/16/s6-hd-kbg.png', 'is_playable': True},
		{'label': '[COLOR yellow]SCTV 7 HD - Sân Khấu[/COLOR]', 'path': 'plugin://plugin.video.thietkeweb30s.sctv/play/107', 'thumbnail': 'https://static-stage.tv24.vn/channel/107/s7-hd-kbg.png', 'is_playable': True},
		{'label': '[COLOR yellow]SCTV 9 HD - Phim Châu Á[/COLOR]', 'path': 'plugin://plugin.video.thietkeweb30s.sctv/play/129', 'thumbnail': 'https://static-stage.tv24.vn/channel/129/s9-hd-kbg.png', 'is_playable': True},
		{'label': '[COLOR yellow]SCTV 11 HD[/COLOR]', 'path': 'plugin://plugin.video.thietkeweb30s.sctv/play/130', 'thumbnail': 'https://static-stage.tv24.vn/channel/130/s11-hd-kbg.png', 'is_playable': True},
		{'label': '[COLOR yellow]SCTV 12 HD - Du Lịch[/COLOR]', 'path': 'plugin://plugin.video.thietkeweb30s.sctv/play/17', 'thumbnail': 'https://static-stage.tv24.vn/channel/17/s12-hd-kbg.png', 'is_playable': True},
		{'label': '[COLOR yellow]SCTV 13 HD - Phụ nữ & Gia đình[/COLOR]', 'path': 'plugin://plugin.video.thietkeweb30s.sctv/play/114', 'thumbnail': 'https://static-stage.tv24.vn/channel/114/s13-hd-kbg.png', 'is_playable': True},
		{'label': '[COLOR yellow]SCTV 14 HD - Phim Việt[/COLOR]', 'path': 'plugin://plugin.video.thietkeweb30s.sctv/play/84', 'thumbnail': 'https://static-stage.tv24.vn/channel/84/s14-hd-kbg.png', 'is_playable': True},
		{'label': '[COLOR yellow]SCTV 15 HD - Thể Thao[/COLOR]', 'path': 'plugin://plugin.video.thietkeweb30s.sctv/play/22', 'thumbnail': 'https://static-stage.tv24.vn/channel/22/s15-hd-kbg.png', 'is_playable': True},
		{'label': '[COLOR yellow]SCTV 16 HD - Phim nước ngoài đặc sắc[/COLOR]', 'path': 'plugin://plugin.video.thietkeweb30s.sctv/play/110', 'thumbnail': 'https://static-stage.tv24.vn/channel/110/s16-hd-kbg.png', 'is_playable': True},
		{'label': '[COLOR yellow]VTV1 HD[/COLOR]', 'path': 'plugin://plugin.video.thietkeweb30s.sctv/play/41', 'thumbnail': 'https://static-stage.tv24.vn/channel/41/vtv11.png', 'is_playable': True},
		{'label': 'ANTV', 'path': 'plugin://plugin.video.thietkeweb30s.sctv/play/31', 'thumbnail': 'https://static-stage.tv24.vn/channel/31/antv.png', 'is_playable': True},
		{'label': 'BTV3', 'path': 'plugin://plugin.video.thietkeweb30s.sctv/play/120', 'thumbnail': 'https://static-stage.tv24.vn/channel/120/btv3-1.png', 'is_playable': True},
		{'label': 'BTV5 HD', 'path': 'plugin://plugin.video.thietkeweb30s.sctv/play/119', 'thumbnail': 'https://static-stage.tv24.vn/channel/119/BTV5.png', 'is_playable': True},
		{'label': 'DW', 'path': 'plugin://plugin.video.thietkeweb30s.sctv/play/159', 'thumbnail': 'https://static-stage.tv24.vn/channel/159/DW(deutschewelle).png', 'is_playable': True},
		{'label': 'Quốc Hội Việt Nam', 'path': 'plugin://plugin.video.thietkeweb30s.sctv/play/123', 'thumbnail': 'https://static-stage.tv24.vn/channel/123/QuocHoi.png', 'is_playable': True},
		{'label': 'Quốc Phòng Việt Nam', 'path': 'plugin://plugin.video.thietkeweb30s.sctv/play/140', 'thumbnail': 'https://static-stage.tv24.vn/channel/140/QPVN_kobg.png', 'is_playable': True},
		{'label': 'SCTV 1 - Hài', 'path': 'plugin://plugin.video.thietkeweb30s.sctv/play/7', 'thumbnail': 'https://static-stage.tv24.vn/channel/7/s1.png', 'is_playable': True},
		{'label': 'SCTV 3 - SEE TV', 'path': 'plugin://plugin.video.thietkeweb30s.sctv/play/10', 'thumbnail': 'https://static-stage.tv24.vn/channel/10/s3.png', 'is_playable': True},
		{'label': 'SCTV 4 - Giải trí tổng hợp', 'path': 'plugin://plugin.video.thietkeweb30s.sctv/play/9', 'thumbnail': 'https://static-stage.tv24.vn/channel/9/s4.png', 'is_playable': True},
		{'label': 'SCTV 5', 'path': 'plugin://plugin.video.thietkeweb30s.sctv/play/11', 'thumbnail': 'https://static-stage.tv24.vn/channel/11/s5.png', 'is_playable': True},
		{'label': 'SCTV 7 - Sân Khấu', 'path': 'plugin://plugin.video.thietkeweb30s.sctv/play/13', 'thumbnail': 'https://static-stage.tv24.vn/channel/13/s7.png', 'is_playable': True},
		{'label': 'SCTV 9 - Phim Châu Á', 'path': 'plugin://plugin.video.thietkeweb30s.sctv/play/8', 'thumbnail': 'https://static-stage.tv24.vn/channel/8/s9.png', 'is_playable': True},
		{'label': 'SCTV 10', 'path': 'plugin://plugin.video.thietkeweb30s.sctv/play/115', 'thumbnail': 'https://static-stage.tv24.vn/channel/115/s10.png', 'is_playable': True},
		{'label': 'SCTV 11', 'path': 'plugin://plugin.video.thietkeweb30s.sctv/play/106', 'thumbnail': 'https://static-stage.tv24.vn/channel/106/s11.png', 'is_playable': True},
		{'label': 'SCTV 12 - Du Lịch', 'path': 'plugin://plugin.video.thietkeweb30s.sctv/play/103', 'thumbnail': 'https://static-stage.tv24.vn/channel/103/S12.png', 'is_playable': True},
		{'label': 'SCTV 13 - Phụ nữ & Gia đình', 'path': 'plugin://plugin.video.thietkeweb30s.sctv/play/18', 'thumbnail': 'https://static-stage.tv24.vn/channel/18/s13.png', 'is_playable': True},
		{'label': 'SCTV 14 - Phim Việt', 'path': 'plugin://plugin.video.thietkeweb30s.sctv/play/19', 'thumbnail': 'https://static-stage.tv24.vn/channel/19/s14.png', 'is_playable': True},
		{'label': 'SCTV 15 - Thể Thao', 'path': 'plugin://plugin.video.thietkeweb30s.sctv/play/20', 'thumbnail': 'https://static-stage.tv24.vn/channel/20/s15.png', 'is_playable': True},
		{'label': 'SCTV 16 - Phim nước ngoài đặc sắc', 'path': 'plugin://plugin.video.thietkeweb30s.sctv/play/21', 'thumbnail': 'https://static-stage.tv24.vn/channel/21/s16.png', 'is_playable': True},
		{'label': 'SCTV 17', 'path': 'plugin://plugin.video.thietkeweb30s.sctv/play/14', 'thumbnail': 'https://static-stage.tv24.vn/channel/14/s17.png', 'is_playable': True},
		{'label': 'SCTV 18', 'path': 'plugin://plugin.video.thietkeweb30s.sctv/play/164', 'thumbnail': 'https://static-stage.tv24.vn/channel/164/s18.png', 'is_playable': True},
		{'label': 'SCTV Phim Tổng Hợp', 'path': 'plugin://plugin.video.thietkeweb30s.sctv/play/4', 'thumbnail': 'https://static-stage.tv24.vn/channel/4/PhimTongHopSD.png', 'is_playable': True},
		{'label': 'TH AN GIANG', 'path': 'plugin://plugin.video.thietkeweb30s.sctv/play/141', 'thumbnail': 'https://static-stage.tv24.vn/channel/141/ATVangiang.png', 'is_playable': True},
		{'label': 'TH Bến Tre', 'path': 'plugin://plugin.video.thietkeweb30s.sctv/play/143', 'thumbnail': 'https://static-stage.tv24.vn/channel/143/THBTbentre.png', 'is_playable': True},
		{'label': 'TH Hậu Giang', 'path': 'plugin://plugin.video.thietkeweb30s.sctv/play/148', 'thumbnail': 'https://static-stage.tv24.vn/channel/148/HGTVhaugiang.png', 'is_playable': True},
		{'label': 'TH Nhân Dân', 'path': 'plugin://plugin.video.thietkeweb30s.sctv/play/204', 'thumbnail': 'https://static-stage.tv24.vn/channel/204/NhanDan.png', 'is_playable': True},
		{'label': 'Th Ninh Thuận', 'path': 'plugin://plugin.video.thietkeweb30s.sctv/play/151', 'thumbnail': 'https://static-stage.tv24.vn/channel/151/NTVninhthuan.png', 'is_playable': True},
		{'label': 'TH VĨNH LONG 1 - THVL1', 'path': 'plugin://plugin.video.thietkeweb30s.sctv/play/62', 'thumbnail': 'https://static-stage.tv24.vn/channel/62/THVL1_kobg.png', 'is_playable': True},
		{'label': 'TH VĨNH LONG 2 - THVL2', 'path': 'plugin://plugin.video.thietkeweb30s.sctv/play/124', 'thumbnail': 'https://static-stage.tv24.vn/channel/124/THVL2_kobg.png', 'is_playable': True},
		{'label': 'TH Đồng Tháp', 'path': 'plugin://plugin.video.thietkeweb30s.sctv/play/147', 'thumbnail': 'https://static-stage.tv24.vn/channel/147/THDTdongthap.png', 'is_playable': True},
		{'label': 'TTXVN', 'path': 'plugin://plugin.video.thietkeweb30s.sctv/play/122', 'thumbnail': 'https://static-stage.tv24.vn/channel/122/TTXVn.png', 'is_playable': True},
		{'label': 'TV BLUE - VTC 5', 'path': 'plugin://plugin.video.thietkeweb30s.sctv/play/135', 'thumbnail': 'https://static-stage.tv24.vn/channel/135/vtc5.png', 'is_playable': True},
		{'label': 'TV5 Monde', 'path': 'plugin://plugin.video.thietkeweb30s.sctv/play/162', 'thumbnail': 'https://static-stage.tv24.vn/channel/162/tv5(monde).png', 'is_playable': True},
		{'label': 'VTC1', 'path': 'plugin://plugin.video.thietkeweb30s.sctv/play/156', 'thumbnail': 'https://static-stage.tv24.vn/channel/156/vtc1.png', 'is_playable': True},
		{'label': 'VTC10', 'path': 'plugin://plugin.video.thietkeweb30s.sctv/play/153', 'thumbnail': 'https://static-stage.tv24.vn/channel/153/vtc10.png', 'is_playable': True}

	]
	if plugin.get_setting('thumbview', bool):
		if xbmc.getSkinDir() in ('skin.confluence', 'skin.eminence'):
			return plugin.finish(items, view_mode=500)
		elif xbmc.getSkinDir() == 'skin.xeebo':
			return plugin.finish(items, view_mode=52)
		else:
			return plugin.finish(items)
	else:
		return plugin.finish(items)


def LogIn(phone, passw):
	try:
		headers = {
			"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Safari/537.36",
			"Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
			"Accept-Encoding": "gzip, deflate, sdch, br"
		}
		payloads = "mobile=%s&password=%s" % (phone, passw)
		sess = requests.Session()
		sess.headers.update(headers)
		resp = sess.post("https://tv24.vn/client/authentication/loginProcess",
		                 data=payloads, verify=False).json()
		if resp["result"] == "-1":
			return None, None
		user_name = "Thietkeweb30s.org"
		return user_name, sess
	except:
		return None, None


def getTV24Link(cid, sess):
	try:
		mes = 'Không lấy được kênh %s từ TV24.VN!' % cid
		resp = sess.get(
			"https://tv24.vn/kenh-truyen-hinh/%s/-" % cid,
			verify=False
		)
		payloads = {
			"channel_id": cid
		}
		resp = sess.post(
			"https://tv24.vn/client/channel/link",
			data=payloads,
			verify=False
		)
		res_json = resp.json()
		mes = res_json["message"]
		play_url = res_json["data"]["PLAY_URL"]
		# time.sleep(2)
		try:
			resp = sess.get(
				play_url,
				verify=False
			)
			match = re.compile("(chunklist.+?m3u8)").findall(resp.text)
			tmp_url = play_url.split("playlist")[0] + match[2]
			code = requests.head(tmp_url, verify=False).status_code
			if code == 404:
				raise Exception()
			return tmp_url
		except:
			pass
		return play_url
	except:
		header = "Get link thất bại!!!"
		message = mes.encode("utf-8")
		xbmc.executebuiltin('Notification("%s", "%s", "%d", "%s")' %
		                    (header, message, 10000, ''))
		return ""


def dec(key, b64_encrypted_str):
	b64_encrypted_str = b64_encrypted_str.decode("base64")
	j = 0
	x = ""
	out = ""
	s = [i for i in range(0, 256)]
	for i in range(0, 256):
		j = (j + s[i] + ord(key[i % len(key)])) % 256
		x = s[i]
		s[i] = s[j]
		s[j] = x
	i = 0
	j = 0
	for k in range(0, len(b64_encrypted_str)):
		i = (i + 1) % 256
		j = (j + s[i]) % 256
		x = s[i]
		s[i] = s[j]
		s[j] = x
		out += chr(ord(b64_encrypted_str[k]) ^ s[(s[i] + s[j]) % 256])
	return out


@plugin.route('/play/<cid>', name="play_with_local_acc")
@plugin.route('/play/<cid>/<phone>/<passw>')
def play(cid, phone="", passw=""):
	if phone == "":
		phone = plugin.get_setting('usernamesctv')
	if passw == "":
		passw = plugin.get_setting('passwordsctv')
		# hash_object = hashlib.md5(passw)
		# passw = hash_object.hexdigest()
	user_name, sess = LogIn(phone, passw)
	if user_name is not None:
		dialogWait = xbmcgui.DialogProgress()
		dialogWait.create(
			'SCTV (tv24.vn)', 'Chào [COLOR orange]%s[/COLOR]. Đang mở kênh %s. Vui lòng đợi trong giây lát...' % (user_name.encode("utf8"), cid))
		plugin.set_resolved_url(get_playable_url(cid, sess))
		dialogWait.close()
		del dialogWait
	else:
		dialog = xbmcgui.Dialog()
		yes = dialog.yesno(
			'Đăng nhập không thành công!\n',
			'Chưa có tài khoản? Đăng ký tại [COLOR lime]tv24.vn/dang-ky[/COLOR].\n[COLOR yellow]Bạn muốn nhập tài khoản bây giờ không?[/COLOR]',
			yeslabel='OK, nhập ngay',
			nolabel='Nhập sau!'
		)
		if yes:
			plugin.open_settings()
			play(cid)


def get_playable_url(cid, sess):
	return getTV24Link(cid, sess)


if __name__ == '__main__':
	plugin.run()
