#!/usr/bin/python
#coding=utf-8

import xbmc, xbmcaddon

addon = xbmcaddon.Addon(id='plugin.video.thietkeweb30s.org.IPTVShare')

if addon.getSetting('autostart') == 'true':
	xbmc.executebuiltin("RunAddon(plugin.video.thietkeweb30s.org.IPTVShare)")