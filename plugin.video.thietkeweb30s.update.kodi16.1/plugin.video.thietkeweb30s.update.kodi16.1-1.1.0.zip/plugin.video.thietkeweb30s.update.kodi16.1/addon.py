﻿import re;import os;import sys;import time;import ntpath;import base64;import shutil;import zipfile;import hashlib;import platform;import urllib;import urllib2;import xbmc;import xbmcgui;import xbmcaddon;import xbmcplugin

ADDON_NAME   = xbmcaddon.Addon('plugin.video.thietkeweb30s.update.kodi16.1')

USER_AGENT   = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.73 Safari/537.36 ReplicantWizard/1.0.0'

def unzip(_in, _out, progress):
	__in = zipfile.ZipFile(_in,  'r')
	
	nofiles = float(len(__in.infolist()))
	count   = 0
	
	try:
		for item in __in.infolist():
			count += 1
			update = (count / nofiles) * 100
			
			if progress.iscanceled():
				dialog = xbmcgui.Dialog()
				dialog.ok('MEDIACENTER', 'Trích xuất đã bị hủy.')
				
				sys.exit()
				progress.close()
				
			progress.update(int(update))
			__in.extract(item, _out)
			
	except Exception, e:
		return False
		
	return True
	
def download(url, destination, progress):
	progress.update(0)
	urllib.urlretrieve(url, destination, lambda numblocks, blocksize, filesize, url=url: hook(numblocks, blocksize, filesize, url, progress))
	
def hook(numblocks, blocksize, filesize, url, progress):
	try:
		percent = min((numblocks * blocksize * 100) / filesize, 100)
		progress.update(percent)
		
	except:
		percent = 100
		progress.update(percent)
		
	if progress.iscanceled():
		dialog = xbmcgui.Dialog()
		dialog.ok('MEDIACENTER', 'Quá trình tải bản cập nhật đã bị hủy.')
		
		sys.exit()
		progress.close()

		
def categories():

	choice = xbmcgui.Dialog().yesno('MEDIACENTER', 'Bản cập nhật mới nhất cho KODI HUEHDPLUS\n(Version 16.1 - Build 17/07/2017) Với nhiều cải tiến mới, nâng cao trải nghiệm người dùng, ổn định và dễ sử dụng hơn so với phiên bản cũ. Nhấn "OK" để tiếp tục.', yeslabel='OK', nolabel='Thoát')

	if (choice == 0):
		sys.exit()
	elif (choice == 1):
		pass

	link  = openUrl('https://dl.dropboxusercontent.com/s/54cmkerbfiatfv9/checkupdate16.1.txt').replace('\n', '').replace('\r', '')
	match = re.compile('name="(.+?)".+?rl="(.+?)".+?mb="(.+?)"').findall(link)
	
	for name, url, thumb in match:
		addDir(name, url, 1, thumb, '', '')
		
	setView('movies', 'MAIN')
	
def openUrl(url):
	request  = urllib2.Request(url)
	request.add_header('User-Agent', USER_AGENT)
	
	response = urllib2.urlopen(request)
	link = response.read()
	
	response.close()
	return link
	
def runAddon(name, url, desc):
	root   = xbmc.translatePath(os.path.join('special://', 'home'))
	dialog = xbmcgui.Dialog()
	
	progress = xbmcgui.DialogProgress()
	progress.create('MEDIACENTER', 'Đang tải bản cập nhật...')
	
	path = xbmc.translatePath(os.path.join('special://home/addons', 'packages'))
	archive = os.path.join(path, name + '.zip')
	
	try:
		os.remove(archive)
	except:
		pass
		
	download(url, archive, progress)
	time.sleep(2)
	
	progress.update(0, 'Đang trích xuất dữ liệu...')
	
	unzip(archive, root, progress)
	time.sleep(2)
	
	killXbmc()

def killXbmc():
	dialog = xbmcgui.Dialog()
	dialog.ok('MEDIACENTER', 'Quá trình cập nhật đã thành công.')
	
	choice = xbmcgui.Dialog().yesno('MEDIACENTER', 'Để nhận được những thay đổi mới nhất vui lòng tắt nguồn và khởi động lại thiết bị của bạn. Bạn có chắc chắn điều này?', yeslabel='Có', nolabel='Không')
	
	if (choice == 0):
		return
	elif (choice == 1):
		pass
		
	platform = queryPlatform()

	if (platform == 'Android'):
		try:os.system('adb shell am force-stop org.xbmc.kodi')
		except:pass
		try:os.system('adb shell am force-stop org.kodi')
		except:pass
		try:os.system('adb shell am force-stop org.xbmc.xbmc')
		except:pass
		try:os.system('adb shell am force-stop org.xbmc')
		except:pass
	
	elif (platform == 'OSX'):
		try:os.system('killall -9 XBMC')
		except:pass
		try:os.system('killall -9 Kodi')
		except:pass

	elif (platform == 'AppleTV'):
		try:os.system('killall AppleTV')
		except:pass
		try:os.system('sudo initctl stop kodi')
		except:pass
		try:os.system('sudo initctl stop xbmc')
		except:pass

	elif (platform == 'Linux'):
		try:os.system('killall XBMC')
		except:pass
		try:os.system('killall Kodi')
		except:pass
		try:os.system('killall -9 xbmc.bin')
		except:pass
		try:os.system('killall -9 kodi.bin')
		except:pass

	elif (platform == 'Windows'):
		try:
			os.system('@ECHO off')
			os.system('tskill XBMC.exe')
		except:
			pass
			
		try:
			os.system('@ECHO off')
			os.system('tskill Kodi.exe')
		except:
			pass
			
		try:
			os.system('@ECHO off')
			os.system('TASKKILL /im XBMC.exe /f')
		except:
			pass
			
		try:
			os.system('@ECHO off')
			os.system('TASKKILL /im Kodi.exe /f')
		except:
			pass
	else:
		dialog.ok('The Spartan Wizard', 'Please pull the power cable from your device.')
		
def queryPlatform():
	if (xbmc.getCondVisibility('system.platform.android')):
		return 'Android'
	elif (xbmc.getCondVisibility('system.platform.osx')):
		return 'OSX'
	elif (xbmc.getCondVisibility('system.platform.atv2')):
		return 'AppleTV'
	elif (xbmc.getCondVisibility('system.platform.linux')):
		return 'Linux'
	elif (xbmc.getCondVisibility('system.platform.windows')):
		return 'Windows'
	else:
		return 'Other'
		
def addDir(name, url, mode, icon, fanart, desc):
	__url = sys.argv[0] + "?url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.quote_plus(name) + "&icon=" + urllib.quote_plus(icon) + "&fanart=" + urllib.quote_plus(fanart) + "&desc=" + urllib.quote_plus(desc)
	__listitem = xbmcgui.ListItem(name, iconImage='DefaultFolder.png', thumbnailImage=icon)
	__listitem.setInfo(type='Video', infoLabels={ 'Title': name, 'Plot': desc })
	__listitem.setProperty('Fanart_Image', fanart)
	item = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=__url, listitem=__listitem, isFolder=False)
	return item
	
def getParams():
	param  = []
	string = sys.argv[2]
	
	if (len(string) >= 2):
		params = sys.argv[2]
		clean  = params.replace('?', '')
		
		if (params[len(params) -1] == '/'):
			params = params[0:len(params) -2]
			
		pairs = clean.split('&')
		param = {}
		
		for i in range(len(pairs)):
			split = {}
			split = pairs[i].split('=')
			
			if (len(split) == 2):
				param[split[0]] = split[1]
				
	return param
	
url  = None
name = None
mode = None
icon = None
fanart = None
desc = None

params = getParams()

try:
	url  = urllib.unquote_plus(params['url'])
except:
	pass
	
try:
	name = urllib.unquote_plus(params['name'])
except:
	pass
	
try:
	mode = int(params['mode'])
except:
	pass
	
try:
	icon = urllib.unquote_plus(params['icon'])
except:
	pass
	
try:
	fanart = urllib.unquote_plus(params['fanart'])
except:
	pass
	
try:
	desc = urllib.unquote_plus(params['desc'])
except:
	pass
	
def setView(content, viewType):
	if (content):
		xbmcplugin.setContent(int(sys.argv[1]), content)
		
	if (ADDON_NAME.getSetting('auto-view') == 'true'):
		xbmc.executebuiltin('Container.SetViewMode(%s)' % ADDON_NAME.getSetting(viewType))
		
if ((mode == None) or (url == None) or len(url) < 1):
	categories()
elif (mode == 1):
	runAddon(name, url, desc)
	
xbmcplugin.endOfDirectory(int(sys.argv[1]))