﻿#!/usr/bin/python
#coding=utf-8
import urllib , requests , re , json , HTMLParser , os , uuid
from xbmcswift2 import Plugin , xbmc , xbmcgui , xbmcaddon
requests . packages . urllib3 . disable_warnings ( )
oo000 = Plugin ( )
ii = HTMLParser . HTMLParser ( )
oOOo = "plugin://plugin.video.4vn.fptplay"
if 59 - 59: Oo0Ooo . OO0OO0O0O0 * iiiIIii1IIi . iII111iiiii11 % I1IiiI
IIi1IiiiI1Ii = "https://fptplay.net/show/getlinklivetv"
I11i11Ii = "https://fptplay.net/tro-giup/bao-loi"
oO00oOo = "https://fptplay.net/show/getlink"
OOOo0 = 30
if 54 - 54: i1 - o0 * i1oOo0OoO * iIIIiiIIiiiIi % Oo
o0O = {
 "User-Agent" : "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.99 Safari/537.36" ,
 "Content-Type" : "application/x-www-form-urlencoded; charset=UTF-8" ,
 "Accept" : "application/json, text/javascript, */*; q=0.01" ,
 "X-Requested-With" : "XMLHttpRequest" ,
 "Referer" : "https://fptplay.net/livetv" ,
 "Accept-Encoding" : "gzip, deflate"
 }
if 48 - 48: iII111i % IiII + I1Ii111 / ooOoO0o * o00O0oo
def O0oOO0o0 ( items ) :
 i1ii1iIII = set ( )
 Oo0oO0oo0oO00 = [ ]
 for i111I in items :
  II1Ii1iI1i = tuple ( i111I . items ( ) )
  if II1Ii1iI1i not in i1ii1iIII :
   i1ii1iIII . add ( II1Ii1iI1i )
   Oo0oO0oo0oO00 . append ( i111I )
 return Oo0oO0oo0oO00
 if 12 - 12: o0oOoO00o
def i1oOOoo00O0O ( s ) :
 s = '' . join ( s . splitlines ( ) ) . replace ( '\'' , '"' )
 s = s . replace ( '\n' , '' )
 s = s . replace ( '\t' , '' )
 s = re . sub ( '  +' , ' ' , s )
 s = s . replace ( '> <' , '><' )
 return ii . unescape ( s )
 if 15 - 15: I11iii11IIi
@ oo000 . route ( '/eps/<sid>' )
def O00o0o0000o0o ( sid ) :
 O0Oo ( "Browse eps by id %s" % sid , "/eps/%s" % sid )
 oo = requests . get ( "https://fptplay.net/xem-video/-%s.html" % sid , headers = o0O )
 oo . encoding = "utf-8"
 IiII1I1i1i1ii = i1oOOoo00O0O ( oo . text ) . encode ( "utf8" )
 IIIII = 1
 I1 = re . compile ( 'Số tập\: </span>(\d+) tập</p>' ) . findall ( IiII1I1i1i1ii )
 O0OoOoo00o = [ ]
 if len ( I1 ) > 0 :
  IIIII = int ( I1 [ 0 ] )
 iiiI11 = re . compile ( '<title>FPT Play - Xem video (.+?)</title>' ) . findall ( IiII1I1i1i1ii ) [ 0 ]
 if IIIII == 1 :
  OOooO = { }
  OOooO [ "label" ] = "Xem %s" % iiiI11
  OOooO [ "path" ] = "%s/play/%s/%s" % ( oOOo , sid , "1" )
  OOooO [ "is_playable" ] = True
  O0OoOoo00o . append ( OOooO )
 else :
  for OOoO00o in range ( 1 , IIIII + 1 ) :
   OOooO = { }
   OOooO [ "label" ] = "Xem %s - Tập %s" % ( iiiI11 , OOoO00o )
   OOooO [ "path" ] = "%s/play/%s/%s" % ( oOOo , sid , OOoO00o )
   OOooO [ "is_playable" ] = True
   O0OoOoo00o . append ( OOooO )
 return oo000 . finish ( O0OoOoo00o )
 if 9 - 9: I1iiiiI1iII - oOo0 / i1Ii % I1IiiI
@ oo000 . route ( '/list/<order>/<s_id>/<page>' )
def list ( order = "new" , s_id = "" , page = "1" ) :
 O0Oo ( "Browse new videos by id %s" % s_id , "/list/%s/%s/%s" % ( order , s_id , page ) )
 o00O00O0O0O = requests . Session ( )
 OooO0OO = {
 'type' : order ,
 'stucture_id' : s_id ,
 'page' : page ,
 'keyword' : 'undefined'
 }
 oo = o00O00O0O0O . post ( "https://fptplay.net/show/more" , headers = o0O , data = OooO0OO )
 oo . encoding = "utf-8"
 IiII1I1i1i1ii = i1oOOoo00O0O ( oo . text ) . encode ( "utf8" )
 I1 = re . compile ( '<a href=".+?-(\w+).html" ><img[^>]*src="(.+?)"[^>]*alt="(.+?)"' ) . findall ( IiII1I1i1i1ii )
 O0OoOoo00o = [ ]
 for iiiIi , IiIIIiI1I1 , iiiI11 in I1 :
  OOooO = { }
  OOooO [ "label" ] = iiiI11
  OOooO [ "path" ] = "%s/eps/%s" % ( oOOo , iiiIi )
  OOooO [ "thumbnail" ] = IiIIIiI1I1
  O0OoOoo00o . append ( OOooO )
 if len ( O0OoOoo00o ) == OOOo0 :
  OOooO = { }
  OOooO [ "label" ] = "Next >>"
  OOooO [ "path" ] = "%s/list/%s/%s/%s" % ( oOOo , order , s_id , int ( page ) + 1 )
  OOooO [ "thumbnail" ] = "http://icons.iconarchive.com/icons/rafiqul-hassan/blogger/128/Arrow-Next-icon.png"
  O0OoOoo00o . append ( OOooO )
 if oo000 . get_setting ( 'thumbview' , bool ) :
  if xbmc . getSkinDir ( ) in ( 'skin.confluence' , 'skin.eminence' ) :
   return oo000 . finish ( O0OoOoo00o , view_mode = 500 )
  elif xbmc . getSkinDir ( ) == 'skin.xeebo' :
   return oo000 . finish ( O0OoOoo00o , view_mode = 52 )
  else :
   return oo000 . finish ( O0OoOoo00o )
 else :
  return oo000 . finish ( O0OoOoo00o )
  if 86 - 86: Oo0Ooo + o0oOoO00o + i1Ii * o00O0oo + iII111i
@ oo000 . route ( '/live' )
def oOoO ( ) :
 O0Oo ( "Browse Live Channels" , "/live" )
 oOo = "https://fptplay.net/livetv"
 o00O00O0O0O = requests . Session ( )
 OooO0OO = {
 'country_code' : oo000 . get_setting ( 'code' ) ,
 'phone' : oo000 . get_setting ( 'phone' ) ,
 'password' : oo000 . get_setting ( 'passw' ) ,
 'submit' : ''
 }
 o00O00O0O0O . post (
 "https://fptplay.net/user/login" ,
 headers = o0O ,
 data = OooO0OO
 )
 oo = o00O00O0O0O . get ( oOo , headers = o0O )
 oo . encoding = "utf-8"
 IiII1I1i1i1ii = i1oOOoo00O0O ( oo . text )
 I1 = re . compile ( 'onclick="getLivetv\(\$\(this\)\)" data-href="(.+?)"[^>]*>(.*?)<img class="lazy" data-original="(.+?)"[^>]*title="(.+?)"' ) . findall ( IiII1I1i1i1ii )
 O0OoOoo00o = [ ]
 for IIi1IiiiI1Ii , oOoOoO , IiIIIiI1I1 , iiiI11 in I1 :
  if "livetv_lock" not in oOoOoO :
   OOooO = { }
   OOooO [ "label" ] = iiiI11
   OOooO [ "path" ] = "%s/play/%s" % ( oOOo , urllib . quote_plus ( IIi1IiiiI1Ii . encode ( "utf8" ) ) )
   OOooO [ "is_playable" ] = True
   OOooO [ "thumbnail" ] = IiIIIiI1I1
   O0OoOoo00o . append ( OOooO )
 O0OoOoo00o = O0oOO0o0 ( O0OoOoo00o )
 if oo000 . get_setting ( 'thumbview' , bool ) :
  if xbmc . getSkinDir ( ) in ( 'skin.confluence' , 'skin.eminence' ) :
   return oo000 . finish ( O0OoOoo00o , view_mode = 500 )
  elif xbmc . getSkinDir ( ) == 'skin.xeebo' :
   return oo000 . finish ( O0OoOoo00o , view_mode = 52 )
  else :
   return oo000 . finish ( O0OoOoo00o )
 else :
  return oo000 . finish ( O0OoOoo00o )
  if 6 - 6: o0 / i1oOo0OoO % o0oOoO00o
@ oo000 . route ( '/play/<url>' , name = "play_firsteps" )
@ oo000 . route ( '/play/<url>/<eps>' )
def ooOO0O00 ( url , eps = "1" ) :
 O0Oo ( "Play %s" % url , "/play/%s/%s" % ( url , eps ) )
 ii1 = xbmcgui . DialogProgress ( )
 ii1 . create ( 'Thietkeweb30s.org - FPTPlay.net' , 'Loading video. Please wait...' )
 o0oO0o00oo = "|User-Agent=Mozilla%2F5.0%20%28Windows%20NT%2010.0%3B%20Win64%3B%20x64%29%20AppleWebKit%2F537.36%20%28KHTML%2C%20like%20Gecko%29%20Chrome%2F53.0.2785.143%20Safari%2F537.36&Referer=https%3A%2F%2Ffptplay.net%2Flivetv%2F"
 oo000 . set_resolved_url ( II1i1Ii11Ii11 ( url , eps ) + o0oO0o00oo , subtitles = "https://dl.dropboxusercontent.com/s/oa2yn7vqgfrmpb1/advertisement.srt" )
 ii1 . close ( )
 del ii1
 if 35 - 35: iII111i + I11iii11IIi + I11iii11IIi
def II1i1Ii11Ii11 ( url , ep_id = "1" ) :
 I11I11i1I = None
 o00O00O0O0O = requests . Session ( )
 OooO0OO = {
 'country_code' : oo000 . get_setting ( 'code' ) ,
 'phone' : oo000 . get_setting ( 'phone' ) ,
 'password' : oo000 . get_setting ( 'passw' ) ,
 'submit' : ''
 }
 o00O00O0O0O . post (
 "https://fptplay.net/user/login" ,
 headers = o0O ,
 data = OooO0OO
 )
 if "/livetv" in url or "/event" in url :
  oo = o00O00O0O0O . get ( url , headers = o0O )
  oo . encoding = "utf-8"
  IiII1I1i1i1ii = i1oOOoo00O0O ( oo . text ) . encode ( "utf8" )
  ii11i1iIII = re . compile ( 'showAlert\("(.+?)"' ) . findall ( IiII1I1i1i1ii ) [ 0 ]
  Ii1I = re . compile ( '"X-KEY", ?"(.+?)"' ) . findall ( IiII1I1i1i1ii ) [ 0 ]
  o0O [ "X-Key" ] = Ii1I
  OooO0OO = {
 'id' : ii11i1iIII ,
 'type' : 'newchannel' ,
 'quality' : '3' ,
 'mobile' : 'web'
 }
  Oo0o0 = o00O00O0O0O . post ( IIi1IiiiI1Ii , headers = o0O , data = OooO0OO ) . json ( )
  I11I11i1I = Oo0o0 [ "stream" ]
 else :
  oo = o00O00O0O0O . get (
 "https://fptplay.net/xem-video/-%s.html" % url ,
 headers = o0O )
  oo . encoding = "utf-8"
  IiII1I1i1i1ii = i1oOOoo00O0O ( oo . text ) . encode ( "utf8" )
  Ii1I = re . compile ( '"X-KEY", ?"(.+?)"' ) . findall ( IiII1I1i1i1ii ) [ 0 ]
  o0O [ "X-Key" ] = Ii1I
  OooO0OO = {
 'id' : url ,
 'type' : 'newchannel' ,
 'quality' : '3' ,
 'mobile' : 'web' ,
 'episode' : ep_id
 }
  I11I11i1I = o00O00O0O0O . post ( oO00oOo , headers = o0O , data = OooO0OO ) . json ( ) [ "stream" ]
 if "ttlogin" in I11I11i1I :
  if xbmc . getSkinDir ( ) != "skin.titan" :
   III1ii1iII = xbmcgui . Dialog ( )
   oo0oooooO0 = III1ii1iII . yesno (
 'Đăng nhập không hợp lệ!' ,
 'Nội dung này cần tài khoản đăng nhập để xem.\nChưa có tài khoản? Vào [COLOR orange]fptplay.net[/COLOR] để đăng ký.\n[COLOR yellow][B]Bạn có muốn nhập tài khoản bây giờ không?[/B][/COLOR]' ,
 yeslabel = 'Nhập ngay' ,
 nolabel = 'Bỏ qua!'
 )
   if oo0oooooO0 :
    oo000 . open_settings ( )
    return II1i1Ii11Ii11 ( url , ep_id )
  else :
   i11Iiii = xbmcgui . Dialog ( )
   IiII1I1i1i1ii = 'Nội dung này cần tài khoản đăng nhập để xem.\nChưa có tài khoản? Vào [COLOR orange]fptplay.net[/COLOR] để đăng ký.\n[COLOR yellow]Xong bật [B]Menu[/B] > [B]Add-on Settings[/B] để nhập tài khoản[/COLOR]'
   i11Iiii . ok ( 'Đăng nhập không hợp lệ!' , IiII1I1i1i1ii )
   I11I11i1I = None
   if 23 - 23: iII111i . i1
 return I11I11i1I
 if 98 - 98: iiiIIii1IIi % Oo * IiII * Oo
 if 45 - 45: oOo0 . Oo
def O0Oo ( title = "Home" , page = "/" ) :
 oO = "http://www.google-analytics.com/collect"
 ii1i1I1i = open ( o00oOO0 ) . read ( )
 oOoo = {
 'v' : '1' ,
 'tid' : 'UA-52209804-5' ,
 'cid' : ii1i1I1i ,
 't' : 'pageview' ,
 'dp' : "FPTPlay" + page ,
 'dt' : title
 }
 requests . post ( oO , data = urllib . urlencode ( oOoo ) )
 if 8 - 8: Oo
o00O = xbmc . translatePath ( 'special://userdata' )
if os . path . exists ( o00O ) == False :
 os . mkdir ( o00O )
o00oOO0 = os . path . join ( o00O , 'cid' )
if 69 - 69: I1Ii111 % oOo0 - iII111i + oOo0 - OO0OO0O0O0 % iII111iiiii11
if os . path . exists ( o00oOO0 ) == False :
 with open ( o00oOO0 , "w" ) as Iii111II :
  Iii111II . write ( str ( uuid . uuid1 ( ) ) )
  if 9 - 9: iIIIiiIIiiiIi
if __name__ == '__main__' :
 oo000 . run ( )
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
