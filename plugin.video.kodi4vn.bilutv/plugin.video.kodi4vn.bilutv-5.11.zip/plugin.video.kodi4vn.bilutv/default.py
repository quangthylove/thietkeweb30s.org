#!/usr/bin/python
# -*- coding: utf-8 -*-
import urllib , requests , re , os , json , uuid , base64
from xbmcswift2 import Plugin , xbmc , xbmcgui , xbmcaddon
from operator import itemgetter
requests . packages . urllib3 . disable_warnings ( )
oo000 = Plugin ( )
ii = xbmc . translatePath ( 'special://userdata' )
oOOo = os . path . join ( ii , 'search.p' )
if 59 - 59: Oo0Ooo . OO0OO0O0O0 * iiiIIii1IIi . iII111iiiii11 % I1IiiI
IIi1IiiiI1Ii = "plugin://plugin.video.kodi4vn.bilutv"
I11i11Ii = "https://docs.google.com/drawings/d/12OjbFr3Z5TCi1WREwTWECxNNwx0Kx-FTrCLOigrpqG4/pub?w=256&h=256"
oO00oOo = "https://docs.google.com/drawings/d/1rniOY_omlvmXtpuHFoMuCS3upWOu04DD0KWRyLV4szs/pub?w=1920&h=1080"
OOOo0 = "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.75 Safari/537.36"
Oooo000o = "Mozilla/5.0 (iPhone; CPU iPhone OS 8_0_2 like Mac OS X) AppleWebKit/600.1.4 (KHTML, like Gecko) Version/8.0 Mobile/12A366 Safari/600.1.4"
IiIi11iIIi1Ii = '<li class="film-item.+?"><label class="current-status">(.+?)</label>(.*?)<a href=".+?-(\d+).html"[^>]*><img src="(.+?)"[^>]*/><div[^>]*><p[^>]*>(.*?)</p><p[^>]*>(.+?)</p></div></a></li>'
Oo0O = '<li class="film-item.+?"><label class="current-status">(.+?)</label>(.*?)<a[^>]*href=".+?-(\d+).html"[^>]*><img[^>]*data-original="(.+?)"[^>]*><div[^>]*><p[^>]*>(.*?)</p><p[^>]*>(.+?)</p></div></a></li>'
IiI = '<a class="watch_button now" href="(.+?)">Xem phim</a>'
ooOo = '<li><a href="(/xem-phim/.+?)">(.+?)</a></li>'
Oo = '&file=/xml.php\?id=(\d+)'
o0O = '<div class="list_episodes content">.*?<td[^>]*class="name">%s</td><td valign="top" class="ep">(.+?)</td></tr>'
if 48 - 48: iII111i % IiII + I1Ii111 / ooOoO0o * o00O0oo
O0oOO0o0 = 24
if 9 - 9: o0o - OOO0o0o
@ oo000 . route ( '/' )
def Ii1iI ( ) :
 xbmc . executebuiltin ( "ShowPicture(%s)" % oO00oOo )
 if 100 - 100: i11Ii11I1Ii1i . ooO - OOoO / ooo0Oo0 * i1 - OOooo0000ooo
@ oo000 . route ( '/search' )
def OOo000 ( ) :
 O0 = oo000 . keyboard ( heading = 'Tìm kiếm' )
 if O0 :
  I11i1i11i1I = 'http://bilutv.com/tim-kiem.html?q=' + urllib . quote_plus ( O0 ) + '&p=%s'
  with open ( oOOo , "a" ) as Iiii :
   Iiii . write ( O0 + "\n" )
  OOO0O = {
 "title" : "Search: %s" % O0 ,
 "url" : I11i1i11i1I ,
 "page" : 1
 }
  oo0ooO0oOOOOo = '%s/list_media/%s' % (
 IIi1IiiiI1Ii ,
 urllib . quote_plus ( json . dumps ( OOO0O ) )
 )
  oo000 . redirect ( oo0ooO0oOOOOo )
  if 71 - 71: O00OoOoo00
@ oo000 . route ( '/searchlist' )
def iIiiI1 ( ) :
 OoOooOOOO (
 '[Search List]' ,
 '/searchlist/'
 )
 i11iiII = [ ]
 I1iiiiI1iII = [ {
 "label" : "[B]Search[/B]" ,
 "path" : "%s/search" % ( IIi1IiiiI1Ii ) ,
 "thumbnail" : "https://docs.google.com/drawings/d/1uP5xm3I5KRZsnoliqJDkYJXYz1MznecVqWg3e-Gue48/pub?w=256&h=256"
 } ]
 IiIi11i = [ ]
 if os . path . exists ( oOOo ) :
  with open ( oOOo , "r" ) as Iiii :
   IiIi11i = Iiii . read ( ) . strip ( ) . split ( "\n" )
  for iIii1I111I11I in reversed ( IiIi11i ) :
   I11i1i11i1I = 'http://bilutv.com/tim-kiem.html?q=' + urllib . quote_plus ( iIii1I111I11I ) + '&p=%s'
   OOO0O = {
 "title" : "Search: %s" % iIii1I111I11I ,
 "url" : I11i1i11i1I ,
 "page" : 1
 }
   OO00OooO0OO = { }
   OO00OooO0OO [ "label" ] = iIii1I111I11I
   OO00OooO0OO [ "path" ] = "%s/list_media/%s" % (
 IIi1IiiiI1Ii ,
 urllib . quote_plus ( json . dumps ( OOO0O ) )
 )
   OO00OooO0OO [ "thumbnail" ] = "https://docs.google.com/drawings/d/1uP5xm3I5KRZsnoliqJDkYJXYz1MznecVqWg3e-Gue48/pub?w=256&h=256"
   i11iiII . append ( OO00OooO0OO )
 i11iiII = I1iiiiI1iII + i11iiII
 return oo000 . finish ( i11iiII )
 if 28 - 28: iIii1
@ oo000 . route ( '/list_media/<args_json>' )
def oOOoO0 ( args_json = { } ) :
 i11iiII = [ ]
 O0OoO000O0OO = json . loads ( args_json )
 OoOooOOOO (
 "[Browse Media of] %s - Page %s" % (
 O0OoO000O0OO [ "title" ] if "title" in O0OoO000O0OO else "Unknow Title" ,
 O0OoO000O0OO [ "page" ] if "page" in O0OoO000O0OO else "1"
 ) ,
 '/list_media/%s/%s' % (
 O0OoO000O0OO [ "url" ] % O0OoO000O0OO [ "page" ] if "page" in O0OoO000O0OO else "1" ,
 json . dumps ( O0OoO000O0OO [ "payloads" ] ) if "payloads" in O0OoO000O0OO else "{}"
 )
 )
 iiI1IiI = II ( O0OoO000O0OO [ "url" ] % O0OoO000O0OO [ "page" ] )
 if "Search: " in O0OoO000O0OO [ "title" ] :
  ooOoOoo0O = re . compile ( Oo0O ) . findall ( iiI1IiI )
 else :
  ooOoOoo0O = re . compile ( IiIi11iIIi1Ii ) . findall ( iiI1IiI )
 for OooO0 , II11iiii1Ii , OO0o , Ooo , O0o0Oo , Oo00OOOOO in ooOoOoo0O :
  II11iiii1Ii = re . sub ( '<[^>]*>' , '' , II11iiii1Ii ) . strip ( )
  if "://" not in Ooo :
   Ooo = "http://bilutv.com/" + Ooo
  I11i1i11i1I = "http://bilutv.com/xem-phim/phim---%s" % OO0o
  O0O = "%s - %s (%s %s)" % ( O0o0Oo , Oo00OOOOO , OooO0 , re . sub ( '<[^>]*>' , '' , II11iiii1Ii ) )
  OOO0O = {
 "title" : O0O ,
 "quality_label" : II11iiii1Ii ,
 "url" : I11i1i11i1I
 }
  OO00OooO0OO = { }
  OO00OooO0OO [ "label" ] = O0O
  OO00OooO0OO [ "path" ] = "%s/list_mirrors/%s" % (
 IIi1IiiiI1Ii ,
 urllib . quote_plus ( json . dumps ( OOO0O ) )
 )
  OO00OooO0OO [ "thumbnail" ] = Ooo
  if "HD" in OooO0 :
   OO00OooO0OO [ "label" ] = "[COLOR yellow]%s[/COLOR]" % OO00OooO0OO [ "label" ]
  i11iiII . append ( OO00OooO0OO )
 if len ( i11iiII ) == O0oOO0o0 :
  O00o0OO = int ( O0OoO000O0OO [ "page" ] ) + 1
  O0OoO000O0OO [ "page" ] = O00o0OO
  i11iiII . append ( {
 'label' : 'Next >>' ,
 'path' : '%s/list_media/%s' % (
 IIi1IiiiI1Ii ,
 urllib . quote_plus ( json . dumps ( O0OoO000O0OO ) )
 ) ,
 'thumbnail' : I11i11Ii
 } )
 return oo000 . finish ( i11iiII )
 if 44 - 44: OOooo0000ooo / OO0OO0O0O0 % I1IiiI * i11Ii11I1Ii1i + I1Ii111
@ oo000 . route ( '/list_mirrors/<args_json>' )
def Ii1I ( args_json = { } ) :
 i11iiII = [ ]
 O0OoO000O0OO = json . loads ( args_json )
 OoOooOOOO (
 "[Browse Mirrors of] %s (%s)" % (
 O0OoO000O0OO [ "title" ] if "title" in O0OoO000O0OO else "Unknow Title" ,
 O0OoO000O0OO [ "quality_label" ] if "quality_label" in O0OoO000O0OO else ""
 ) ,
 '/list_mirrors/%s/%s' % (
 O0OoO000O0OO [ "url" ] ,
 json . dumps ( O0OoO000O0OO [ "payloads" ] ) if "payloads" in O0OoO000O0OO else "{}"
 )
 )
 OOO0O = {
 "title" : O0OoO000O0OO [ "title" ] ,
 "quality_label" : O0OoO000O0OO [ "quality_label" ] ,
 "mirror" : "Default server" ,
 "url" : O0OoO000O0OO [ "url" ]
 }
 Oo0o0 = '%s/list_eps/%s' % (
 IIi1IiiiI1Ii ,
 urllib . quote_plus ( json . dumps ( OOO0O ) )
 )
 oo000 . redirect ( Oo0o0 )
 return oo000 . finish ( i11iiII )
 if 49 - 49: i11Ii11I1Ii1i % ooo0Oo0 + I1IiiI . IiII % OOO0o0o
@ oo000 . route ( '/list_eps/<args_json>' )
def I1i1iii ( args_json = { } ) :
 i11iiII = [ ]
 O0OoO000O0OO = json . loads ( args_json )
 OoOooOOOO (
 "[Browse Episodes of] %s (%s) [%s]" % (
 O0OoO000O0OO [ "title" ] if "title" in O0OoO000O0OO else "Unknow Title" ,
 O0OoO000O0OO [ "quality_label" ] if "quality_label" in O0OoO000O0OO else "" ,
 O0OoO000O0OO [ "mirror" ] if "mirror" in O0OoO000O0OO else ""
 ) ,
 '/list_mirrors/%s/%s' % (
 O0OoO000O0OO [ "url" ] ,
 json . dumps ( O0OoO000O0OO [ "payloads" ] ) if "payloads" in O0OoO000O0OO else "{}"
 )
 )
 iiI1IiI = II ( O0OoO000O0OO [ "url" ] )
 i1iiI11I = re . compile ( '-(\d+_e\d+.*?.html)">(.+?)</a>' ) . findall ( iiI1IiI )
 if len ( i1iiI11I ) > 0 :
  for iiii , oO0o0O0OOOoo0 in i1iiI11I :
   if "_HD2" not in iiii :
    iiii = iiii . replace ( ".html" , "_HD2.html" )
   IiIiiI = "http://bilutv.com/xem-phim/phim---%s" % iiii
   OOO0O = {
 "title" : O0OoO000O0OO [ "title" ] ,
 "quality_label" : O0OoO000O0OO [ "quality_label" ] ,
 "mirror" : O0OoO000O0OO [ "mirror" ] ,
 "url" : IiIiiI ,
 "eps" : oO0o0O0OOOoo0
 }
   OO00OooO0OO = { }
   OO00OooO0OO [ "label" ] = "Part %s - %s (%s) [%s]" % (
 oO0o0O0OOOoo0 . decode ( "utf8" ) ,
 O0OoO000O0OO [ "title" ] ,
 O0OoO000O0OO [ "quality_label" ] ,
 O0OoO000O0OO [ "mirror" ]
 )
   OO00OooO0OO [ "label" ]
   OO00OooO0OO [ "path" ] = '%s/play/%s' % (
 IIi1IiiiI1Ii ,
 urllib . quote_plus ( json . dumps ( OOO0O ) )
 )
   OO00OooO0OO [ "is_playable" ] = True
   i11iiII . append ( OO00OooO0OO )
 else :
  try :
   OOO0O = {
 "title" : O0OoO000O0OO [ "title" ] ,
 "quality_label" : O0OoO000O0OO [ "quality_label" ] ,
 "mirror" : O0OoO000O0OO [ "mirror" ] ,
 "url" : O0OoO000O0OO [ "url" ] ,
 "eps" : "Full"
 }
   OO00OooO0OO = { }
   OO00OooO0OO [ "label" ] = "Part %s - %s (%s) [%s]" % (
 "Full" ,
 O0OoO000O0OO [ "title" ] ,
 O0OoO000O0OO [ "quality_label" ] ,
 O0OoO000O0OO [ "mirror" ]
 )
   OO00OooO0OO [ "path" ] = '%s/play/%s' % (
 IIi1IiiiI1Ii ,
 urllib . quote_plus ( json . dumps ( OOO0O ) )
 )
   OO00OooO0OO [ "is_playable" ] = True
   i11iiII . append ( OO00OooO0OO )
  except :
   pass
 return oo000 . finish ( i11iiII )
 if 31 - 31: ooo0Oo0 . ooo0Oo0 - o0o / ooOoO0o + iIii1 * IiII
@ oo000 . route ( '/play/<args_json>' )
def O0ooOooooO ( args_json = { } ) :
 O0OoO000O0OO = json . loads ( args_json )
 OoOooOOOO (
 "[Play] %s (%s) - Part %s [%s]" % (
 O0OoO000O0OO [ "title" ] if "title" in O0OoO000O0OO else "Unknow Title" ,
 O0OoO000O0OO [ "quality_label" ] if "quality_label" in O0OoO000O0OO else "" ,
 O0OoO000O0OO [ "eps" ] if "eps" in O0OoO000O0OO else "" ,
 O0OoO000O0OO [ "mirror" ] if "mirror" in O0OoO000O0OO else ""
 ) ,
 '/play/%s/%s' % (
 O0OoO000O0OO [ "url" ] ,
 json . dumps ( O0OoO000O0OO [ "payloads" ] ) if "payloads" in O0OoO000O0OO else "{}"
 )
 )
 oo000 . set_resolved_url ( o00O ( O0OoO000O0OO [ "url" ] ) )
 if 69 - 69: i11Ii11I1Ii1i % O00OoOoo00 - o0o + O00OoOoo00 - OO0OO0O0O0 % iII111iiiii11
def o00O ( url ) :
 iiI1IiI = II ( url )
 Iii111II = None
 ooOoOoo0O = re . compile ( 'playerSetting = (\{.+?\})\;' ) . findall ( iiI1IiI )
 iiii11I = json . loads ( ooOoOoo0O [ 0 ] )
 Ooo0OO0oOO = "bilutv.com4590481877" + iiii11I [ "modelId" ]
 ii11i1 = [ "sourceLinks" , "sourceLinksBk" , "sourcesVs" , "sourcesTm" ]
 if 29 - 29: OOO0o0o % IiII + iIii1 / o0o + ooO * o0o
 for i1I1iI in ii11i1 :
  if i1I1iI in iiii11I :
   for oo0OooOOo0 in iiii11I [ i1I1iI ] :
    if oo0OooOOo0 [ "server" ] == "ga" :
     for o0OO00oO in oo0OooOOo0 [ "links" ] :
      try :
       Iiii = I11i1I1I ( o0OO00oO [ "file" ] , Ooo0OO0oOO )
       if any ( iiI1IiI in Iiii for iiI1IiI in [ "=m18" , "=m22" ] ) :
        oO0Oo = Iiii . replace ( "=m18" , "=m22" ) . replace ( "https://" , "http://" )
        oOOoo0Oo = requests . head ( oO0Oo ) . status_code
        if oOOoo0Oo != 404 :
         return oO0Oo
        else :
         return Iiii
      except : pass
   for oo0OooOOo0 in iiii11I [ i1I1iI ] :
    if oo0OooOOo0 [ "server" ] == "gd" :
     for o0OO00oO in oo0OooOOo0 [ "links" ] :
      try :
       Iiii = I11i1I1I ( o0OO00oO [ "file" ] , Ooo0OO0oOO )
       return o00OO00OoO ( Iiii . replace ( "/preview" , "/view" ) , oo000 . get_setting ( 'HQ' , bool ) )
      except : pass
   for oo0OooOOo0 in iiii11I [ i1I1iI ] :
    if oo0OooOOo0 [ "server" ] == "yt" :
     for o0OO00oO in oo0OooOOo0 [ "links" ] :
      try :
       Iiii = I11i1I1I ( o0OO00oO [ "file" ] , Ooo0OO0oOO )
       OOOO0OOoO0O0 = re . compile ( '(youtu\.be\/|youtube-nocookie\.com\/|youtube\.com\/(watch\?(.*&)?v=|(embed|v|user)\/))([^\?&"\'>]+)' ) . findall ( Iiii )
       O0Oo000ooO00 = OOOO0OOoO0O0 [ 0 ] [ len ( OOOO0OOoO0O0 [ 0 ] ) - 1 ] . replace ( 'v/' , '' )
       return 'plugin://plugin.video.youtube/play/?video_id=%s' % O0Oo000ooO00
      except : pass
   for oo0OooOOo0 in iiii11I [ i1I1iI ] :
    if oo0OooOOo0 [ "server" ] == "gp" :
     for o0OO00oO in oo0OooOOo0 [ "links" ] :
      try :
       Iiii = I11i1I1I ( o0OO00oO [ "file" ] , Ooo0OO0oOO )
       return Iiii
      except : pass
      if 75 - 75: i11Ii11I1Ii1i . ooOoO0o * ooO
      if 91 - 91: ooo0Oo0
 return Iii111II
 if 30 - 30: o0o . ooo0Oo0 - iII111iiiii11
 if 8 - 8: I1IiiI - iiiIIii1IIi * iII111i + Oo0Ooo / O00OoOoo00 % ooO
def II ( url , data = { } ) :
 iIIIi1 = {
 'User-Agent' : OOOo0 ,
 'Accept-Encoding' : 'gzip, deflate, sdch' ,
 'Content-Type' : 'text/html; charset=utf-8' ,
 }
 if data == { } :
  iiII1i1 = requests . get (
 url ,
 headers = iIIIi1 )
 else :
  iIIIi1 [ "Content-Type" ] = "application/x-www-form-urlencoded"
  iiII1i1 = requests . post (
 url ,
 headers = iIIIi1 ,
 data = data )
  return iiII1i1 . json ( )
 iiII1i1 . encoding = "utf-8"
 iiI1IiI = o00oOO0o ( iiII1i1 . text . encode ( "utf8" ) )
 return iiI1IiI
 if 80 - 80: i11Ii11I1Ii1i + ooO - ooO % i1
def o00OO00OoO ( url , hq ) :
 iIIIi1 = {
 'User-Agent' : OOOo0 ,
 'Accept-Encoding' : 'gzip, deflate, sdch' ,
 }
 iiII1i1 = requests . get ( url , headers = iIIIi1 )
 OOOO0OOoO0O0 = re . compile ( '(\["fmt_stream_map".+?\])' ) . findall ( iiII1i1 . text ) [ 0 ]
 OoOO0oo0o = [ "38" , "37" , "46" , "22" , "45" , "18" , "43" ]
 if not hq : reversed ( OoOO0oo0o )
 II11i1I11Ii1i = json . loads ( OOOO0OOoO0O0 ) [ 1 ] . split ( "," )
 for O000O0oOO0 in OoOO0oo0o :
  for O0ooo0O0oo0 in II11i1I11Ii1i :
   if O0ooo0O0oo0 . startswith ( O000O0oOO0 + "|" ) :
    url = O0ooo0O0oo0 . split ( "|" ) [ 1 ]
    oo0oOo = "|User-Agent=%s&Cookie=%s" % ( urllib . quote ( OOOo0 ) , urllib . quote ( iiII1i1 . headers [ 'set-cookie' ] ) )
    return url + oo0oOo
 raise ValueError ( 'NaN' )
 if 89 - 89: o00O0oo
def OO0oOoOO0oOO0 ( url , data = { } ) :
 iIIIi1 = {
 'User-Agent' : Oooo000o ,
 'Accept-Encoding' : 'gzip, deflate, sdch' ,
 }
 if data == { } :
  iiII1i1 = requests . get (
 url ,
 headers = iIIIi1 )
 else :
  iIIIi1 [ "Content-Type" ] = "application/x-www-form-urlencoded"
  iiII1i1 = requests . post (
 url ,
 headers = iIIIi1 ,
 data = data )
 iiII1i1 . encoding = "utf-8"
 iiI1IiI = o00oOO0o ( iiII1i1 . text . encode ( "utf8" ) )
 return iiI1IiI
 if 86 - 86: ooO
def o00oOO0o ( s ) :
 s = '' . join ( s . splitlines ( ) ) . replace ( '\'' , '"' )
 s = s . replace ( '\n' , '' )
 s = s . replace ( '\t' , '' )
 s = re . sub ( '  +' , ' ' , s )
 s = s . replace ( '> <' , '><' )
 return s
 if 55 - 55: I1Ii111 + iiiIIii1IIi / o00O0oo * i11Ii11I1Ii1i - Oo0Ooo - ooo0Oo0
def ii1ii1ii ( s ) :
 O000O0oOO0 = re . compile ( r'<.*?>' , re . IGNORECASE )
 s = re . sub ( O000O0oOO0 , '' , s )
 return s . strip ( )
 if 91 - 91: OOooo0000ooo
def OoOooOOOO ( title = "Home" , page = "/" ) :
 try :
  iiIii = "http://www.google-analytics.com/collect"
  ooo0O = open ( oOoO0o00OO0 ) . read ( )
  i1I1ii = {
 'v' : '1' ,
 'tid' : 'UA-52209804-5' ,
 'cid' : ooo0O ,
 't' : 'pageview' ,
 'dp' : "BiluTV%s" % page ,
 'dt' : "[BiluTV] - %s" % title . encode ( "utf8" )
 }
  requests . post ( iiIii , data = urllib . urlencode ( i1I1ii ) )
 except :
  pass
  if 61 - 61: iII111i
def O0OOO ( pattern , string , group = 1 , flags = 0 , result = '' ) :
 try : iiI1IiI = re . search ( pattern , string , flags ) . group ( group )
 except : iiI1IiI = result
 return iiI1IiI
 if 10 - 10: ooO * OOoO % o00O0oo / IiII / o00O0oo
def I11i1I1I ( string , key = '' ) :
 import ctypes
 def iIIi1i1 ( l , s = 4 ) :
  i1IIIiiII1 = [ ]
  for OOOOoOoo0O0O0 in range ( 0 , len ( l ) , s ) : i1IIIiiII1 . append ( ( l [ OOOOoOoo0O0O0 : OOOOoOoo0O0O0 + s ] ) )
  return i1IIIiiII1
  if 85 - 85: i11Ii11I1Ii1i % Oo0Ooo - i1 * iII111iiiii11 / IiII % IiII
 def IIiIi1iI ( v ) : return ctypes . c_int ( v ) . value
 def i1IiiiI1iI ( val , n ) : return ( val % 0x100000000 ) >> n
 if 49 - 49: ooo0Oo0 / ooOoO0o . iII111i
 ooOOoooooo = 14
 II1I = 8
 O0i1II1Iiii1I11 = False
 if 9 - 9: OOO0o0o / I1Ii111 - IiII / iII111iiiii11 / iiiIIii1IIi - o0o
 def Iiii ( e ) :
  if 91 - 91: i1 % I1IiiI % iiiIIii1IIi
  if 20 - 20: ooO % ooo0Oo0 / ooo0Oo0 + ooo0Oo0
  return str ( e )
  if 45 - 45: i11Ii11I1Ii1i - OOooo0000ooo - iII111iiiii11 - ooOoO0o . iII111i / OO0OO0O0O0
 def oo0o00O ( e ) :
  if 51 - 51: ooo0Oo0 - ooOoO0o * i1
  if 66 - 66: iII111iiiii11 + OO0OO0O0O0
  return str ( e )
  if 11 - 11: OOoO + iII111iiiii11 - ooOoO0o / o0o + I1Ii111 . iII111i
 def i1Iii1i1I ( e ) :
  Iiii = [ 0 ] * len ( e )
  if 16 > len ( e ) :
   II1I = 16 - len ( e )
   Iiii = [ II1I , II1I , II1I , II1I , II1I , II1I , II1I , II1I , II1I , II1I , II1I , II1I , II1I , II1I , II1I , II1I ]
  for O0i1II1Iiii1I11 in range ( len ( e ) ) : Iiii [ O0i1II1Iiii1I11 ] = e [ O0i1II1Iiii1I11 ]
  return Iiii
  if 91 - 91: OOO0o0o + IiII . ooO * OOO0o0o + IiII * I1Ii111
 def O000OOOOOo ( e ) :
  O0i1II1Iiii1I11 = ""
  for II1I in len ( e ) : O0i1II1Iiii1I11 += ( "0" if 16 > e [ II1I ] else "" ) + format ( e [ II1I ] , 'x' )
  return O0i1II1Iiii1I11
  if 22 - 22: I1IiiI + OO0OO0O0O0 . iiiIIii1IIi * i1 % Oo0Ooo * IiII
 def oo000o ( e , r ) :
  oo0o00O = [ ]
  if not r : e = Iiii ( e )
  for O0i1II1Iiii1I11 in range ( len ( e ) ) : oo0o00O . append ( ord ( e [ O0i1II1Iiii1I11 ] ) )
  return oo0o00O
  if 44 - 44: I1IiiI % iII111i + OOoO
 def OOOOoOoo0O0O0 ( n ) :
  if n == 128 : ooOOoooooo = 10 ; II1I = 4
  elif n == 192 : ooOOoooooo = 12 ; II1I = 6
  elif n == 256 : ooOOoooooo = 14 ; II1I = 8
  if 45 - 45: i1 / i1 + O00OoOoo00 + iIii1
 def iI111i ( e ) :
  O0i1II1Iiii1I11 = [ ]
  for II1I in range ( e ) : O0i1II1Iiii1I11 . append ( 256 )
  return O0i1II1Iiii1I11
  if 26 - 26: OOO0o0o * i1 . iII111i * ooo0Oo0
 def II1 ( n , f ) :
  iiiIi1 = [ ] ; i1Iii1i1I = 3 if ooOOoooooo >= 12 else 2 ; OOOOoOoo0O0O0 = n + f ; iiiIi1 . append ( i1I1ii11i1Iii ( OOOOoOoo0O0O0 ) ) ; oo000o = [ oo0o00O for oo0o00O in iiiIi1 [ 0 ] ]
  for oo0o00O in range ( 1 , i1Iii1i1I ) : iiiIi1 . append ( i1I1ii11i1Iii ( iiiIi1 [ oo0o00O - 1 ] + OOOOoOoo0O0O0 ) ) ; oo000o += iiiIi1 [ oo0o00O ]
  return { 'key' : oo000o [ 0 : 4 * II1I ] , 'iv' : oo000o [ 4 * II1I : 4 * II1I + 16 ] }
  if 26 - 26: OOoO - iiiIIii1IIi - IiII / ooOoO0o . o00O0oo % iiiIIii1IIi
 def OO ( e , r = False ) :
  oo0o00O = ""
  if ( r ) :
   O0i1II1Iiii1I11 = e [ 15 ]
   if 25 - 25: ooOoO0o
   if 16 != O0i1II1Iiii1I11 :
    for Iiii in range ( 16 - O0i1II1Iiii1I11 ) : oo0o00O += chr ( e [ Iiii ] )
  else :
   for Iiii in range ( 16 ) : oo0o00O += chr ( e [ Iiii ] )
  return oo0o00O
  if 62 - 62: ooO + OO0OO0O0O0
 def i1IIIiiII1 ( e , r = False ) :
  if not r : oo0o00O = '' . join ( chr ( e [ f ] ) for f in range ( 16 ) )
  elif 16 != e [ 15 ] : oo0o00O = '' . join ( chr ( e [ f ] ) for f in range ( 16 - e [ 15 ] ) )
  else : oo0o00O = ''
  return oo0o00O
  if 98 - 98: o0o
 def OOOO0oo0 ( e , r , n , f = '' ) :
  r = I11iiI1i1 ( r ) ; O000OOOOOo = len ( e ) / 16 ; oo000o = [ 0 ] * O000OOOOOo
  iiiIi1 = [ e [ 16 * i1Iii1i1I : 16 * ( i1Iii1i1I + 1 ) ] for i1Iii1i1I in range ( O000OOOOOo ) ]
  for i1Iii1i1I in range ( len ( iiiIi1 ) - 1 , - 1 , - 1 ) :
   oo000o [ i1Iii1i1I ] = I1i1Iiiii ( iiiIi1 [ i1Iii1i1I ] , r )
   oo000o [ i1Iii1i1I ] = OOo0oO00ooO00 ( oo000o [ i1Iii1i1I ] , n ) if 0 == i1Iii1i1I else OOo0oO00ooO00 ( oo000o [ i1Iii1i1I ] , iiiIi1 [ i1Iii1i1I - 1 ] )
   if 90 - 90: o00O0oo * O00OoOoo00 + o0o
  OOOOoOoo0O0O0 = '' . join ( i1IIIiiII1 ( oo000o [ i1Iii1i1I ] ) for i1Iii1i1I in range ( O000OOOOOo - 1 ) )
  OOOOoOoo0O0O0 += i1IIIiiII1 ( oo000o [ O000OOOOOo - 1 ] , True )
  return OOOOoOoo0O0O0 if f else oo0o00O ( OOOOoOoo0O0O0 )
  if 81 - 81: i11Ii11I1Ii1i . o0o % OO0OO0O0O0 / IiII - i11Ii11I1Ii1i
 def iiI1IiI ( r , f ) :
  O0i1II1Iiii1I11 = False
  i1Iii1i1I = Ii1I1i ( r , f , 0 )
  for oo0o00O in ( 1 , ooOOoooooo + 1 , 1 ) :
   i1Iii1i1I = OOI1iI1ii1II ( i1Iii1i1I )
   i1Iii1i1I = O0O0OOOOoo ( i1Iii1i1I )
   if ooOOoooooo > oo0o00O : i1Iii1i1I = oOooO0 ( i1Iii1i1I )
   i1Iii1i1I = Ii1I1i ( i1Iii1i1I , f , oo0o00O )
  return i1Iii1i1I
  if 29 - 29: iiiIIii1IIi + o00O0oo * ooOoO0o * ooO . IiII * IiII
 def I1i1Iiiii ( r , f ) :
  O0i1II1Iiii1I11 = True
  i1Iii1i1I = Ii1I1i ( r , f , ooOOoooooo )
  for oo0o00O in range ( ooOOoooooo - 1 , - 1 , - 1 ) :
   i1Iii1i1I = O0O0OOOOoo ( i1Iii1i1I , O0i1II1Iiii1I11 )
   i1Iii1i1I = OOI1iI1ii1II ( i1Iii1i1I , O0i1II1Iiii1I11 )
   i1Iii1i1I = Ii1I1i ( i1Iii1i1I , f , oo0o00O )
   if oo0o00O > 0 : i1Iii1i1I = oOooO0 ( i1Iii1i1I , O0i1II1Iiii1I11 )
  return i1Iii1i1I
  if 7 - 7: OOooo0000ooo * O00OoOoo00 % ooo0Oo0 - o0o
 def OOI1iI1ii1II ( e , n = True ) :
  Iiii = i1i if n else oOOoo00O00o ; oo0o00O = [ 0 ] * 16
  for II1I in range ( 16 ) : oo0o00O [ II1I ] = Iiii [ e [ II1I ] ]
  return oo0o00O
  if 98 - 98: ooO + OOooo0000ooo + i11Ii11I1Ii1i % iII111iiiii11
 def O0O0OOOOoo ( e , n = True ) :
  Iiii = [ ]
  if n : oo0o00O = [ 0 , 13 , 10 , 7 , 4 , 1 , 14 , 11 , 8 , 5 , 2 , 15 , 12 , 9 , 6 , 3 ]
  else : oo0o00O = [ 0 , 5 , 10 , 15 , 4 , 9 , 14 , 3 , 8 , 13 , 2 , 7 , 12 , 1 , 6 , 11 ]
  for II1I in range ( 16 ) : Iiii . append ( e [ oo0o00O [ II1I ] ] )
  return Iiii
  if 97 - 97: OO0OO0O0O0 * iII111iiiii11 . iII111iiiii11
 def oOooO0 ( e , n = True ) :
  Iiii = [ 0 ] * 16
  if ( n ) :
   for II1I in range ( 4 ) :
    Iiii [ 4 * II1I ] = I111iI [ e [ 4 * II1I ] ] ^ oOOo0 [ e [ 1 + 4 * II1I ] ] ^ II1I1iiIII [ e [ 2 + 4 * II1I ] ] ^ oOOo0O00o [ e [ 3 + 4 * II1I ] ]
    Iiii [ 1 + 4 * II1I ] = oOOo0O00o [ e [ 4 * II1I ] ] ^ I111iI [ e [ 1 + 4 * II1I ] ] ^ oOOo0 [ e [ 2 + 4 * II1I ] ] ^ II1I1iiIII [ e [ 3 + 4 * II1I ] ]
    Iiii [ 2 + 4 * II1I ] = II1I1iiIII [ e [ 4 * II1I ] ] ^ oOOo0O00o [ e [ 1 + 4 * II1I ] ] ^ I111iI [ e [ 2 + 4 * II1I ] ] ^ oOOo0 [ e [ 3 + 4 * II1I ] ]
    Iiii [ 3 + 4 * II1I ] = oOOo0 [ e [ 4 * II1I ] ] ^ II1I1iiIII [ e [ 1 + 4 * II1I ] ] ^ oOOo0O00o [ e [ 2 + 4 * II1I ] ] ^ I111iI [ e [ 3 + 4 * II1I ] ]
  else :
   for II1I in range ( 4 ) :
    Iiii [ 4 * II1I ] = iIiIi11 [ e [ 4 * II1I ] ] ^ OOO [ e [ 1 + 4 * II1I ] ] ^ e [ 2 + 4 * II1I ] ^ e [ 3 + 4 * II1I ]
    Iiii [ 1 + 4 * II1I ] = e [ 4 * II1I ] ^ iIiIi11 [ e [ 1 + 4 * II1I ] ] ^ OOO [ e [ 2 + 4 * II1I ] ] ^ e [ 3 + 4 * II1I ]
    Iiii [ 2 + 4 * II1I ] = e [ 4 * II1I ] ^ e [ 1 + 4 * II1I ] ^ iIiIi11 [ e [ 2 + 4 * II1I ] ] ^ OOO [ e [ 3 + 4 * II1I ] ]
    Iiii [ 3 + 4 * II1I ] = OOO [ e [ 4 * II1I ] ] ^ e [ 1 + 4 * II1I ] ^ e [ 2 + 4 * II1I ] ^ iIiIi11 [ e [ 3 + 4 * II1I ] ]
  return Iiii
  if 32 - 32: I1IiiI / iII111i . I1Ii111
 def Ii1I1i ( e , r , n ) :
  oo0o00O = [ 0 ] * 16
  for Iiii in range ( 16 ) : oo0o00O [ Iiii ] = e [ Iiii ] ^ r [ n ] [ Iiii ]
  return oo0o00O
  if 62 - 62: iII111iiiii11 * IiII
 def OOo0oO00ooO00 ( e , r ) :
  Iiii = [ 0 ] * 16
  for O0i1II1Iiii1I11 in range ( 16 ) : Iiii [ O0i1II1Iiii1I11 ] = e [ O0i1II1Iiii1I11 ] ^ r [ O0i1II1Iiii1I11 ]
  return Iiii
  if 58 - 58: o00O0oo % o0o
 def I11iiI1i1 ( n ) :
  O000OOOOOo = [ [ n [ 4 * Iiii + OOOOoOoo0O0O0 ] for OOOOoOoo0O0O0 in range ( 4 ) ] for Iiii in range ( II1I ) ]
  if 50 - 50: O00OoOoo00 . o0o
  for Iiii in range ( II1I , 4 * ( ooOOoooooo + 1 ) ) :
   iiiIi1 = [ i1Iii1i1I for i1Iii1i1I in O000OOOOOo [ Iiii - 1 ] ]
   if 0 == Iiii % II1I : iiiIi1 = ooO0OO ( O000OOO ( iiiIi1 ) ) ; iiiIi1 [ 0 ] ^= IIo0o0O0O00oOOo [ Iiii / II1I - 1 ]
   elif II1I > 6 and 4 == Iiii % II1I : iiiIi1 = ooO0OO ( iiiIi1 )
   O000OOOOOo . append ( [ O000OOOOOo [ Iiii - II1I ] [ i1Iii1i1I ] ^ iiiIi1 [ i1Iii1i1I ] for i1Iii1i1I in range ( 4 ) ] )
   if 14 - 14: o00O0oo + i11Ii11I1Ii1i
  oo000o = [ ]
  for Iiii in range ( ooOOoooooo + 1 ) :
   oo000o . append ( [ ] )
   for i1IIIiiII1 in range ( 4 ) : oo000o [ Iiii ] += O000OOOOOo [ 4 * Iiii + i1IIIiiII1 ]
  return oo000o
  if 52 - 52: iII111iiiii11 - iIii1
 def ooO0OO ( e ) :
  return [ oOOoo00O00o [ e [ II1I ] ] for II1I in range ( 4 ) ]
  if 74 - 74: i1 + o0o
 def O000OOO ( e ) :
  e . insert ( 4 , e [ 0 ] )
  e . remove ( e [ 4 ] )
  return e
  if 71 - 71: I1Ii111 % ooO
 def O00oO000O0O ( e , r ) : return [ int ( e [ O0i1II1Iiii1I11 : O0i1II1Iiii1I11 + r ] , 16 ) for O0i1II1Iiii1I11 in range ( 0 , len ( e ) , r ) ]
 if 18 - 18: i1 - ooO . O00OoOoo00 . iiiIIii1IIi
 def i1I ( e ) :
  O0i1II1Iiii1I11 = [ 0 ] * len ( e )
  for II1I in range ( len ( e ) ) : O0i1II1Iiii1I11 [ e [ II1I ] ] = II1I
  return O0i1II1Iiii1I11
  if 78 - 78: OOoO * iiiIIii1IIi . IiII / o0o - iII111iiiii11 / O00OoOoo00
 def i1I1IiiIi1i ( e , r ) :
  Iiii = 0
  for O0i1II1Iiii1I11 in range ( 8 ) :
   Iiii = Iiii ^ e if 1 == ( 1 & r ) else Iiii
   e = IIiIi1iI ( 283 ^ e << 1 ) if e > 127 else IIiIi1iI ( e << 1 )
   r >>= 1
  return Iiii
  if 29 - 29: IiII % IiII
 def Oo0O0 ( e ) :
  O0i1II1Iiii1I11 = [ 0 ] * 256
  for II1I in range ( 256 ) : O0i1II1Iiii1I11 [ II1I ] = i1I1IiiIi1i ( e , II1I )
  return O0i1II1Iiii1I11
  if 82 - 82: iII111i % OOoO / ooOoO0o + o00O0oo / o0o / O00OoOoo00
 oOOoo00O00o = O00oO000O0O ( "637c777bf26b6fc53001672bfed7ab76ca82c97dfa5947f0add4a2af9ca472c0b7fd9326363ff7cc34a5e5f171d8311504c723c31896059a071280e2eb27b27509832c1a1b6e5aa0523bd6b329e32f8453d100ed20fcb15b6acbbe394a4c58cfd0efaafb434d338545f9027f503c9fa851a3408f929d38f5bcb6da2110fff3d2cd0c13ec5f974417c4a77e3d645d197360814fdc222a908846eeb814de5e0bdbe0323a0a4906245cc2d3ac629195e479e7c8376d8dd54ea96c56f4ea657aae08ba78252e1ca6b4c6e8dd741f4bbd8b8a703eb5664803f60e613557b986c11d9ee1f8981169d98e949b1e87e9ce5528df8ca1890dbfe6426841992d0fb054bb16" , 2 )
 i1i = i1I ( oOOoo00O00o )
 IIo0o0O0O00oOOo = O00oO000O0O ( "01020408102040801b366cd8ab4d9a2f5ebc63c697356ad4b37dfaefc591" , 2 )
 iIiIi11 = Oo0O0 ( 2 )
 OOO = Oo0O0 ( 3 )
 oOOo0O00o = Oo0O0 ( 9 )
 oOOo0 = Oo0O0 ( 11 )
 II1I1iiIII = Oo0O0 ( 13 )
 I111iI = Oo0O0 ( 14 )
 if 70 - 70: i11Ii11I1Ii1i
 def oOOoO0o0oO ( e , r , n = '' ) :
  Iiii = o0Oo0oO0oOO00 ( e )
  oo0o00O = Iiii [ 8 : 16 ]
  i1Iii1i1I = II1 ( oo000o ( r , n ) , oo0o00O )
  i1IIIiiII1 = i1Iii1i1I [ 'key' ]
  O000OOOOOo = i1Iii1i1I [ 'iv' ]
  Iiii = Iiii [ 16 : len ( Iiii ) ]
  return OOOO0oo0 ( Iiii , i1IIIiiII1 , O000OOOOOo , n )
  if 92 - 92: iII111iiiii11 * O00OoOoo00
 def o0Oo0oO0oOO00 ( r ) :
  def o0000oO ( n ) :
   try : i1IIIiiII1 = ooOOoooooo . index ( r [ n ] )
   except : i1IIIiiII1 = - 1
   return i1IIIiiII1
   if 11 - 11: iIii1 / o00O0oo - OOooo0000ooo * iII111iiiii11 + iII111iiiii11 . o00O0oo
  ooOOoooooo = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"
  r = r . replace ( '\n' , '' ) ; Iiii = [ ] ; oo0o00O = [ 0 ] * 4
  for O0i1II1Iiii1I11 in range ( 0 , len ( r ) , 4 ) :
   for OOOOoOoo0O0O0 in range ( len ( oo0o00O ) ) : oo0o00O [ OOOOoOoo0O0O0 ] = o0000oO ( O0i1II1Iiii1I11 + OOOOoOoo0O0O0 )
   Iiii . append ( IIiIi1iI ( oo0o00O [ 0 ] << 2 | oo0o00O [ 1 ] >> 4 ) )
   Iiii . append ( IIiIi1iI ( ( 15 & oo0o00O [ 1 ] ) << 4 | oo0o00O [ 2 ] >> 2 ) )
   Iiii . append ( IIiIi1iI ( ( 3 & oo0o00O [ 2 ] ) << 6 | oo0o00O [ 3 ] ) )
  return Iiii [ 0 : len ( Iiii ) - len ( Iiii ) % 16 ]
  if 26 - 26: ooo0Oo0 % OOO0o0o
 def i1I1ii11i1Iii ( e ) :
  def II1I ( e , r ) : return IIiIi1iI ( e << r ) | IIiIi1iI ( i1IiiiI1iI ( e , 32 - r ) )
  if 76 - 76: OOooo0000ooo * i1
  def O0i1II1Iiii1I11 ( e , r ) :
   oo0o00O = 2147483648 & e
   i1Iii1i1I = 2147483648 & r
   O0i1II1Iiii1I11 = 1073741824 & e
   Iiii = 1073741824 & r
   i1IIIiiII1 = ( 1073741823 & e ) + ( 1073741823 & r )
   OOOOoOoo0O0O0 = 2147483648 ^ i1IIIiiII1 ^ oo0o00O ^ i1Iii1i1I
   II1I1iiIII = 3221225472 ^ i1IIIiiII1 ^ oo0o00O ^ i1Iii1i1I
   oOooO0 = 1073741824 ^ i1IIIiiII1 ^ oo0o00O ^ i1Iii1i1I
   return IIiIi1iI ( OOOOoOoo0O0O0 if O0i1II1Iiii1I11 & Iiii else ( ( II1I1iiIII if 1073741824 & i1IIIiiII1 else oOooO0 ) if O0i1II1Iiii1I11 | Iiii else i1IIIiiII1 ^ oo0o00O ^ i1Iii1i1I ) )
   if 52 - 52: ooO
  def Iiii ( e , r , n ) : return IIiIi1iI ( e & r ) | IIiIi1iI ( ~ e & n )
  if 19 - 19: IiII
  def oo0o00O ( e , r , n ) : return IIiIi1iI ( e & n ) | IIiIi1iI ( r & ~ n )
  if 25 - 25: ooo0Oo0 / iIii1
  def i1Iii1i1I ( e , r , n ) : return e ^ r ^ n
  if 31 - 31: ooO . OO0OO0O0O0 % IiII . o0o + OOooo0000ooo
  def i1IIIiiII1 ( e , r , n ) : return r ^ ( e | ~ n )
  if 71 - 71: O00OoOoo00 . iII111i
  def O000OOOOOo ( e , c , t , a , o , d , u ) :
   e = O0i1II1Iiii1I11 ( e , O0i1II1Iiii1I11 ( O0i1II1Iiii1I11 ( Iiii ( c , t , a ) , o ) , u ) )
   return O0i1II1Iiii1I11 ( II1I ( e , d ) , c )
   if 62 - 62: iII111iiiii11 . OOoO
  def iiiIi1 ( e , f , t , a , o , d , u ) :
   e = O0i1II1Iiii1I11 ( e , O0i1II1Iiii1I11 ( O0i1II1Iiii1I11 ( oo0o00O ( f , t , a ) , o ) , u ) )
   return O0i1II1Iiii1I11 ( II1I ( e , d ) , f )
   if 61 - 61: o00O0oo - ooO - I1IiiI
  def oo000o ( e , f , c , a , o , d , u ) :
   e = O0i1II1Iiii1I11 ( e , O0i1II1Iiii1I11 ( O0i1II1Iiii1I11 ( i1Iii1i1I ( f , c , a ) , o ) , u ) )
   return O0i1II1Iiii1I11 ( II1I ( e , d ) , f )
   if 25 - 25: OO0OO0O0O0 * OOoO + OOO0o0o . o0o . o0o
  def OOOOoOoo0O0O0 ( e , f , c , t , o , d , u ) :
   e = O0i1II1Iiii1I11 ( e , O0i1II1Iiii1I11 ( O0i1II1Iiii1I11 ( i1IIIiiII1 ( f , c , t ) , o ) , u ) )
   return O0i1II1Iiii1I11 ( II1I ( e , d ) , f )
   if 58 - 58: IiII
  def iI111i ( e ) :
   O0i1II1Iiii1I11 = len ( e ) ; Iiii = O0i1II1Iiii1I11 + 8 ; oo0o00O = ( Iiii - Iiii % 64 ) / 64 ; i1Iii1i1I = 16 * ( oo0o00O + 1 ) ; i1IIIiiII1 = [ 0 ] * i1Iii1i1I ; O000OOOOOo = 0
   for iiiIi1 in range ( O0i1II1Iiii1I11 ) : II1I = ( iiiIi1 - iiiIi1 % 4 ) / 4 ; O000OOOOOo = 8 * ( iiiIi1 % 4 ) ; i1IIIiiII1 [ II1I ] = i1IIIiiII1 [ II1I ] | IIiIi1iI ( e [ iiiIi1 ] << O000OOOOOo )
   iiiIi1 += 1
   II1I = ( iiiIi1 - iiiIi1 % 4 ) / 4
   O000OOOOOo = 8 * ( iiiIi1 % 4 )
   i1IIIiiII1 [ II1I ] = i1IIIiiII1 [ II1I ] | IIiIi1iI ( 128 << O000OOOOOo )
   i1IIIiiII1 [ i1Iii1i1I - 2 ] = IIiIi1iI ( O0i1II1Iiii1I11 << 3 )
   i1IIIiiII1 [ i1Iii1i1I - 1 ] = IIiIi1iI ( i1IiiiI1iI ( O0i1II1Iiii1I11 , 29 ) )
   return i1IIIiiII1
   if 53 - 53: I1IiiI
  def II1 ( e ) :
   Iiii = [ ]
   for O0i1II1Iiii1I11 in range ( 4 ) :
    II1I = IIiIi1iI ( 255 & i1IiiiI1iI ( e , 8 * O0i1II1Iiii1I11 ) )
    Iiii . append ( II1I )
   return Iiii
   if 59 - 59: o0o
  ooO0OO = O00oO000O0O ( "67452301efcdab8998badcfe10325476d76aa478e8c7b756242070dbc1bdceeef57c0faf4787c62aa8304613fd469501698098d88b44f7afffff5bb1895cd7be6b901122fd987193a679438e49b40821f61e2562c040b340265e5a51e9b6c7aad62f105d02441453d8a1e681e7d3fbc821e1cde6c33707d6f4d50d87455a14eda9e3e905fcefa3f8676f02d98d2a4c8afffa39428771f6816d9d6122fde5380ca4beea444bdecfa9f6bb4b60bebfbc70289b7ec6eaa127fad4ef308504881d05d9d4d039e6db99e51fa27cf8c4ac5665f4292244432aff97ab9423a7fc93a039655b59c38f0ccc92ffeff47d85845dd16fa87e4ffe2ce6e0a30143144e0811a1f7537e82bd3af2352ad7d2bbeb86d391" , 8 )
  I11iiI1i1 = [ ] ; I11iiI1i1 = iI111i ( e ) ; O0O0OOOOoo = ooO0OO [ 0 ] ; oOooO0 = ooO0OO [ 1 ] ; Ii1I1i = ooO0OO [ 2 ] ; OOo0oO00ooO00 = ooO0OO [ 3 ] ; oOoO00O0 = 0
  for oOoO00O0 in range ( 0 , len ( I11iiI1i1 ) , 16 ) :
   OOOO0oo0 = O0O0OOOOoo
   iiI1IiI = oOooO0
   I1i1Iiiii = Ii1I1i
   OOI1iI1ii1II = OOo0oO00ooO00
   O0O0OOOOoo = O000OOOOOo ( O0O0OOOOoo , oOooO0 , Ii1I1i , OOo0oO00ooO00 , I11iiI1i1 [ oOoO00O0 + 0 ] , 7 , ooO0OO [ 4 ] )
   OOo0oO00ooO00 = O000OOOOOo ( OOo0oO00ooO00 , O0O0OOOOoo , oOooO0 , Ii1I1i , I11iiI1i1 [ oOoO00O0 + 1 ] , 12 , ooO0OO [ 5 ] )
   Ii1I1i = O000OOOOOo ( Ii1I1i , OOo0oO00ooO00 , O0O0OOOOoo , oOooO0 , I11iiI1i1 [ oOoO00O0 + 2 ] , 17 , ooO0OO [ 6 ] )
   oOooO0 = O000OOOOOo ( oOooO0 , Ii1I1i , OOo0oO00ooO00 , O0O0OOOOoo , I11iiI1i1 [ oOoO00O0 + 3 ] , 22 , ooO0OO [ 7 ] )
   O0O0OOOOoo = O000OOOOOo ( O0O0OOOOoo , oOooO0 , Ii1I1i , OOo0oO00ooO00 , I11iiI1i1 [ oOoO00O0 + 4 ] , 7 , ooO0OO [ 8 ] )
   OOo0oO00ooO00 = O000OOOOOo ( OOo0oO00ooO00 , O0O0OOOOoo , oOooO0 , Ii1I1i , I11iiI1i1 [ oOoO00O0 + 5 ] , 12 , ooO0OO [ 9 ] )
   Ii1I1i = O000OOOOOo ( Ii1I1i , OOo0oO00ooO00 , O0O0OOOOoo , oOooO0 , I11iiI1i1 [ oOoO00O0 + 6 ] , 17 , ooO0OO [ 10 ] )
   oOooO0 = O000OOOOOo ( oOooO0 , Ii1I1i , OOo0oO00ooO00 , O0O0OOOOoo , I11iiI1i1 [ oOoO00O0 + 7 ] , 22 , ooO0OO [ 11 ] )
   O0O0OOOOoo = O000OOOOOo ( O0O0OOOOoo , oOooO0 , Ii1I1i , OOo0oO00ooO00 , I11iiI1i1 [ oOoO00O0 + 8 ] , 7 , ooO0OO [ 12 ] )
   OOo0oO00ooO00 = O000OOOOOo ( OOo0oO00ooO00 , O0O0OOOOoo , oOooO0 , Ii1I1i , I11iiI1i1 [ oOoO00O0 + 9 ] , 12 , ooO0OO [ 13 ] )
   Ii1I1i = O000OOOOOo ( Ii1I1i , OOo0oO00ooO00 , O0O0OOOOoo , oOooO0 , I11iiI1i1 [ oOoO00O0 + 10 ] , 17 , ooO0OO [ 14 ] )
   oOooO0 = O000OOOOOo ( oOooO0 , Ii1I1i , OOo0oO00ooO00 , O0O0OOOOoo , I11iiI1i1 [ oOoO00O0 + 11 ] , 22 , ooO0OO [ 15 ] )
   O0O0OOOOoo = O000OOOOOo ( O0O0OOOOoo , oOooO0 , Ii1I1i , OOo0oO00ooO00 , I11iiI1i1 [ oOoO00O0 + 12 ] , 7 , ooO0OO [ 16 ] )
   OOo0oO00ooO00 = O000OOOOOo ( OOo0oO00ooO00 , O0O0OOOOoo , oOooO0 , Ii1I1i , I11iiI1i1 [ oOoO00O0 + 13 ] , 12 , ooO0OO [ 17 ] )
   Ii1I1i = O000OOOOOo ( Ii1I1i , OOo0oO00ooO00 , O0O0OOOOoo , oOooO0 , I11iiI1i1 [ oOoO00O0 + 14 ] , 17 , ooO0OO [ 18 ] )
   oOooO0 = O000OOOOOo ( oOooO0 , Ii1I1i , OOo0oO00ooO00 , O0O0OOOOoo , I11iiI1i1 [ oOoO00O0 + 15 ] , 22 , ooO0OO [ 19 ] )
   O0O0OOOOoo = iiiIi1 ( O0O0OOOOoo , oOooO0 , Ii1I1i , OOo0oO00ooO00 , I11iiI1i1 [ oOoO00O0 + 1 ] , 5 , ooO0OO [ 20 ] )
   OOo0oO00ooO00 = iiiIi1 ( OOo0oO00ooO00 , O0O0OOOOoo , oOooO0 , Ii1I1i , I11iiI1i1 [ oOoO00O0 + 6 ] , 9 , ooO0OO [ 21 ] )
   Ii1I1i = iiiIi1 ( Ii1I1i , OOo0oO00ooO00 , O0O0OOOOoo , oOooO0 , I11iiI1i1 [ oOoO00O0 + 11 ] , 14 , ooO0OO [ 22 ] )
   oOooO0 = iiiIi1 ( oOooO0 , Ii1I1i , OOo0oO00ooO00 , O0O0OOOOoo , I11iiI1i1 [ oOoO00O0 + 0 ] , 20 , ooO0OO [ 23 ] )
   O0O0OOOOoo = iiiIi1 ( O0O0OOOOoo , oOooO0 , Ii1I1i , OOo0oO00ooO00 , I11iiI1i1 [ oOoO00O0 + 5 ] , 5 , ooO0OO [ 24 ] )
   OOo0oO00ooO00 = iiiIi1 ( OOo0oO00ooO00 , O0O0OOOOoo , oOooO0 , Ii1I1i , I11iiI1i1 [ oOoO00O0 + 10 ] , 9 , ooO0OO [ 25 ] )
   Ii1I1i = iiiIi1 ( Ii1I1i , OOo0oO00ooO00 , O0O0OOOOoo , oOooO0 , I11iiI1i1 [ oOoO00O0 + 15 ] , 14 , ooO0OO [ 26 ] )
   oOooO0 = iiiIi1 ( oOooO0 , Ii1I1i , OOo0oO00ooO00 , O0O0OOOOoo , I11iiI1i1 [ oOoO00O0 + 4 ] , 20 , ooO0OO [ 27 ] )
   O0O0OOOOoo = iiiIi1 ( O0O0OOOOoo , oOooO0 , Ii1I1i , OOo0oO00ooO00 , I11iiI1i1 [ oOoO00O0 + 9 ] , 5 , ooO0OO [ 28 ] )
   OOo0oO00ooO00 = iiiIi1 ( OOo0oO00ooO00 , O0O0OOOOoo , oOooO0 , Ii1I1i , I11iiI1i1 [ oOoO00O0 + 14 ] , 9 , ooO0OO [ 29 ] )
   Ii1I1i = iiiIi1 ( Ii1I1i , OOo0oO00ooO00 , O0O0OOOOoo , oOooO0 , I11iiI1i1 [ oOoO00O0 + 3 ] , 14 , ooO0OO [ 30 ] )
   oOooO0 = iiiIi1 ( oOooO0 , Ii1I1i , OOo0oO00ooO00 , O0O0OOOOoo , I11iiI1i1 [ oOoO00O0 + 8 ] , 20 , ooO0OO [ 31 ] )
   O0O0OOOOoo = iiiIi1 ( O0O0OOOOoo , oOooO0 , Ii1I1i , OOo0oO00ooO00 , I11iiI1i1 [ oOoO00O0 + 13 ] , 5 , ooO0OO [ 32 ] )
   OOo0oO00ooO00 = iiiIi1 ( OOo0oO00ooO00 , O0O0OOOOoo , oOooO0 , Ii1I1i , I11iiI1i1 [ oOoO00O0 + 2 ] , 9 , ooO0OO [ 33 ] )
   Ii1I1i = iiiIi1 ( Ii1I1i , OOo0oO00ooO00 , O0O0OOOOoo , oOooO0 , I11iiI1i1 [ oOoO00O0 + 7 ] , 14 , ooO0OO [ 34 ] )
   oOooO0 = iiiIi1 ( oOooO0 , Ii1I1i , OOo0oO00ooO00 , O0O0OOOOoo , I11iiI1i1 [ oOoO00O0 + 12 ] , 20 , ooO0OO [ 35 ] )
   O0O0OOOOoo = oo000o ( O0O0OOOOoo , oOooO0 , Ii1I1i , OOo0oO00ooO00 , I11iiI1i1 [ oOoO00O0 + 5 ] , 4 , ooO0OO [ 36 ] )
   OOo0oO00ooO00 = oo000o ( OOo0oO00ooO00 , O0O0OOOOoo , oOooO0 , Ii1I1i , I11iiI1i1 [ oOoO00O0 + 8 ] , 11 , ooO0OO [ 37 ] )
   Ii1I1i = oo000o ( Ii1I1i , OOo0oO00ooO00 , O0O0OOOOoo , oOooO0 , I11iiI1i1 [ oOoO00O0 + 11 ] , 16 , ooO0OO [ 38 ] )
   oOooO0 = oo000o ( oOooO0 , Ii1I1i , OOo0oO00ooO00 , O0O0OOOOoo , I11iiI1i1 [ oOoO00O0 + 14 ] , 23 , ooO0OO [ 39 ] )
   O0O0OOOOoo = oo000o ( O0O0OOOOoo , oOooO0 , Ii1I1i , OOo0oO00ooO00 , I11iiI1i1 [ oOoO00O0 + 1 ] , 4 , ooO0OO [ 40 ] )
   OOo0oO00ooO00 = oo000o ( OOo0oO00ooO00 , O0O0OOOOoo , oOooO0 , Ii1I1i , I11iiI1i1 [ oOoO00O0 + 4 ] , 11 , ooO0OO [ 41 ] )
   Ii1I1i = oo000o ( Ii1I1i , OOo0oO00ooO00 , O0O0OOOOoo , oOooO0 , I11iiI1i1 [ oOoO00O0 + 7 ] , 16 , ooO0OO [ 42 ] )
   oOooO0 = oo000o ( oOooO0 , Ii1I1i , OOo0oO00ooO00 , O0O0OOOOoo , I11iiI1i1 [ oOoO00O0 + 10 ] , 23 , ooO0OO [ 43 ] )
   O0O0OOOOoo = oo000o ( O0O0OOOOoo , oOooO0 , Ii1I1i , OOo0oO00ooO00 , I11iiI1i1 [ oOoO00O0 + 13 ] , 4 , ooO0OO [ 44 ] )
   OOo0oO00ooO00 = oo000o ( OOo0oO00ooO00 , O0O0OOOOoo , oOooO0 , Ii1I1i , I11iiI1i1 [ oOoO00O0 + 0 ] , 11 , ooO0OO [ 45 ] )
   Ii1I1i = oo000o ( Ii1I1i , OOo0oO00ooO00 , O0O0OOOOoo , oOooO0 , I11iiI1i1 [ oOoO00O0 + 3 ] , 16 , ooO0OO [ 46 ] )
   oOooO0 = oo000o ( oOooO0 , Ii1I1i , OOo0oO00ooO00 , O0O0OOOOoo , I11iiI1i1 [ oOoO00O0 + 6 ] , 23 , ooO0OO [ 47 ] )
   O0O0OOOOoo = oo000o ( O0O0OOOOoo , oOooO0 , Ii1I1i , OOo0oO00ooO00 , I11iiI1i1 [ oOoO00O0 + 9 ] , 4 , ooO0OO [ 48 ] )
   OOo0oO00ooO00 = oo000o ( OOo0oO00ooO00 , O0O0OOOOoo , oOooO0 , Ii1I1i , I11iiI1i1 [ oOoO00O0 + 12 ] , 11 , ooO0OO [ 49 ] )
   Ii1I1i = oo000o ( Ii1I1i , OOo0oO00ooO00 , O0O0OOOOoo , oOooO0 , I11iiI1i1 [ oOoO00O0 + 15 ] , 16 , ooO0OO [ 50 ] )
   oOooO0 = oo000o ( oOooO0 , Ii1I1i , OOo0oO00ooO00 , O0O0OOOOoo , I11iiI1i1 [ oOoO00O0 + 2 ] , 23 , ooO0OO [ 51 ] )
   O0O0OOOOoo = OOOOoOoo0O0O0 ( O0O0OOOOoo , oOooO0 , Ii1I1i , OOo0oO00ooO00 , I11iiI1i1 [ oOoO00O0 + 0 ] , 6 , ooO0OO [ 52 ] )
   OOo0oO00ooO00 = OOOOoOoo0O0O0 ( OOo0oO00ooO00 , O0O0OOOOoo , oOooO0 , Ii1I1i , I11iiI1i1 [ oOoO00O0 + 7 ] , 10 , ooO0OO [ 53 ] )
   Ii1I1i = OOOOoOoo0O0O0 ( Ii1I1i , OOo0oO00ooO00 , O0O0OOOOoo , oOooO0 , I11iiI1i1 [ oOoO00O0 + 14 ] , 15 , ooO0OO [ 54 ] )
   oOooO0 = OOOOoOoo0O0O0 ( oOooO0 , Ii1I1i , OOo0oO00ooO00 , O0O0OOOOoo , I11iiI1i1 [ oOoO00O0 + 5 ] , 21 , ooO0OO [ 55 ] )
   O0O0OOOOoo = OOOOoOoo0O0O0 ( O0O0OOOOoo , oOooO0 , Ii1I1i , OOo0oO00ooO00 , I11iiI1i1 [ oOoO00O0 + 12 ] , 6 , ooO0OO [ 56 ] )
   OOo0oO00ooO00 = OOOOoOoo0O0O0 ( OOo0oO00ooO00 , O0O0OOOOoo , oOooO0 , Ii1I1i , I11iiI1i1 [ oOoO00O0 + 3 ] , 10 , ooO0OO [ 57 ] )
   Ii1I1i = OOOOoOoo0O0O0 ( Ii1I1i , OOo0oO00ooO00 , O0O0OOOOoo , oOooO0 , I11iiI1i1 [ oOoO00O0 + 10 ] , 15 , ooO0OO [ 58 ] )
   oOooO0 = OOOOoOoo0O0O0 ( oOooO0 , Ii1I1i , OOo0oO00ooO00 , O0O0OOOOoo , I11iiI1i1 [ oOoO00O0 + 1 ] , 21 , ooO0OO [ 59 ] )
   O0O0OOOOoo = OOOOoOoo0O0O0 ( O0O0OOOOoo , oOooO0 , Ii1I1i , OOo0oO00ooO00 , I11iiI1i1 [ oOoO00O0 + 8 ] , 6 , ooO0OO [ 60 ] )
   OOo0oO00ooO00 = OOOOoOoo0O0O0 ( OOo0oO00ooO00 , O0O0OOOOoo , oOooO0 , Ii1I1i , I11iiI1i1 [ oOoO00O0 + 15 ] , 10 , ooO0OO [ 61 ] )
   Ii1I1i = OOOOoOoo0O0O0 ( Ii1I1i , OOo0oO00ooO00 , O0O0OOOOoo , oOooO0 , I11iiI1i1 [ oOoO00O0 + 6 ] , 15 , ooO0OO [ 62 ] )
   oOooO0 = OOOOoOoo0O0O0 ( oOooO0 , Ii1I1i , OOo0oO00ooO00 , O0O0OOOOoo , I11iiI1i1 [ oOoO00O0 + 13 ] , 21 , ooO0OO [ 63 ] )
   O0O0OOOOoo = OOOOoOoo0O0O0 ( O0O0OOOOoo , oOooO0 , Ii1I1i , OOo0oO00ooO00 , I11iiI1i1 [ oOoO00O0 + 4 ] , 6 , ooO0OO [ 64 ] )
   OOo0oO00ooO00 = OOOOoOoo0O0O0 ( OOo0oO00ooO00 , O0O0OOOOoo , oOooO0 , Ii1I1i , I11iiI1i1 [ oOoO00O0 + 11 ] , 10 , ooO0OO [ 65 ] )
   Ii1I1i = OOOOoOoo0O0O0 ( Ii1I1i , OOo0oO00ooO00 , O0O0OOOOoo , oOooO0 , I11iiI1i1 [ oOoO00O0 + 2 ] , 15 , ooO0OO [ 66 ] )
   oOooO0 = OOOOoOoo0O0O0 ( oOooO0 , Ii1I1i , OOo0oO00ooO00 , O0O0OOOOoo , I11iiI1i1 [ oOoO00O0 + 9 ] , 21 , ooO0OO [ 67 ] )
   O0O0OOOOoo = O0i1II1Iiii1I11 ( O0O0OOOOoo , OOOO0oo0 )
   oOooO0 = O0i1II1Iiii1I11 ( oOooO0 , iiI1IiI )
   Ii1I1i = O0i1II1Iiii1I11 ( Ii1I1i , I1i1Iiiii )
   OOo0oO00ooO00 = O0i1II1Iiii1I11 ( OOo0oO00ooO00 , OOI1iI1ii1II )
  return II1 ( O0O0OOOOoo ) + II1 ( oOooO0 ) + II1 ( Ii1I1i ) + II1 ( OOo0oO00ooO00 )
  if 75 - 75: IiII . iIii1 . OO0OO0O0O0 * O00OoOoo00
  if 4 - 4: ooo0Oo0 % i11Ii11I1Ii1i * ooOoO0o
 def o0O0OOOOoOO0 ( b ) :
  def iiO0oOo00o ( s ) :
   O000OOO , OOOOoOoo0O0O0 , s , ooOOoooooo = s . split ( ',' )
   i1IIIiiII1 = iI111i = oo0o00O = 0 ; iiiIi1 = [ ] ; Iiii = [ ]
   while True :
    if i1IIIiiII1 < 5 : Iiii . append ( O000OOO [ i1IIIiiII1 ] )
    elif i1IIIiiII1 < len ( O000OOO ) : iiiIi1 . append ( O000OOO [ i1IIIiiII1 ] )
    i1IIIiiII1 += 1
    if 81 - 81: OOooo0000ooo % I1IiiI . iiiIIii1IIi
    if iI111i < 5 : Iiii . append ( OOOOoOoo0O0O0 [ iI111i ] )
    elif iI111i < len ( OOOOoOoo0O0O0 ) : iiiIi1 . append ( OOOOoOoo0O0O0 [ iI111i ] )
    iI111i += 1
    if 4 - 4: Oo0Ooo % ooOoO0o % I1IiiI / OOooo0000ooo
    if oo0o00O < 5 : Iiii . append ( s [ oo0o00O ] )
    elif oo0o00O < len ( s ) : iiiIi1 . append ( s [ oo0o00O ] )
    oo0o00O += 1
    if 6 - 6: i1 / IiII % ooO - IiII
    if len ( O000OOO ) + len ( OOOOoOoo0O0O0 ) + len ( s ) + len ( ooOOoooooo ) == len ( iiiIi1 ) + len ( Iiii ) + len ( ooOOoooooo ) : break
    if 31 - 31: ooO
   oOooO0 = '' . join ( s for s in iiiIi1 ) ; ooO0OO = '' . join ( s for s in Iiii ) ; iI111i = 0 ; O000OOOOOo = [ ]
   for i1IIIiiII1 in range ( 0 , len ( iiiIi1 ) , 2 ) :
    O0i1II1Iiii1I11 = - 1
    if ord ( ooO0OO [ iI111i ] ) % 2 : O0i1II1Iiii1I11 = 1
    O000OOOOOo . append ( chr ( int ( oOooO0 [ i1IIIiiII1 : i1IIIiiII1 + 2 ] , 36 ) - O0i1II1Iiii1I11 ) )
    iI111i += 1
    if iI111i >= len ( Iiii ) : iI111i = 0
   return '' . join ( s for s in O000OOOOOo )
  oOoO00O0 = 0
  while oOoO00O0 < 5 or 'decodeLink' not in b :
   try : b = iiO0oOo00o ( O0OOO ( "(\w{100,},\w+,\w+,\w+)" , b . replace ( "'" , '' ) ) ) ; oOoO00O0 += 1
   except : break
  return b
  if 23 - 23: O00OoOoo00 . OOooo0000ooo
 return oOOoO0o0oO ( string , key ) if key else o0O0OOOOoOO0 ( string )
 if 92 - 92: o00O0oo + O00OoOoo00 * ooo0Oo0 % IiII
ii = xbmc . translatePath ( 'special://userdata' )
oOOo = os . path . join ( ii , 'search.p' )
if 42 - 42: I1Ii111
oOoO0o00OO0 = os . path . join ( ii , 'cid' )
if not os . path . exists ( oOoO0o00OO0 ) :
 with open ( oOoO0o00OO0 , "w" ) as Iiii :
  Iiii . write ( str ( uuid . uuid1 ( ) ) )
  if 76 - 76: IiII * i1 % O00OoOoo00
if __name__ == '__main__' :
 oo000 . run ( ) # dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
