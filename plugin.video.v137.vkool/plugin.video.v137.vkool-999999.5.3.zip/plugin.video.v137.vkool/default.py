#!/usr/bin/python
# -*- coding: utf-8 -*-
OFFLINE = False
DEBUG = False

from v137 import v137

def Index(baseUrl, viewMode, page=1):
	if not '.html' in baseUrl:
		baseUrl = '%s/%s.html' % (baseUrl.rstrip('/'), page)
	elif '%s' in baseUrl:
		baseUrl = baseUrl % page
	soup = v137.Request(baseUrl, soup=True)
	if DEBUG:
		videos = soup.select('.movie-item')     # MATCHING DEBUG LINES
	else:
		try:
			videos = soup.select('.movie-item')  # MATCHING DEBUG LINES
		except:
			videos = []
	count = 0
	for video in videos:
		if DEBUG:
			# MATCHING DEBUG LINES
			vurl, name, vicon, vname = Items(baseUrl, video)
			vmore = [(COLOUR1 % v137.language[LANG]['TRYBROWSER'],
			          'StartAndroidActivity("","android.intent.action.VIEW","","%s")' % vurl)]     #
			#
			count += v137.AddItem('INFO', vurl, name, vicon, vname=vname, context=vmore)
		else:
			try:
				# MATCHING DEBUG LINES
				vurl, name, vicon, vname = Items(baseUrl, video)
				vmore = [(COLOUR1 % v137.language[LANG]['TRYBROWSER'],
				          'StartAndroidActivity("","android.intent.action.VIEW","","%s")' % vurl)]
				#
				count += v137.AddItem('INFO', vurl, name, vicon,
				                      vname=vname, context=vmore)
			except Exception, e:
				v137.Log('| ITEM ERROR | %s' % e)
	if DEBUG:
		Pagination(baseUrl, page, soup, viewMode)     # MATCHING DEBUG LINES
	else:
		try:
			Pagination(baseUrl, page, soup, viewMode)  # MATCHING DEBUG LINES
		except Exception, e:
			v137.Log('| PAGINATION ERROR | %s' % e)
	if DEBUG:
		v137.Log('| %s ITEM(S) |' % count)
	if not count:
		v137.AddItem(None, None, COLOUR1 %
		             v137.language[LANG]['NOTFOUND'], v137.icons['WARNING'], folder=False)
		v137.AddItem(None, None, COLOUR1 %
		             v137.language[LANG]['NOTFOUND2'], v137.icons['WARNING'], folder=False)
	v137.EndItems(contentType=DEFAULTTYPE, viewMode=viewMode)


def Items(baseUrl, soup):
	link = soup.find('a')['href'].strip()
	link = v137.FormatUrl(link, baseUrl)
	name1 = soup.find('span', class_='movie-title-1').text.strip().encode('utf-8')
	name2 = soup.find('span', class_='movie-title-2').text.strip().encode('utf-8')
	try:
		label = soup.find('span', class_='ribbon').text.strip().encode('utf-8')
		name = '%s %s %s' % (COLOUR1 % name1, COLOUR2 %
		                     '(%s)' % label, COLOUR3 % name2)
	except:
		name = '%s %s %s' % (COLOUR1 % name1, COLOUR2 % '/', COLOUR3 % name2)
	vname = '%s / %s' % (name1, name2)
	try:
		icon = soup.find('div', class_='movie-thumbnail')['style']
		icon = v137.Regex('\(([^\)]*)\)', icon)[0].strip()
		icon = v137.FormatUrl(icon, baseUrl)
	except:
		icon = v137.ICON
	return link, name, icon, vname


def Pagination(baseUrl, page, soup, viewMode):
	pagination = soup.find('ul', class_='pagination')
	if 'LAST &rarr;' in str(pagination) or 'LAST →' in str(pagination):
		page = int(v137.Regex('/(\d+)\.html', baseUrl)[0])
		plink = v137.Resub('%s.html' % str(page), '%s.html' %
		                   str(page+1), baseUrl, count=1)
		pname = COLOUR2 % '%s >>' % v137.language[LANG]['NEXT']
		v137.AddItem('INDEX', plink, pname, v137.icons['LAST_PAGE'], extra3=viewMode)


def Submenus(baseUrl, name, icon):
	soup = v137.Request(baseUrl, soup=True)
	if DEBUG:
		menus = soup.find(id='mega-menu-1').select('ul')     # MATCHING DEBUG LINES
	else:
		try:
			menus = soup.find(id='mega-menu-1').select('ul')  # MATCHING DEBUG LINES
		except:
			menus = links = []
	for menu in menus:
		title = menu.previous.encode('utf-8')
		if title.lower() in name.lower():
			links = menu.select('li')
	count = 0
	for link in links:
		cname = COLOUR1 % (link.text.strip().encode('utf-8'))
		clink = link.a['href'].encode('utf-8')
		count += v137.AddItem('INDEX', clink, cname, icon)
	if not count:
		v137.AddItem(None, None, COLOUR1 %
		             v137.language[LANG]['NOTFOUND'], v137.icons['WARNING'], folder=False)
		v137.AddItem(None, None, COLOUR1 %
		             v137.language[LANG]['NOTFOUND2'], v137.icons['WARNING'], folder=False)
	v137.EndItems(contentType=DEFAULTTYPE, viewMode=DEFAULTVIEW)


def Info(baseUrl, vname, icon):
	html = v137.Request(baseUrl)
	soup = v137.Soup(html)
	if DEBUG:
		title, thumb, info, plot, fanart, trailer = InfoData(
			baseUrl, html)     # MATCHING DEBUG LINES
	else:
		try:
			title, thumb, info, plot, fanart, trailer = InfoData(
				baseUrl, html)  # MATCHING DEBUG LINES
		except Exception, e:
			v137.Log('| INFO ERROR | %s' % e)
			title = None
	if title:
		prompt = v137.Info(title, thumb, info, plot, fanart, trailer, lang=LANG)
		if prompt == 'PLAY':
			if v137.AdultCheck(info):
				Servers(baseUrl, vname, icon, html)
	else:
		Servers(baseUrl, vname, icon, html)


def InfoData(baseUrl, html):
	soup = v137.Soup(html)
	title = soup.find('meta', property='og:title')[
            'content'].lstrip('Phim').strip()
	thumb = soup.find('meta', property='og:image')['content']
	thumb = v137.FormatUrl(thumb, baseUrl)
	info = ''
	metas = soup.find(class_='movie-meta-info').find_all('dt')
	for meta in metas:
		info = info + ('%s %s' % (COLOUR2 % meta.text, COLOUR1 %
                            meta.find_next_sibling('dd').text)) + '\n'
	plot = COLOUR1 % soup.find(class_='content').text
	try:
		trailer = v137.Regex('gkpluginsphp\("vkool_trailer",{(.+?)}\)', html)[0]
		trailer = v137.LinkFinder(trailer)
	except:
		trailer = None
	return title, thumb, info, plot, FANART, trailer


def Servers(baseUrl, vname, icon, html=None):
	if not html:
		html = v137.Request(baseUrl)
	soup = v137.Soup(html)
	try:
		slink = soup.find(id='btn-film-watch')['href'].strip()
		slink = v137.FormatUrl(slink, baseUrl)
		html = v137.Request(slink, referer=baseUrl)
		soup = v137.Soup(html)
	except Exception, e:
		v137.Log('| WATCH BUTTON ERROR | %s' % e)
		slink = baseUrl
#	if '#list_episodes {display: none;}' in str(soup):
#		servers = []
#	else:
	if DEBUG:
		servers = soup.find_all(class_='listserver')     # MATCHING DEBUG LINES
	else:
		try:
			servers = soup.find_all(class_='listserver')  # MATCHING DEBUG LINES
		except:
			servers = []
	count = 0
	for server in servers:
		sname = server.find(class_='name').text.strip().encode('utf-8')
		sname = '%s %s' % (COLOUR2 % '%s:' % v137.language[LANG]['SERVER'], COLOUR1 % sname.replace(
			'Server', ''). replace(':', '').strip().upper())
		smore = [(COLOUR1 % v137.language[LANG]['TRYBROWSER'],
		          'StartAndroidActivity("","android.intent.action.VIEW","","%s")' % slink)]
		if len(servers) > 1:
			count += v137.AddItem('EPISODES', slink, sname, icon,
			                      vname=vname, html=server, context=smore)
		else:
			count = 1
	if DEBUG:
		v137.Log('| %s SERVER(S) |' % count)
	if count == 0:
		Episodes(slink, name, icon, html)
	elif count == 1:
		Episodes(slink, name, icon, html)
	else:
		v137.EndItems(contentType=DEFAULTTYPE, viewMode=DEFAULTVIEW)


def Episodes(baseUrl, vname, icon, html=None):
	if not html:
		html = v137.Request(baseUrl)
	soup = v137.Soup(html)
	if DEBUG:
		if 'episode_list' in str(soup):
			episodes = soup.find(class_='episode_list')     # MATCHING DEBUG LINES
		else:                                               #
			episodes = soup.find(class_='listserver')       #
		episodes = episodes.find_all('a')                   #
	else:
		try:
			if 'episode_list' in str(soup):                 # MATCHING DEBUG LINES
				episodes = soup.find(class_='episode_list')
			else:                                           #
				episodes = soup.find(class_='listserver')   #
			episodes = episodes.find_all('a')               #
		except:
			episodes = []
	count = 0
	for episode in episodes:
		ename = episode.text.strip().encode('utf-8')
		if not 'download' in ename.lower():
			ename = '%s %s' % (COLOUR2 % '%s:' %
			                   v137.language[LANG]['EPISODE'], COLOUR1 % ename)
			elink = episode['href'].strip()
			elink = v137.FormatUrl(elink, SITEURL)
			emore = [(COLOUR1 % v137.language[LANG]['TRYBROWSER'],
			          'StartAndroidActivity("","android.intent.action.VIEW","","%s")' % elink)]
			if len(episodes) > 1:
				count += v137.AddItem('LOAD', elink, ename, icon,
				                      vname=vname, context=emore)
			else:
				count = 1
	if DEBUG:
		v137.Log('| %s EPISODE(S) |' % count)
	if count == 0:
		Load(baseUrl, vname, icon)
	elif count == 1:
		Load(elink, vname, icon)
	else:
		v137.EndItems(contentType=DEFAULTTYPE, viewMode=DEFAULTVIEW)


def Links(baseUrl, vname, icon, html=None, userAgent=v137.userAgent_iPad):
	baseUrl = baseUrl.replace(SITEDOMAIN, SITEDOMAIN2)
	if not html:
		html = v137.Request(baseUrl, userAgent=userAgent)
	soup = v137.Soup(html)
	links = {}
	if 'curplay:' in html:
		links['main'] = v137.Regex('curplay:"([^"]*)"', html)[0]
	elif 'gklist:' in html:
		links['main'] = v137.Regex('gklist:"([^"]*)"', html)[0]
	elif 'link:' in html:
		links['main'] = v137.Regex('link:"([^"]*)"', html)[0]
	else:
		if DEBUG:
			v137.Log('| HTML | %s' % html)
		links['main'] = ''
	if 'window.onerr =' in html:
		links['backup'] = v137.Regex('window.onerr = "([^"]*)"', html)[0]
	if DEBUG:
		v137.Log('| Main Link | %s' % links['main'])
	if DEBUG:
		v137.Log('| Backup Link | %s' % links['backup'])

	for link in links:
		if '://' in links[link]:
			xml = v137.Request(link, userAgent=userAgent,
			                   referer=baseUrl, soup=True, parser='html5lib')
			link2 = xml.find_all('location')[0]
			link2 = v137.Regex('CDATA\[([^\]]*)\]', str(link2))[0]
		else:
			link2 = links[link]
		links2 = []
		data = v137.Request('http://vkool.net/js/vkphp/plugins/gkpluginsphp.php',
		                    post=True, data={'link': link2}, userAgent=userAgent, referer=baseUrl)
		if DEBUG:
			v137.Log('| Data | %s' % data)
		if 'label' in data:
			try:
				sources = v137.JSON(data)['link']
			except:
				sources = []
			if sources:
				for source in sources:
					links2.append((source['label'], source['link']))
				if DEBUG:
					src = v137.ChooseRes(links2, maxres=-1)
				else:
					src = v137.ChooseRes(links2, maxres=15)
				src = v137.Decode(src, '', d=SITEDOMAIN, index=678)
		else:
			src = v137.LinkFinder(data, baseUrl)
		if src:
			status = v137.Request(src, userAgent=userAgent,
			                      referer=baseUrl, getStatus=True)
			if status < 400:
				break

	if src:
		return '%s|Referer=%s' % (src, baseUrl)
	else:
		return None


def Load(baseUrl, vname, icon, html=None):
	link = None
	if DEBUG:
		link = Links(baseUrl, vname, icon, html)     # MATCHING DEBUG LINES
	else:
		try:
			link = Links(baseUrl, vname, icon, html)  # MATCHING DEBUG LINES
		except Exception, e:
			v137.Log('| RESOLVE ERROR | %s' % e)
	if link:
		Play(link, vname, icon)
	else:
		v137.OK(v137.language[LANG]['SORRY'], v137.language[LANG]['CANNOTPLAY'])


def Play(baseUrl, vname, icon):
	url = v137.Resolver(baseUrl, name=vname, icon=icon, lang=LANG)
	player = v137.Player(url, vname, icon)
	return player


def Openload(baseUrl, name, icon, html):
	if html:
		v137.Openload(baseUrl, name, icon, html)
	else:
		url = v137.UrlResolver(baseUrl, lang=LANG)
		if url:
			Play(url, name, icon)


# #################################################################################################### #


if __name__ == '__main__':

	if v137.Android:
		DEBUG = False

	SITENAME = 'VKool'
	SITEDOMAIN = 'vkool.net'
	SITEDOMAIN2 = 'm.vkool.net'
	SITEURL = 'http://vkool.net'
	SITEURL2 = 'http://m.vkool.net'  # User for LINKS()
	SEARCHURL = '/search/%s'
	FANART = ''
	COLOUR1 = '[COLOR white][B]%s[/B][/COLOR]'
	COLOUR2 = '[COLOR deepskyblue][B]%s[/B][/COLOR]'
	COLOUR3 = '[COLOR lightblue][B]%s[/B][/COLOR]'
	COLOUR9 = '[COLOR yellow][B]%s[/B][/COLOR]'
	LANG = 'VI'
	DEFAULTVIEW = v137.listView
	THUMBVIEW = v137.posterView
	DEFAULTTYPE = 'Movies'

	mode, link, name, icon, vname, extra, extra2, extra3, html = v137.Parameters()
	if DEBUG:
		v137.Log('| Mode   | %s' % mode)
		v137.Log('| Link   | %s' % link)
		v137.Log('| Name   | %s' % name)
		v137.Log('| Icon   | %s' % icon)
		v137.Log('| vName  | %s' % vname)
		v137.Log('| Extra  | %s' % extra)
#		v137.Log('| HTML   | %s' % html)

	if not mode:
		if OFFLINE:
			v137.Offline(lang=LANG)
		v137.AddItem('INDEX',    SITEURL + '/list/new/',                 COLOUR2 %
		             'Phim Mới',       v137.icons['FIBER_NEW'],    FANART, extra3=DEFAULTVIEW)
		v137.AddItem('INDEX',    SITEURL + '/list/phim-le/',             COLOUR1 %
		             'Phim Lẻ Mới',    v137.icons['MOVIE'],        FANART, extra3=THUMBVIEW)
		v137.AddItem('INDEX',    SITEURL + '/list/phim-bo/',             COLOUR1 %
		             'Phim Bộ Mới',    v137.icons['MOVIE_FILTER'], FANART, extra3=DEFAULTVIEW)
		v137.AddItem('INDEX',    SITEURL + '/list/phim-hd/',             COLOUR1 %
		             'Phim HD',        v137.icons['HD'],           FANART, extra3=DEFAULTVIEW)
		v137.AddItem('INDEX',    SITEURL + '/list/phim-dang-chieu-rap/', COLOUR1 %
		             'Phim Chiếu Rạp', v137.icons['THEATERS'],     FANART, extra3=THUMBVIEW)
		v137.AddItem('INDEX',    SITEURL + '/list/phim-top-imdb/',       COLOUR1 %
		             'Phim Top IMDB',  v137.icons['FIBER_NEW'],    FANART, extra3=DEFAULTVIEW)
		v137.AddItem('SUBMENUS', SITEURL,                                COLOUR1 %
		             '+ Thể Loại',     v137.icons['BOOK'],         FANART, extra3=DEFAULTVIEW)
		v137.AddItem('SUBMENUS', SITEURL,                                COLOUR1 %
		             '+ Quốc Gia',     v137.icons['LANGUAGE'],     FANART, extra3=DEFAULTVIEW)
		v137.AddItem('SEARCH',   SITEURL + SEARCHURL,                    COLOUR2 %
		             '[ Tìm Kiếm ]',   v137.icons['SEARCH'],       FANART, extra3=DEFAULTVIEW)
		v137.EndItems(contentType='Files', viewMode=v137.listView)

		v137.DefineSettings(settingsXML='Bare')

	elif mode == 'INDEX':
		Index(link, extra3)
	elif mode == 'SUBMENUS':
		Submenus(link, name, icon)
	elif mode == 'INFO':
		Info(link, vname, icon)
	elif mode == 'SERVERS':
		Servers(link, vname, icon)
	elif mode == 'EPISODES':
		Episodes(link, vname, icon, html)
	elif mode == 'LOAD':
		Load(link, vname, icon)
	elif mode == 'PLAY':
		Play(link, vname, icon)
	elif mode == 'OPENLOAD':
		Openload(link, name, icon, html)
	elif mode == 'SEARCH':
		link = v137.Search(link, extra, extra2, colour=COLOUR2, lang=LANG)
		if link:
			Index(link, extra3)
		Episodes(link, vname, icon, html)
	elif mode == 'LOAD':
		Load(link, vname, icon)
	elif mode == 'PLAY':
		Play(link, vname, icon)
	elif mode == 'OPENLOAD':
		Openload(link, name, icon, html)
	elif mode == 'SEARCH':
		link = v137.Search(link, extra, extra2, colour=COLOUR2, lang=LANG)
		if link:
			Index(link, extra3)
