﻿#!/usr/bin/python
# coding=utf-8
import urllib , requests , re , json , HTMLParser , os , uuid
from xbmcswift2 import Plugin , xbmc , xbmcgui , xbmcaddon
requests . packages . urllib3 . disable_warnings ( )
oo000 = Plugin ( )
ii = HTMLParser . HTMLParser ( )
oOOo = "plugin://plugin.video.thietkeweb30s.org.fpt-play"
if 59 - 59: Oo0Ooo . OO0OO0O0O0 * iiiIIii1IIi . iII111iiiii11 % I1IiiI
IIi1IiiiI1Ii = "https://fptplay.net/show/getlinklivetv"
I11i11Ii = "https://fptplay.net/tro-giup/bao-loi"
oO00oOo = "https://fptplay.net/show/getlink"
OOOo0 = 30
if 54 - 54: i1 - o0 * i1oOo0OoO * iIIIiiIIiiiIi % Oo
o0O = {
 'X-Requested-With' : 'XMLHttpRequest' ,
 'User-Agent' : 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.106 Safari/537.36' ,
 'Content-Type' : 'application/x-www-form-urlencoded; charset=UTF-8' ,
 'Accept-Encoding' : 'gzip, deflate' ,
 'Referer' : 'http://fptplay.net/livetv'
 }
if 48 - 48: iII111i % IiII + I1Ii111 / ooOoO0o * o00O0oo
def O0oOO0o0 ( s ) :
 s = '' . join ( s . splitlines ( ) ) . replace ( '\'' , '"' )
 s = s . replace ( '\n' , '' )
 s = s . replace ( '\t' , '' )
 s = re . sub ( '  +' , ' ' , s )
 s = s . replace ( '> <' , '><' )
 return ii . unescape ( s )
 if 9 - 9: o0o - OOO0o0o
@ oo000 . route ( '/eps/<sid>' )
def Ii1iI ( sid ) :
 #OoI1Ii11I1Ii1i ( "Browse eps by id %s" % sid , "/eps/%s" % sid )
 Ooo = requests . get ( "https://fptplay.net/xem-video/-%s.html" % sid , headers = o0O )
 Ooo . encoding = "utf-8"
 o0oOoO00o = O0oOO0o0 ( Ooo . text ) . encode ( "utf8" )
 i1oOOoo00O0O = 1
 i1111 = re . compile ( 'Số tập\: </span>(\d+) tập</p>' ) . findall ( o0oOoO00o )
 i11 = [ ]
 if len ( i1111 ) > 0 :
  i1oOOoo00O0O = int ( i1111 [ 0 ] )
  print i1oOOoo00O0O
 I11 = re . compile ( '<title>FPT Play - Xem video (.+?)</title>' ) . findall ( o0oOoO00o ) [ 0 ]
 if i1oOOoo00O0O == 1 :
  Oo0o0000o0o0 = { }
  Oo0o0000o0o0 [ "label" ] = "Xem %s" % I11
  Oo0o0000o0o0 [ "path" ] = "%s/play/%s/%s" % ( oOOo , sid , "1" )
  Oo0o0000o0o0 [ "is_playable" ] = True
  i11 . append ( Oo0o0000o0o0 )
 else :
  for oOo0oooo00o in range ( 1 , i1oOOoo00O0O + 1 ) :
   Oo0o0000o0o0 = { }
   Oo0o0000o0o0 [ "label" ] = "Xem %s - Tập %s" % ( I11 , oOo0oooo00o )
   Oo0o0000o0o0 [ "path" ] = "%s/play/%s/%s" % ( oOOo , sid , oOo0oooo00o )
   Oo0o0000o0o0 [ "is_playable" ] = True
   i11 . append ( Oo0o0000o0o0 )
 return oo000 . finish ( i11 )
 if 65 - 65: O0o * i1iIIII * I1
@ oo000 . route ( '/list/<order>/<s_id>/<page>' )
def list ( order = "new" , s_id = "" , page = "1" ) :
 #OoI1Ii11I1Ii1i ( "Browse new videos by id %s" % s_id , "/list/%s/%s/%s" % ( order , s_id , page ) )
 O0OoOoo00o = requests . Session ( )
 Ooo = O0OoOoo00o . get ( I11i11Ii , headers = o0O )
 Ooo . encoding = "utf-8"
 o0oOoO00o = O0oOO0o0 ( Ooo . text ) . encode ( "utf8" )
 try :
  iiiI11 = re . compile ( 'name="_token" content="(.+?)"' ) . findall ( o0oOoO00o ) [ 0 ]
  o0O [ "X-CSRF-Token" ] = iiiI11
 except :
  pass
 OOooO = {
 'type' : order ,
 'stucture_id' : s_id ,
 'page' : page ,
 'keyword' : 'undefined'
 }
 Ooo = O0OoOoo00o . post ( "https://fptplay.net/show/more" , headers = o0O , data = OOooO )
 Ooo . encoding = "utf-8"
 o0oOoO00o = O0oOO0o0 ( Ooo . text ) . encode ( "utf8" )
 i1111 = re . compile ( '<a href=".+?-(\w+).html" ><img[^>]*src="(.+?)"[^>]*alt="(.+?)"' ) . findall ( o0oOoO00o )
 i11 = [ ]
 for OOoO00o , II111iiii , I11 in i1111 :
  Oo0o0000o0o0 = { }
  Oo0o0000o0o0 [ "label" ] = I11
  Oo0o0000o0o0 [ "path" ] = "%s/eps/%s" % ( oOOo , OOoO00o )
  Oo0o0000o0o0 [ "thumbnail" ] = II111iiii
  i11 . append ( Oo0o0000o0o0 )
 if len ( i11 ) == OOOo0 :
  Oo0o0000o0o0 = { }
  Oo0o0000o0o0 [ "label" ] = "Next >>"
  Oo0o0000o0o0 [ "path" ] = "%s/list/%s/%s/%s" % ( oOOo , order , s_id , int ( page ) + 1 )
  Oo0o0000o0o0 [ "thumbnail" ] = "http://icons.iconarchive.com/icons/rafiqul-hassan/blogger/128/Arrow-Next-icon.png"
  i11 . append ( Oo0o0000o0o0 )
 if oo000 . get_setting ( 'thumbview' , bool ) :
  if xbmc . getSkinDir ( ) in ( 'skin.confluence' , 'skin.eminence' ) :
   return oo000 . finish ( i11 , view_mode = 500 )
  elif xbmc . getSkinDir ( ) == 'skin.xeebo' :
   return oo000 . finish ( i11 , view_mode = 52 )
  else :
   return oo000 . finish ( i11 )
 else :
  return oo000 . finish ( i11 )
  if 48 - 48: iIIIiiIIiiiIi . iII111iiiii11 - Oo % ooOoO0o / o0o . o0o
@ oo000 . route ( '/live' )
def i1Ii ( ) :
 #OoI1Ii11I1Ii1i ( "Browse Live Channels" , "/live" )
 I111I11 = "https://fptplay.net/livetv"
 Ooo = requests . get ( I111I11 , headers = o0O )
 Ooo . encoding = "utf-8"
 o0oOoO00o = O0oOO0o0 ( Ooo . text )
 i1111 = re . compile ( 'onclick="getLivetv\(\$\(this\)\)" data-href="(.+?)"[^>]*><img class="lazy" data-original="(.+?)"[^>]*title="(.+?)"' ) . findall ( o0oOoO00o )
 i11 = [ ]
 for IIi1IiiiI1Ii , II111iiii , I11 in i1111 :
  Oo0o0000o0o0 = { }
  Oo0o0000o0o0 [ "label" ] = I11
  Oo0o0000o0o0 [ "path" ] = "%s/play/%s" % ( oOOo , urllib . quote_plus ( IIi1IiiiI1Ii . encode ( "utf8" ) ) )
  Oo0o0000o0o0 [ "is_playable" ] = True
  Oo0o0000o0o0 [ "thumbnail" ] = II111iiii
  i11 . append ( Oo0o0000o0o0 )
 if oo000 . get_setting ( 'thumbview' , bool ) :
  if xbmc . getSkinDir ( ) in ( 'skin.confluence' , 'skin.eminence' ) :
   return oo000 . finish ( i11 , view_mode = 500 )
  elif xbmc . getSkinDir ( ) == 'skin.xeebo' :
   return oo000 . finish ( i11 , view_mode = 52 )
  else :
   return oo000 . finish ( i11 )
 else :
  return oo000 . finish ( i11 )
  if 62 - 62: OOO0o0o - O0o - Oo % I1IiiI / I1Ii111
@ oo000 . route ( '/play/<url>' , name = "play_firsteps" )
@ oo000 . route ( '/play/<url>/<eps>' )
def OoooooOoo ( url , eps = "1" ) :
 #OoI1Ii11I1Ii1i ( "Play %s" % url , "/play/%s/%s" % ( url , eps ) )
 OO = xbmcgui . DialogProgress ( )
 OO . create ( 'FPTPlay.net' , 'Loading video. Please wait...' )
 oo000 . set_resolved_url ( oO0O ( url , eps ) )
 OO . close ( )
 del OO
 if 70 - 70: i1oOo0OoO % i1oOo0OoO . O0o % iIIIiiIIiiiIi * iII111i % I1Ii111
def oO0O ( url , ep_id = "1" ) :
 O0OoOoo00o = requests . Session ( )
 if "/livetv" in url or "/event" in url :
  Ooo = O0OoOoo00o . get ( url , headers = o0O )
  Ooo . encoding = "utf-8"
  o0oOoO00o = O0oOO0o0 ( Ooo . text ) . encode ( "utf8" )
  iiI1IiI = re . compile ( 'showAlert\("(.+?)"' ) . findall ( o0oOoO00o ) [ 0 ]
  try :
   iiiI11 = re . compile ( 'name="_token" content="(.+?)"' ) . findall ( o0oOoO00o ) [ 0 ]
   o0O [ "X-CSRF-Token" ] = iiiI11
  except :
   pass
  OOooO = {
 'id' : iiI1IiI ,
 'type' : 'newchannel' ,
 'quality' : '3' ,
 'mobile' : 'web'
 }
  return O0OoOoo00o . post ( IIi1IiiiI1Ii , headers = o0O , data = OOooO ) . json ( ) [ "stream" ]
 else :
  Ooo = O0OoOoo00o . get ( I11i11Ii , headers = o0O )
  Ooo . encoding = "utf-8"
  o0oOoO00o = O0oOO0o0 ( Ooo . text ) . encode ( "utf8" )
  try :
   iiiI11 = re . compile ( 'name="_token" content="(.+?)"' ) . findall ( o0oOoO00o ) [ 0 ]
   o0O [ "X-CSRF-Token" ] = iiiI11
  except :
   pass
  OOooO = {
 'id' : url ,
 'type' : 'newchannel' ,
 'quality' : '3' ,
 'mobile' : 'web' ,
 'episode' : ep_id
 }
  return O0OoOoo00o . post ( oO00oOo , headers = o0O , data = OOooO ) . json ( ) [ "stream" ]
  if 13 - 13: i1oOo0OoO . Oo0Ooo - iiiIIii1IIi - Oo


if __name__ == '__main__' :
 oo000 . run ( )
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
