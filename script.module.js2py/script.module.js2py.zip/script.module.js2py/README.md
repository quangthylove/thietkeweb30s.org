script.module.js2py
======================

Python Js2Py library packed for Kodi.

See https://github.com/PiotrDabkowski/Js2Py

