# -*- coding: utf-8 -*-
#https://www.facebook.com/groups/vietkodi/

import re
import urlfetch
import os
from time import sleep
from addon import alert, notify, ADDON, ADDON_ID, ADDON_PROFILE, LOG, PROFILE
import simplejson as json
import random
import xbmc,xbmcgui
from config import VIETMEDIA_HOST
import urllib

import time


USER_VIP_CODE = ADDON.getSetting('user_vip_code')
ADDON_NAME = ADDON.getAddonInfo("name")
PROFILE_PATH = xbmc.translatePath(ADDON_PROFILE).decode("utf-8")
HOME = xbmc.translatePath('special://home/')
USERDATA = os.path.join(xbmc.translatePath('special://home/'), 'userdata')
ADDONDATA = os.path.join(USERDATA, 'addon_data', ADDON_ID)
DIALOG = xbmcgui.Dialog()


def fetch_data(url, headers=None, data=None):
  	if headers is None:

  		headers = { 
    				'User-agent'	: 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36 VietMedia/1.0',
                	'Referer'		: 'http://www.google.com',
                	'X-User-VIP'    :  USER_VIP_CODE
            }
  	try:

  		if data:
  			response = urlfetch.post(url, headers=headers, data=data)
  		else:
			response = urlfetch.get(url, headers=headers)
           	return response

	except Exception as e:
  		print e
  		pass


def get(url):
	if '//fptplay.net' in url:
		return get_fptplay(url)
	if 'www.fshare.vn' in url:
		return get_fshare(url)
	else:
		return url
		

	
def get_hash(m):
	md5 = m or 9
	s = ''
	code = 'LinksVIP.Net2014eCrVtByNgMfSvDhFjGiHoJpKlLiEuRyTtYtUbInOj9u4y81r5o26q4a0v'
	for x in range(0, md5):
		s = s + code[random.randint(0,len(code)-1)] 
    
	return s
def get_linkvips(fshare_url,username, password):
	
	host_url = 'http://linksvip.net/?ref=9669'
	login_url = 'http://linksvip.net/login/'
	logout_url = 'http://linksvip.net/login/logout.php'
	getlink_url = 'http://linksvip.net/GetLinkFs'
	
	response = fetch_data(host_url)
	if not response:
		return
	
	cookie = response.cookiestring

	headers = { 
				'User-Agent' 	: 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36',
				'Cookie'		: cookie,
				'Referer'		: host_url,
				'Content-Type'	: 'application/x-www-form-urlencoded; charset=UTF-8',
				'Accept'		: 'application/json, text/javascript, */*; q=0.01',
				'X-Requested-With'	: 'XMLHttpRequest'
            }
	
	data = {
			"u"				: username,
			"p"				: password,
			"auto_login"	: 'checked'
		}

	response = fetch_data(login_url, headers, data)

	video_url = ''
	if response.status == 200:
		json_data = json.loads(response.body)
		if int(json_data['status']) == 1:
			cookie = cookie + ';' + response.cookiestring
			headers['Cookie'] = cookie
			data = {
				"link"			: fshare_url,
				"pass"			: 'undefined',
				"hash"			: get_hash(32),
				"captcha"		: ''

			}
			headers['Accept-Encoding'] = 'gzip, deflate'
			headers['Accept-Language'] = 'en-US,en;q=0.8,vi;q=0.6'
			
			response = fetch_data(getlink_url, headers, data)

			json_data = json.loads(response.body)

			link_vip = json_data['linkvip']
			
			response = fetch_data(link_vip, headers)

			match = re.search(r'id="linkvip"\stype="text"\svalue="(.*?)"', response.body)
			if not match:
				return ''
			video_url = match.group(1)
			video_url = video_url.replace("[LinksVIP.Net]", "")
			xbmc.log(video_url)
			#logout
			response = fetch_data(logout_url, headers)
			
	return video_url

	
def get_fshare(url):
	url = url.replace('http://', 'https://')
	#xbmc.log(url)
	match = re.search(r"(https://)", url)
	if not match:
		url = 'https://'+url
	else:
		url = url
		
	username = ADDON.getSetting('fshare_username')
	password = ADDON.getSetting('fshare_password')
	fshare_option = ADDON.getSetting('fshare_option')
	
	def getlink(url, username, password):
		login_url = 'https://www.fshare.vn/login'
		logout_url = 'https://www.fshare.vn/logout'
		download_url = 'https://www.fshare.vn/download/get'
		notify (u'VMF Getlink system'.encode("utf-8"))
		response = fetch_data(login_url)
		if not response:
			return

		csrf_pattern = '\svalue="(.+?)".*name="fs_csrf"'

		csrf=re.search(csrf_pattern, response.body)
		fs_csrf = csrf.group(1)

		headers = { 
					'User-Agent' 	: 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36 VietMedia/1.0',
					'Cookie'		: response.cookiestring
				}
		
		data = {
				"LoginForm[email]"		: username,
				"LoginForm[password]"	: password,
				"fs_csrf"				: fs_csrf
			}

		response = fetch_data(login_url, headers, data)
		headers['Cookie'] = response.cookiestring
		headers['Referer'] = url
		direct_url = ''
		attempt = 1
		MAX_ATTEMPTS = 8
		file_id = os.path.basename(url)
		if response and response.status == 302:
			notify (u'Đang xử lý lấy link'.encode("utf-8"))
			while attempt < MAX_ATTEMPTS:
				if attempt > 1: sleep(2)
				notify (u'Lấy link lần thứ #%s'.encode("utf-8") % attempt)
				attempt += 1

				response = fetch_data(url, headers, data)

				if response.status == 200:
					csrf=re.search(csrf_pattern, response.body)
					fs_csrf = csrf.group(1)
					data = {
							'fs_csrf'					: fs_csrf,
							'ajax'						: 'download-form',
							'DownloadForm[linkcode]'	: file_id
						}

					response=fetch_data(download_url, headers, data);

					json_data = json.loads(response.body)

					if json_data.get('url'):
						direct_url = json_data['url']
						break
					elif json_data.get('msg'):
						notify(json_data['msg'].encode("utf-8"))
				elif response.status == 302:
					direct_url = response.headers['location']
					break
				else:
					notify (u'Lỗi khi lấy link, mã lỗi #%s. Đang thử lại...'.encode("utf-8") % response.status)

			response = fetch_data(logout_url, headers)
			if response.status == 302:
				notify (u'Done'.encode("utf-8"))
		else:
			notify (u'Lấy link không thành công.'.encode("utf-8"))
		if len(direct_url) > 0:
			notify (u'Đã lấy được link'.encode("utf-8"))
		else:
			notify (u'Có sự cố khi lấy link. Xin vui lòng thử lại'.encode("utf-8"))

		return direct_url
	#+++++++++++++++++	
	if fshare_option == "true":
		if len(username) == 0  or len(password) == 0:
			alert(u'Bạn chưa nhập [COLOR red]VMF[/COLOR] code hoặc tài khoản cá nhân Fshare'.encode("utf-8"), 'Soạn tin: [COLOR red]VMF[/COLOR] gửi [COLOR red]8798[/COLOR] để lấy VMF Code')
			return
		else:
			return getlink(url, username, password)
	
	if fshare_option == "false":	
		if len(USER_VIP_CODE) == 0:
			alert(u'Bạn chưa nhập [COLOR red]VMF[/COLOR] code hoặc tài khoản cá nhân Fshare'.encode("utf-8"), 'Soạn tin: [COLOR red]VMF[/COLOR] gửi [COLOR red]8798[/COLOR] để lấy VMF Code')
			return
		if len(USER_VIP_CODE) > 0:
			try:
				url_account = VIETMEDIA_HOST + '?action=fshare_account'
				response = fetch_data(url_account)
				json_data = json.loads(response.body)
				username = json_data['username']
				password = json_data['password']
				return getlink(url, username, password)
			except Exception as e:
				pass
			