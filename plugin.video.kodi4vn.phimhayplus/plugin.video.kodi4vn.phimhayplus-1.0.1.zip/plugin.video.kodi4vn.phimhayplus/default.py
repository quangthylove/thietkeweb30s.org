#!/usr/bin/python
# -*- coding: utf-8 -*-
import urllib , requests , re , os , json , uuid , base64 , kodi4vn
import concurrent . futures
from xbmcswift2 import Plugin , xbmc , xbmcgui , xbmcaddon
from operator import itemgetter
requests . packages . urllib3 . disable_warnings ( )
oo000 = Plugin ( )
ii = xbmc . translatePath ( 'special://userdata' )
oOOo = os . path . join ( ii , 'search.p' )
if 59 - 59: Oo0Ooo . OO0OO0O0O0 * iiiIIii1IIi . iII111iiiii11 % I1IiiI
IIi1IiiiI1Ii = "plugin://plugin.video.kodi4vn.phimhayplus"
I11i11Ii = "https://docs.google.com/drawings/d/12OjbFr3Z5TCi1WREwTWECxNNwx0Kx-FTrCLOigrpqG4/pub?w=256&h=256"
oO00oOo = "https://docs.google.com/drawings/d/1rniOY_omlvmXtpuHFoMuCS3upWOu04DD0KWRyLV4szs/pub?w=1920&h=1080"
OOOo0 = "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36"
Oooo000o = "Mozilla/5.0 (iPhone; CPU iPhone OS 8_0_2 like Mac OS X) AppleWebKit/600.1.4 (KHTML, like Gecko) Version/8.0 Mobile/12A366 Safari/600.1.4"
IiIi11iIIi1Ii = '''<a class="movie-item m-block"[^>]*href="(.+?)">.+?\('.+?url=(.+?)'\).+?<div class="movie-title-1">(.+?)</div><span class="movie-title-2">(.+?)</span><span class="movie-title-chap">(.+?)</span><span class="ribbon">(.+?)</span></div>'''
Oo0O = '<li class="film-item.+?"><label class="current-status">(.+?)</label>(.*?)<a[^>]*href=".+?-(\d+).html"[^>]*><img[^>]*data-original="(.+?)"[^>]*><div[^>]*><p[^>]*>(.*?)</p><p[^>]*>(.+?)</p></div></a></li>'
IiI = '<a class="watch_button now" href="(.+?)">Xem phim</a>'
ooOo = '<li><a href="(/xem-phim/.+?)">(.+?)</a></li>'
Oo = '&file=/xml.php\?id=(\d+)'
o0O = '<div class="list_episodes content">.*?<td[^>]*class="name">%s</td><td valign="top" class="ep">(.+?)</td></tr>'
if 48 - 48: iII111i % IiII + I1Ii111 / ooOoO0o * o00O0oo
O0oOO0o0 = 20
if 9 - 9: o0o - OOO0o0o
@ oo000 . route ( '/' )
def Ii1iI ( ) :
 xbmc . executebuiltin ( "ShowPicture(%s)" % oO00oOo )
 if 100 - 100: i11Ii11I1Ii1i . ooO - OOoO / ooo0Oo0 * i1 - OOooo0000ooo
@ oo000 . route ( '/search' )
def OOo000 ( ) :
 O0 = oo000 . keyboard ( heading = 'Tìm kiếm' )
 if O0 :
  I11i1i11i1I = 'http://phimhayplus.com/tim-kiem/' + urllib . quote_plus ( O0 ) + '/page-%s'
  with open ( oOOo , "a" ) as Iiii :
   Iiii . write ( O0 + "\n" )
  OOO0O = {
 "title" : "Search: %s" % O0 ,
 "url" : I11i1i11i1I ,
 "page" : 1
 }
  oo0ooO0oOOOOo = '%s/list_media/%s' % (
 IIi1IiiiI1Ii ,
 urllib . quote_plus ( json . dumps ( OOO0O ) )
 )
  oo000 . redirect ( oo0ooO0oOOOOo )
  if 71 - 71: O00OoOoo00
@ oo000 . route ( '/searchlist' )
def iIiiI1 ( ) :
 OoOooOOOO (
 '[Search List]' ,
 '/searchlist/'
 )
 i11iiII = [ ]
 I1iiiiI1iII = [ {
 "label" : "[B]Search[/B]" ,
 "path" : "%s/search" % ( IIi1IiiiI1Ii ) ,
 "thumbnail" : "https://docs.google.com/drawings/d/1uP5xm3I5KRZsnoliqJDkYJXYz1MznecVqWg3e-Gue48/pub?w=256&h=256"
 } ]
 IiIi11i = [ ]
 if os . path . exists ( oOOo ) :
  with open ( oOOo , "r" ) as Iiii :
   IiIi11i = Iiii . read ( ) . strip ( ) . split ( "\n" )
  for iIii1I111I11I in reversed ( IiIi11i ) :
   I11i1i11i1I = 'http://phimhayplus.com/tim-kiem/' + urllib . quote_plus ( iIii1I111I11I ) + '/page-%s'
   OOO0O = {
 "title" : "Search: %s" % iIii1I111I11I ,
 "url" : I11i1i11i1I ,
 "page" : 1
 }
   OO00OooO0OO = { }
   OO00OooO0OO [ "label" ] = iIii1I111I11I
   OO00OooO0OO [ "path" ] = "%s/list_media/%s" % (
 IIi1IiiiI1Ii ,
 urllib . quote_plus ( json . dumps ( OOO0O ) )
 )
   OO00OooO0OO [ "thumbnail" ] = "https://docs.google.com/drawings/d/1uP5xm3I5KRZsnoliqJDkYJXYz1MznecVqWg3e-Gue48/pub?w=256&h=256"
   i11iiII . append ( OO00OooO0OO )
 i11iiII = I1iiiiI1iII + i11iiII
 return oo000 . finish ( i11iiII )
 if 28 - 28: iIii1
@ oo000 . route ( '/list_media/<args_json>' )
def oOOoO0 ( args_json = { } ) :
 i11iiII = [ ]
 O0OoO000O0OO = json . loads ( args_json )
 OoOooOOOO (
 "[Browse Media of] %s - Page %s" % (
 O0OoO000O0OO [ "title" ] if "title" in O0OoO000O0OO else "Unknow Title" ,
 O0OoO000O0OO [ "page" ] if "page" in O0OoO000O0OO else "1"
 ) ,
 '/list_media/%s/%s' % (
 O0OoO000O0OO [ "url" ] % O0OoO000O0OO [ "page" ] if "page" in O0OoO000O0OO else "1" ,
 json . dumps ( O0OoO000O0OO [ "payloads" ] ) if "payloads" in O0OoO000O0OO else "{}"
 )
 )
 iiI1IiI = II ( O0OoO000O0OO [ "url" ] % O0OoO000O0OO [ "page" ] )
 ooOoOoo0O = re . compile ( IiIi11iIIi1Ii , re . S ) . findall ( iiI1IiI )
 for I11i1i11i1I , OooO0 , II11iiii1Ii , OO0o , Ooo , O0o0Oo in ooOoOoo0O :
  Ooo = Ooo . strip ( )
  O0o0Oo = O0o0Oo . strip ( )
  I11i1i11i1I += "tap-%20.html"
  Oo00OOOOO = "%s - %s (%s) (%s)" % ( II11iiii1Ii , OO0o , Ooo , O0o0Oo )
  OOO0O = {
 "title" : Oo00OOOOO ,
 "quality_label" : O0o0Oo ,
 "url" : I11i1i11i1I
 }
  OO00OooO0OO = { }
  OO00OooO0OO [ "label" ] = Oo00OOOOO
  OO00OooO0OO [ "path" ] = "%s/list_mirrors/%s" % (
 IIi1IiiiI1Ii ,
 urllib . quote_plus ( json . dumps ( OOO0O ) )
 )
  OO00OooO0OO [ "thumbnail" ] = OooO0
  if "HD" in O0o0Oo :
   OO00OooO0OO [ "label" ] = "[COLOR yellow]%s[/COLOR]" % OO00OooO0OO [ "label" ]
  i11iiII . append ( OO00OooO0OO )
 if len ( i11iiII ) == O0oOO0o0 :
  O0O = int ( O0OoO000O0OO [ "page" ] ) + 1
  O0OoO000O0OO [ "page" ] = O0O
  i11iiII . append ( {
 'label' : 'Next >>' ,
 'path' : '%s/list_media/%s' % (
 IIi1IiiiI1Ii ,
 urllib . quote_plus ( json . dumps ( O0OoO000O0OO ) )
 ) ,
 'thumbnail' : I11i11Ii
 } )
 return oo000 . finish ( i11iiII )
 if 83 - 83: OOoO + iII111i * o0o % ooOoO0o + OOoO
@ oo000 . route ( '/list_mirrors/<args_json>' )
def Ii1iIIIi1ii ( args_json = { } ) :
 i11iiII = [ ]
 O0OoO000O0OO = json . loads ( args_json )
 OoOooOOOO (
 "[Browse Mirrors of] %s (%s)" % (
 O0OoO000O0OO [ "title" ] if "title" in O0OoO000O0OO else "Unknow Title" ,
 O0OoO000O0OO [ "quality_label" ] if "quality_label" in O0OoO000O0OO else ""
 ) ,
 '/list_mirrors/%s/%s' % (
 O0OoO000O0OO [ "url" ] ,
 json . dumps ( O0OoO000O0OO [ "payloads" ] ) if "payloads" in O0OoO000O0OO else "{}"
 )
 )
 o0oo0o0O00OO = II ( O0OoO000O0OO [ "url" ] )
 ooOoOoo0O = re . compile ( '<h3 class="server.+?">(.+?)</h3>' , re . S ) . findall ( o0oo0o0O00OO )
 for o0oO in ooOoOoo0O :
  OOO0O = {
 "title" : O0OoO000O0OO [ "title" ] ,
 "mirror" : o0oO ,
 "quality_label" : O0OoO000O0OO [ "quality_label" ] ,
 "url" : O0OoO000O0OO [ "url" ]
 }
  OO00OooO0OO = { }
  OO00OooO0OO [ "label" ] = o0oO . strip ( )
  OO00OooO0OO [ "path" ] = "%s/list_eps/%s" % (
 IIi1IiiiI1Ii ,
 urllib . quote_plus ( json . dumps ( OOO0O ) )
 )
  i11iiII . append ( OO00OooO0OO )
 return oo000 . finish ( i11iiII )
 if 48 - 48: OOoO + OOoO / iII111i / iiiIIii1IIi
@ oo000 . route ( '/list_eps/<args_json>' )
def i1iiI11I ( args_json = { } ) :
 i11iiII = [ ]
 O0OoO000O0OO = json . loads ( args_json )
 OoOooOOOO (
 "[Browse Episodes of] %s (%s) [%s]" % (
 O0OoO000O0OO [ "title" ] if "title" in O0OoO000O0OO else "Unknow Title" ,
 O0OoO000O0OO [ "quality_label" ] if "quality_label" in O0OoO000O0OO else "" ,
 O0OoO000O0OO [ "mirror" ] if "mirror" in O0OoO000O0OO else ""
 ) ,
 '/list_mirrors/%s/%s' % (
 O0OoO000O0OO [ "url" ] ,
 json . dumps ( O0OoO000O0OO [ "payloads" ] ) if "payloads" in O0OoO000O0OO else "{}"
 )
 )
 iiI1IiI = II ( O0OoO000O0OO [ "url" ] )
 iiii = re . search ( '<h3 class="server.+?">%s</h3><ul class="list-episode">(.+?)</ul>' %
 O0OoO000O0OO [ "mirror" ] . encode ( "utf8" ) , iiI1IiI ) . group ( 1 )
 for oO0o0O0OOOoo0 , IiIiiI in re . compile ( '<a[^>]*title="(.+?)"[^>]*href="(.+?)"[^>]*>' ) . findall ( iiii ) :
  OOO0O = {
 "title" : O0OoO000O0OO [ "title" ] ,
 "quality_label" : O0OoO000O0OO [ "quality_label" ] ,
 "mirror" : O0OoO000O0OO [ "mirror" ] ,
 "url" : IiIiiI ,
 "eps" : oO0o0O0OOOoo0
 }
  OO00OooO0OO = { }
  OO00OooO0OO [ "label" ] = "Part %s - %s [%s]" % (
 oO0o0O0OOOoo0 . decode ( "utf8" ) ,
 O0OoO000O0OO [ "title" ] ,
 O0OoO000O0OO [ "mirror" ] . replace ( ":" , "" )
 )
  OO00OooO0OO [ "path" ] = '%s/play/%s' % (
 IIi1IiiiI1Ii ,
 urllib . quote_plus ( json . dumps ( OOO0O ) )
 )
  OO00OooO0OO [ "is_playable" ] = True
  i11iiII . append ( OO00OooO0OO )
 return oo000 . finish ( i11iiII )
 if 31 - 31: ooo0Oo0 . ooo0Oo0 - o0o / ooOoO0o + iIii1 * IiII
@ oo000 . route ( '/play/<args_json>' )
def O0ooOooooO ( args_json = { } ) :
 O0OoO000O0OO = json . loads ( args_json )
 OoOooOOOO (
 "[Play] %s (%s) - Part %s [%s]" % (
 O0OoO000O0OO [ "title" ] if "title" in O0OoO000O0OO else "Unknow Title" ,
 O0OoO000O0OO [ "quality_label" ] if "quality_label" in O0OoO000O0OO else "" ,
 O0OoO000O0OO [ "eps" ] if "eps" in O0OoO000O0OO else "" ,
 O0OoO000O0OO [ "mirror" ] if "mirror" in O0OoO000O0OO else ""
 ) ,
 '/play/%s/%s' % (
 O0OoO000O0OO [ "url" ] ,
 json . dumps ( O0OoO000O0OO [ "payloads" ] ) if "payloads" in O0OoO000O0OO else "{}"
 )
 )
 oo000 . set_resolved_url ( o00O ( O0OoO000O0OO [ "url" ] ) )
 if 69 - 69: i11Ii11I1Ii1i % O00OoOoo00 - o0o + O00OoOoo00 - OO0OO0O0O0 % iII111iiiii11
def o00O ( url ) :
 iiI1IiI = II ( url )
 Iii111II = re . search ( "PHP\('(.+?)', *filmInfo\.filmID\)" , iiI1IiI , re . S ) . group ( 1 )
 iiii11I = re . search ( "filmInfo.filmID = parseInt\('(\d+)'\);" , iiI1IiI , re . S ) . group ( 1 )
 Ooo0OO0oOO = {
 "id" : iiii11I ,
 "link" : Iii111II
 }
 o0oo0o0O00OO = II ( "http://phimhayplus.com/ajax/player" , data = Ooo0OO0oOO )
 try :
  return o0oo0o0O00OO [ "link" ] [ 0 ] [ "file" ]
 except : pass
 try :
  if "bilutv.com" in o0oo0o0O00OO [ "link" ] :
   oo0ooO0oOOOOo = "plugin://plugin.video.kodi4vn.bilutv/play/"
   oo0ooO0oOOOOo += urllib . quote_plus ( '{"url": "%s", "title": ""}' % ( o0oo0o0O00OO [ "link" ] ) )
   return oo0ooO0oOOOOo
 except : pass
 try :
  return kodi4vn . resolve ( o0oo0o0O00OO [ "link" ] )
 except : pass
 return None
 if 50 - 50: IiII
 if 34 - 34: IiII * iII111i % i1 * o00O0oo - IiII
def II ( url , data = { } ) :
 II1III = {
 'User-Agent' : OOOo0 ,
 'Accept-Encoding' : 'gzip, deflate, sdch'
 }
 if data == { } :
  o0oo0o0O00OO = requests . get (
 url ,
 headers = II1III )
 else :
  II1III [ "Content-Type" ] = "application/x-www-form-urlencoded; charset=UTF-8"
  o0oo0o0O00OO = requests . post (
 url ,
 headers = II1III ,
 data = data )
  o0oo0o0O00OO . encoding = "utf-8"
  iiI1IiI = o0oo0o0O00OO . text . encode ( "utf8" )
  return o0oo0o0O00OO . json ( )
 o0oo0o0O00OO . encoding = "utf-8"
 iiI1IiI = o0oo0o0O00OO . text . encode ( "utf8" )
 return iiI1IiI
 if 19 - 19: i11Ii11I1Ii1i % I1IiiI % o0o
def OoOooOOOO ( title = "Home" , page = "/" ) :
 try :
  oo0OooOOo0 = "http://www.google-analytics.com/collect"
  o0OO00oO = open ( I11i1I1I ) . read ( )
  Ooo0OO0oOO = {
 'v' : '1' ,
 'tid' : 'UA-52209804-5' ,
 'cid' : o0OO00oO ,
 't' : 'pageview' ,
 'dp' : "PhimHayPlus%s" % page ,
 'dt' : "[PhimHayPlus] - %s" % title . encode ( "utf8" )
 }
  requests . post ( oo0OooOOo0 , data = urllib . urlencode ( Ooo0OO0oOO ) )
 except :
  pass
  if 83 - 83: OOO0o0o / iIii1
ii = xbmc . translatePath ( 'special://userdata' )
oOOo = os . path . join ( ii , 'search.p' )
if 49 - 49: o0o
I11i1I1I = os . path . join ( ii , 'cid' )
if not os . path . exists ( I11i1I1I ) :
 with open ( I11i1I1I , "w" ) as Iiii :
  Iiii . write ( str ( uuid . uuid1 ( ) ) )
  if 35 - 35: o00O0oo - iII111iiiii11 / OOO0o0o % I1IiiI
if __name__ == '__main__' :
 oo000 . run ( )
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
