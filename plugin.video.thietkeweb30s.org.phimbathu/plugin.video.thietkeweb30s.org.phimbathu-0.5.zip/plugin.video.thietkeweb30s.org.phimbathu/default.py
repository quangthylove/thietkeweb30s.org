﻿#!/usr/bin/python
# coding=utf-8
import urllib , requests , re , json , os , uuid
from xbmcswift2 import Plugin , xbmc , xbmcgui , xbmcaddon
from operator import itemgetter
requests . packages . urllib3 . disable_warnings ( )
oo000 = Plugin ( )
ii = "plugin://plugin.video.thietkeweb30s.org.phimbathu"
if 51 - 51: IiI1i11I
Iii1I1 = "https://phimbathu.net/show/getlinklivetv"
OOO0O0O0ooooo = "https://phimbathu.net/tro-giup/bao-loi"
iIIii1IIi = "https://phimbathu.net/show/getlink"
o0OO00 = 24
if 78 - 78: i11i . oOooOoO0Oo0O
iI1 = {
 'User-Agent' : 'Mozilla/5.0 (iPhone; CPU iPhone OS 5_0 like Mac OS X) AppleWebKit/534.46 (KHTML, like Gecko) Version/5.1 Mobile/9A334 Safari/7534.48.3' ,
 'Accept-Encoding' : 'gzip, deflate' ,
 }
if 43 - 43: I11i11Ii
def oO00oOo ( s ) :
 s = '' . join ( s . splitlines ( ) ) . replace ( '\'' , '"' )
 s = s . replace ( '\n' , '' )
 s = s . replace ( '\t' , '' )
 s = re . sub ( '  +' , ' ' , s )
 s = s . replace ( '> <' , '><' )
 return s
 if 92 - 92: O0O / oo000i1iIi11iIIi1 % Iii1IIIiiI + iI - Oo / o0O
@ oo000 . route ( '/eps/<sid>' )
def IiiIII111iI ( sid ) :
 IiII ( "Browse eps by id %s" % sid , "/eps/%s" % sid )
 iI1Ii11111iIi = "http://phimbathu.com/xem-phim/phim--%s" % sid
 if 41 - 41: I1II1
 Ooo0OO0oOO = requests . get ( iI1Ii11111iIi , headers = iI1 )
 Ooo0OO0oOO . encoding = "utf-8"
 oooO0oo0oOOOO = oO00oOo ( Ooo0OO0oOO . text ) . encode ( "utf8" )
 IiiIII111iI = re . compile ( '<div class="list-episode">(.+?)</div>' ) . findall ( oooO0oo0oOOOO )
 O0oO = re . compile ( 'data-id="(\d+)"' ) . findall ( oooO0oo0oOOOO ) [ 0 ]
 iI1Ii11111iIi = "_e%s.html" % O0oO
 o0oO0 = [ ]
 if len ( IiiIII111iI ) > 0 :
  for oo00 , o00 in re . compile ( '<a[^>]*href="(.+?)">(.+?)</a>' ) . findall ( IiiIII111iI [ 0 ] ) :
   Oo0oO0ooo = { }
   Oo0oO0ooo [ "label" ] = "Tập: %s" % o00
   Oo0oO0ooo [ "path" ] = "%s/play/%s" % ( ii , urllib . quote_plus ( oo00 ) )
   Oo0oO0ooo [ "is_playable" ] = True
   o0oO0 . append ( Oo0oO0ooo )
 else :
  Oo0oO0ooo = { }
  Oo0oO0ooo [ "label" ] = "Xem Full"
  Oo0oO0ooo [ "path" ] = "%s/play/%s" % ( ii , urllib . quote_plus ( iI1Ii11111iIi ) )
  Oo0oO0ooo [ "is_playable" ] = True
  o0oO0 . append ( Oo0oO0ooo )
 return oo000 . finish ( o0oO0 )
 if 56 - 56: ooO00oOoo - O0OOo
@ oo000 . route ( '/list/<order>/<s_id>/<region_id>/<page>' )
def list ( order = "new" , s_id = "" , region_id = "" , page = "1" ) :
 IiII ( "Browse new videos by id %s" % s_id , "/list/%s/%s/%s/%s" % ( order , s_id , region_id , page ) )
 II1Iiii1111i = "http://phimbathu.com/film/filter?order=%s&cat_id=%s&city_id=%s&page=%s" % (
 order ,
 s_id ,
 region_id ,
 page
 )
 Ooo0OO0oOO = requests . get ( II1Iiii1111i , headers = iI1 )
 Ooo0OO0oOO . encoding = "utf-8"
 oooO0oo0oOOOO = oO00oOo ( Ooo0OO0oOO . text ) . encode ( "utf8" )
 i1IIi11111i = re . compile ( '<li class="item.*?"><span class="label">(.+?)</span>.*?<a title="(.+?)" href=".+?-(\d+).html"><img[^>]*data-original="(.+?)"[^>]*/>.+?<div class="name-real"><span>(.*?)</span>' ) . findall ( oooO0oo0oOOOO )
 o0oO0 = [ ]
 for o000o0o00o0Oo , oo , IiII1I1i1i1ii , IIIII , I1 in i1IIi11111i :
  if "://" not in IIIII :
   IIIII = "http://phimbathu.com/" + IIIII
  O0OoOoo00o = "%s - %s (%s)" % ( oo , I1 , o000o0o00o0Oo )
  Oo0oO0ooo = { }
  Oo0oO0ooo [ "label" ] = O0OoOoo00o
  Oo0oO0ooo [ "path" ] = "%s/eps/%s" % ( ii , IiII1I1i1i1ii )
  Oo0oO0ooo [ "thumbnail" ] = IIIII
  o0oO0 . append ( Oo0oO0ooo )
 if len ( o0oO0 ) == o0OO00 :
  Oo0oO0ooo = { }
  Oo0oO0ooo [ "label" ] = "Next >>"
  Oo0oO0ooo [ "path" ] = "%s/list/%s/%s/%s/%s" % (
 ii ,
 order ,
 s_id ,
 region_id ,
 int ( page ) + 1
 )
  Oo0oO0ooo [ "thumbnail" ] = "http://icons.iconarchive.com/icons/rafiqul-hassan/blogger/128/Arrow-Next-icon.png"
  o0oO0 . append ( Oo0oO0ooo )
 if oo000 . get_setting ( 'thumbview' , bool ) :
  if xbmc . getSkinDir ( ) in ( 'skin.confluence' , 'skin.eminence' ) :
   return oo000 . finish ( o0oO0 , view_mode = 500 )
  elif xbmc . getSkinDir ( ) == 'skin.xeebo' :
   return oo000 . finish ( o0oO0 , view_mode = 52 )
  else :
   return oo000 . finish ( o0oO0 )
 else :
  return oo000 . finish ( o0oO0 )
  if 31 - 31: i111IiI + iIIIiI11 . iII111ii
@ oo000 . route ( '/play/<url>' )
def i1iIIi1 ( url ) :
 IiII ( "Play" , '/play/%s' % ( url ) )
 ii11iIi1I = xbmcgui . DialogProgress ( )
 ii11iIi1I . create ( 'PhimBatHu.com' , 'Loading video. Please wait...' )
 oo000 . set_resolved_url ( iI111I11I1I1 ( url ) )
 ii11iIi1I . close ( )
 del ii11iIi1I
 if 55 - 55: iI1I % iiiIi - OO / i1I111I - iI . iII111ii
def iI111I11I1I1 ( url ) :
 print url
 O0OOooO = ""
 try :
  O0OOooO = re . compile ( "_e(\d+).html" ) . findall ( url ) [ 0 ]
 except :
  pass
 try :
  O0OOooO = re . compile ( "_e(\d+).html" ) . findall ( url ) [ 0 ]
 except :
  pass
 iI1Ii11111iIi = "http://phimbathu.com/link-film/download-phim--%s_HD2.html" % O0OOooO
 Ooo0OO0oOO = requests . get ( iI1Ii11111iIi , headers = iI1 )
 Ooo0OO0oOO . encoding = "utf-8"
 oooO0oo0oOOOO = oO00oOo ( Ooo0OO0oOO . text ) . encode ( "utf8" )
 iIiIiIiIIi = ""
 ooOoo0O = re . compile ( 'data-link="(.+?)"><a[^>]*>.+?(\d+).+?</a>' ) . findall ( oooO0oo0oOOOO )
 ooOoo0O = sorted ( ooOoo0O , key = itemgetter ( 1 ) )
 iIiIiIiIIi = ooOoo0O [ 0 ] [ 0 ]
 if oo000 . get_setting ( 'HQ' , bool ) and ( len ( ooOoo0O ) > 1 ) :
  iIiIiIiIIi = ooOoo0O [ - 1 ] [ 0 ]
 return iIiIiIiIIi
 if 76 - 76: i11i / I1II1 . Iii1IIIiiI * iII111ii - i111IiI
def IiII ( title = "Home" , page = "/" ) :
 Oooo = "http://www.google-analytics.com/collect"
 O00o = open ( O00 ) . read ( )
 i11I1 = {
 'v' : '1' ,
 'tid' : 'UA-52209804-5' ,
 'cid' : O00o ,
 't' : 'pageview' ,
 'dp' : "PhimBatHu" + page ,
 'dt' : title
 }
 requests . post ( Oooo , data = urllib . urlencode ( i11I1 ) )
 if 8 - 8: oOooOoO0Oo0O - iiiIi % oOooOoO0Oo0O - iII111ii * Iii1IIIiiI
iI11i1I1 = xbmc . translatePath ( 'special://userdata' )
if os . path . exists ( iI11i1I1 ) == False :
 os . mkdir ( iI11i1I1 )
O00 = os . path . join ( iI11i1I1 , 'cid' )
if 71 - 71: i1I111I % iI1I / I1II1
if os . path . exists ( O00 ) == False :
 with open ( O00 , "w" ) as ii11i1iIII :
  ii11i1iIII . write ( str ( uuid . uuid1 ( ) ) )
  if 3 - 3: O0O / Iii1IIIiiI % iIIIiI11 * IiI1i11I / i11i * iIIIiI11
if __name__ == '__main__' :
 oo000 . run ( )
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
