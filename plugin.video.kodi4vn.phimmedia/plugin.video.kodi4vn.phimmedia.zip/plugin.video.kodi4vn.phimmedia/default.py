#!/usr/bin/python
# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import urllib , requests , re , os , json , uuid , js2py , kodi4vn , cfscrape
import concurrent . futures
from xbmcswift2 import Plugin , xbmc , xbmcgui , xbmcaddon
from operator import itemgetter
from cookielib import LWPCookieJar
requests . packages . urllib3 . disable_warnings ( )
oo000 = cfscrape . create_scraper ( )
oo000 . cookies = LWPCookieJar ( )
if 9 - 9: Ii . o0o00Oo0O - iI11I1II1I1I
oooo = '41f5812679f97c83e27c539ac68c0dc6'
iIIii1IIi = Plugin ( )
o0OO00 = xbmc . translatePath ( 'special://userdata' )
oo = os . path . join ( o0OO00 , 'search.p' )
i1iII1IiiIiI1 = "plugin://plugin.video.kodi4vn.phimmedia"
iIiiiI1IiI1I1 = i1iII1IiiIiI1 . split ( "/" ) [ - 1 ]
o0OoOoOO00 = "https://docs.google.com/drawings/d/12OjbFr3Z5TCi1WREwTWECxNNwx0Kx-FTrCLOigrpqG4/pub?w=256&h=256"
I11i = 'div class="inner"><a title="(.*?)" href="(.+?)"><img[^>]*src="(.+?)"[^>]*></a>.+?</a>(.+?)</div><div class="name2">(.*?)</div>.+?<div class="status">(.*?)</div><div[^>]*class="speaker">(.*?)</div><div class="HD">(.*?)</div></div></li>'
if 64 - 64: OOooo000oo0 . i1 * ii1IiI1i % IIIiiIIii
I11iIi1I = 40
if 48 - 48: iII111i % IiII + I1Ii111 / ooOoO0o * o00O0oo
O0oOO0o0 = {
 'Referer' : 'http://www.phimmedia.tv/' ,
 'Content-Type' : 'application/x-www-form-urlencoded'
 }
if 9 - 9: o0o - OOO0o0o
@ iIIii1IIi . route ( '/' )
def Ii1iI ( ) :
 xbmc . executebuiltin ( "ShowPicture(%s)" % addon_popup )
 if 100 - 100: i11Ii11I1Ii1i . ooO - OOoO / ooo0Oo0 * i1OOooo0000ooo - OOo000
@ iIIii1IIi . route ( '/search' )
def O0 ( ) :
 I11i1i11i1I = iIIii1IIi . keyboard ( heading = 'Tìm kiếm' )
 if I11i1i11i1I :
  if 31 - 31: Ii / IIIiiIIii / OOo000 * o0o / iII111i
  Oo0o0ooO0oOOO = 'https://www.phimmedia.tv/index.php?keyword=' + urllib . quote_plus ( I11i1i11i1I ) + '&do=phim&act=search&page=%s'
  with open ( oo , "a" ) as oo0O000OoO :
   oo0O000OoO . write ( I11i1i11i1I + "\n" )
  i1iiIIiiI111 = {
 "title" : "Search: %s" % I11i1i11i1I ,
 "url" : Oo0o0ooO0oOOO ,
 "page" : 1
 }
  oooOOOOO = '%s/list_media/%s' % (
 i1iII1IiiIiI1 ,
 urllib . quote_plus ( json . dumps ( i1iiIIiiI111 ) )
 )
  iIIii1IIi . redirect ( oooOOOOO )
  if 22 - 22: ooO * o0o00Oo0O / ooOoO0o
@ iIIii1IIi . route ( '/searchlist' )
def o00ooooO0oO ( ) :
 oOoOo00oOo (
 '[Search List]' ,
 '/searchlist/'
 )
 Oo = [ ]
 o00O00O0O0O = [ {
 "label" : "[B]Search[/B]" ,
 "path" : "%s/search" % ( i1iII1IiiIiI1 ) ,
 "thumbnail" : "https://docs.google.com/drawings/d/1uP5xm3I5KRZsnoliqJDkYJXYz1MznecVqWg3e-Gue48/pub?w=256&h=256"
 } ]
 OooO0OO = [ ]
 if os . path . exists ( oo ) :
  with open ( oo , "r" ) as oo0O000OoO :
   OooO0OO = oo0O000OoO . read ( ) . strip ( ) . split ( "\n" )
  for iiiIi in reversed ( OooO0OO ) :
   Oo0o0ooO0oOOO = 'https://www.phimmedia.tv/index.php?keyword=' + urllib . quote_plus ( iiiIi ) + '&do=phim&act=search&page=%s'
   i1iiIIiiI111 = {
 "title" : "Search: %s" % iiiIi ,
 "url" : Oo0o0ooO0oOOO ,
 "page" : 1
 }
   IiIIIiI1I1 = { }
   IiIIIiI1I1 [ "label" ] = iiiIi
   IiIIIiI1I1 [ "path" ] = "%s/list_media/%s" % (
 i1iII1IiiIiI1 ,
 urllib . quote_plus ( json . dumps ( i1iiIIiiI111 ) )
 )
   IiIIIiI1I1 [ "thumbnail" ] = "https://docs.google.com/drawings/d/1uP5xm3I5KRZsnoliqJDkYJXYz1MznecVqWg3e-Gue48/pub?w=256&h=256"
   Oo . append ( IiIIIiI1I1 )
 Oo = o00O00O0O0O + Oo
 return iIIii1IIi . finish ( Oo )
 if 86 - 86: Ii + ooO + OOo000 * i11Ii11I1Ii1i + ooOoO0o
@ iIIii1IIi . route ( '/list_media/<args_json>' )
def oOoO ( args_json = { } ) :
 Oo = [ ]
 oOo = json . loads ( args_json )
 oOoOo00oOo (
 "[Browse Media of] %s - Page %s" % (
 oOo [ "title" ] if "title" in oOo else "Unknow Title" ,
 oOo [ "page" ] if "page" in oOo else "1"
 ) ,
 '/list_media/%s/%s' % (
 oOo [ "url" ] % oOo [ "page" ] if "page" in oOo else "1" ,
 json . dumps ( oOo [ "payloads" ] ) if "payloads" in oOo else "{}"
 )
 )
 oOoOoO = kodi4vn . Request ( oOo [ "url" ] % oOo [ "page" ] , session = oo000 )
 ii1I = kodi4vn . cleanHTML ( oOoOoO . text )
 OooO0 = re . compile ( I11i , re . S ) . findall ( ii1I )
 for II11iiii1Ii , Oo0o0ooO0oOOO , OO0o , Ooo , O0o0Oo , Oo00OOOOO , O0O , O00o0OO in OooO0 :
  Oo0o0ooO0oOOO = Oo0o0ooO0oOOO . strip ( ) + "xem-online.html"
  II11iiii1Ii = "%s - %s (%s) (%s %s %s)" % (
 II11iiii1Ii . strip ( ) ,
 O0o0Oo . strip ( ) ,
 Ooo . strip ( ) ,
 Oo00OOOOO . strip ( ) ,
 O0O . strip ( ) ,
 O00o0OO . strip ( )
 )
  i1iiIIiiI111 = {
 "title" : II11iiii1Ii ,
 "quality_label" : O00o0OO . strip ( ) ,
 "url" : Oo0o0ooO0oOOO
 }
  IiIIIiI1I1 = { }
  IiIIIiI1I1 [ "label" ] = II11iiii1Ii
  IiIIIiI1I1 [ "path" ] = "%s/list_mirrors/%s" % (
 i1iII1IiiIiI1 ,
 urllib . quote_plus ( json . dumps ( i1iiIIiiI111 ) )
 )
  IiIIIiI1I1 [ "thumbnail" ] = OO0o
  if "Bản Đẹp" in O00o0OO :
   IiIIIiI1I1 [ "label" ] = "[COLOR yellow]%s[/COLOR]" % IiIIIiI1I1 [ "label" ]
  Oo . append ( IiIIIiI1I1 )
 if len ( Oo ) == I11iIi1I :
  I11i1 = int ( oOo [ "page" ] ) + 1
  oOo [ "page" ] = I11i1
  Oo . append ( {
 'label' : 'Next >>' ,
 'path' : '%s/list_media/%s' % (
 i1iII1IiiIiI1 ,
 urllib . quote_plus ( json . dumps ( oOo ) )
 ) ,
 'thumbnail' : o0OoOoOO00
 } )
 return iIIii1IIi . finish ( Oo )
 if 25 - 25: iII111i - ooo0Oo0 . OOooo000oo0
@ iIIii1IIi . route ( '/list_mirrors/<args_json>' )
def I11ii1 ( args_json = { } ) :
 Oo = [ ]
 oOo = json . loads ( args_json )
 oOoOo00oOo (
 "[Browse Mirrors of] %s (%s)" % (
 oOo [ "title" ] if "title" in oOo else "Unknow Title" ,
 oOo [ "quality_label" ] if "quality_label" in oOo else ""
 ) ,
 '/list_mirrors/%s/%s' % (
 oOo [ "url" ] ,
 json . dumps ( oOo [ "payloads" ] ) if "payloads" in oOo else "{}"
 )
 )
 oOoOoO = kodi4vn . Request ( oOo [ "url" ] , session = oo000 )
 ii1I = kodi4vn . cleanHTML ( oOoOoO . text ) . encode ( "utf8" )
 OooO0 = re . compile ( '<h4>(.+?)</h4>' , re . S ) . findall ( ii1I )
 for I11II1i in OooO0 [ : - 1 ] :
  I11II1i = kodi4vn . stripHTML ( I11II1i ) . replace ( ":" , "" )
  i1iiIIiiI111 = {
 "title" : oOo [ "title" ] ,
 "mirror" : I11II1i ,
 "quality_label" : oOo [ "quality_label" ] ,
 "url" : oOo [ "url" ]
 }
  IiIIIiI1I1 = { }
  IiIIIiI1I1 [ "label" ] = I11II1i
  IiIIIiI1I1 [ "path" ] = "%s/list_eps/%s" % (
 i1iII1IiiIiI1 ,
 urllib . quote_plus ( json . dumps ( i1iiIIiiI111 ) )
 )
  Oo . append ( IiIIIiI1I1 )
 return iIIii1IIi . finish ( Oo )
 if 23 - 23: o00O0oo / ooOoO0o + i11Ii11I1Ii1i + i11Ii11I1Ii1i / ii1IiI1i
@ iIIii1IIi . route ( '/list_eps/<args_json>' )
def iiI1 ( args_json = { } ) :
 Oo = [ ]
 oOo = json . loads ( args_json )
 oOoOo00oOo (
 "[Browse Episodes of] %s (%s) [%s]" % (
 oOo [ "title" ] if "title" in oOo else "Unknow Title" ,
 oOo [ "quality_label" ] if "quality_label" in oOo else "" ,
 oOo [ "mirror" ] if "mirror" in oOo else ""
 ) ,
 '/list_mirrors/%s/%s' % (
 oOo [ "url" ] ,
 json . dumps ( oOo [ "payloads" ] ) if "payloads" in oOo else "{}"
 )
 )
 oOoOoO = kodi4vn . Request ( oOo [ "url" ] , session = oo000 )
 ii1I = kodi4vn . cleanHTML ( oOoOoO . text ) . encode ( "utf8" )
 i11Iiii = re . search ( '<h4>%s.*?</h4>(.+?)</div></div>' % oOo [ "mirror" ] , ii1I ) . group ( 1 )
 for iI , I1i1I1II in re . compile ( '<a[^>]*href="(.+?)" title="(.+?)">' ) . findall ( i11Iiii ) :
  i1iiIIiiI111 = {
 "title" : oOo [ "title" ] ,
 "quality_label" : oOo [ "quality_label" ] ,
 "mirror" : oOo [ "mirror" ] ,
 "url" : iI ,
 "eps" : I1i1I1II
 }
  IiIIIiI1I1 = { }
  IiIIIiI1I1 [ "label" ] = "Part %s - %s [%s]" % (
 I1i1I1II . decode ( "utf8" ) ,
 oOo [ "title" ] ,
 oOo [ "mirror" ] . replace ( ":" , "" )
 )
  IiIIIiI1I1 [ "path" ] = '%s/play/%s' % (
 i1iII1IiiIiI1 ,
 urllib . quote_plus ( json . dumps ( i1iiIIiiI111 ) )
 )
  IiIIIiI1I1 [ "is_playable" ] = True
  Oo . append ( IiIIIiI1I1 )
 return iIIii1IIi . finish ( Oo )
 if 45 - 45: i1OOooo0000ooo . I1Ii111
@ iIIii1IIi . route ( '/play/<args_json>' )
def oO ( args_json = { } ) :
 oOo = json . loads ( args_json )
 oOoOo00oOo (
 "[Play] %s (%s) - Part %s [%s]" % (
 oOo [ "title" ] if "title" in oOo else "Unknow Title" ,
 oOo [ "quality_label" ] if "quality_label" in oOo else "" ,
 oOo [ "eps" ] if "eps" in oOo else "" ,
 oOo [ "mirror" ] if "mirror" in oOo else ""
 ) ,
 '/play/%s/%s' % (
 oOo [ "url" ] ,
 json . dumps ( oOo [ "payloads" ] ) if "payloads" in oOo else "{}"
 )
 )
 iIIii1IIi . set_resolved_url ( ii1i1I1i ( oOo [ "url" ] ) )
 if 53 - 53: ooo0Oo0 + IIIiiIIii * o0o
def ii1i1I1i ( url ) :
 OooOooooOOoo0 = o00OO0OOO0 ( url )
 OooOooooOOoo0 = set ( OooOooooOOoo0 )
 OooOooooOOoo0 = list ( OooOooooOOoo0 )
 xbmc . log ( json . dumps ( OooOooooOOoo0 ) )
 for oo0 in OooOooooOOoo0 :
  try :
   oOoOoO = kodi4vn . Request ( oo0 , method = "HEAD" , session = oo000 )
   if oOoOoO . status_code < 300 :
    return oOoOoO . url
   if oOoOoO . status_code == 429 and "blogspot" in oo0 :
    return kodi4vn . RetryBlogspot ( oo0 )
  except : pass
  if 57 - 57: OOO0o0o . OOO0o0o
  if 95 - 95: o0o00Oo0O + IiII . ii1IiI1i / o0o00Oo0O
def o00OO0OOO0 ( url ) :
 oOoOoO = oo000 . get ( url )
 oOoOoO . encoding = "utf-8"
 ii1I = oOoOoO . text . encode ( "utf8" )
 if 97 - 97: OOo000 - OOO0o0o * Ii / I1Ii111 % i1OOooo0000ooo - OOooo000oo0
 OooO0 = re . compile ( 'define8\("(.+?)"\);' , re . S ) . findall ( ii1I )
 OooOooooOOoo0 = [ OoOo00o ( i11Iiii . decode ( "base64" ) ) for i11Iiii in OooO0 ]
 return OooOooooOOoo0
 if 70 - 70: OOoO * o00O0oo
 if 46 - 46: OOo000 / IiII
def OoOo00o ( url ) :
 OOOoO0O0o = "https\://bit.ly/2zE7Kmg\?(temp|test)=(tuoitre\.vn/\d+.mp4/tuoitre\.vn/\d+\.mp4|domain\.com/\d+\.mp4|u0000)*"
 url = re . sub ( OOOoO0O0o , "" , url ) . strip ( )
 OOOoO0O0o = "(domain\.com/\d+.mp4/)*(;|&)ip.+?($|http)"
 url = re . sub ( OOOoO0O0o , "" , url ) . strip ( )
 OOOoO0O0o = "domain\.com/\d+\.mp4"
 url = re . sub ( OOOoO0O0o , "v/t42.9040-2" , url )
 if url . startswith ( "/10000000_" ) :
  return "https://scontent.fhan4-1.fna.fbcdn.net/v/t42.9040-2" + url
 if url . startswith ( "/" ) :
  if re . search ( "(m18|m22)" , url ) :
   return "https://3.bp.blogspot.com" + url
  else :
   return "https://3.bp.blogspot.com%s=m22" % url
 return url
 if 55 - 55: OOO0o0o + OOo000 . i1 - o00O0oo . o0o00Oo0O - OOo000
o0OO00 = xbmc . translatePath ( 'special://userdata' )
oo = os . path . join ( o0OO00 , 'search.p' )
if 92 - 92: OOoO . i11Ii11I1Ii1i + ooOoO0o
global IiII1I11i1I1I
IiII1I11i1I1I = os . path . join ( o0OO00 , 'cid' )
if not os . path . exists ( IiII1I11i1I1I ) :
 with open ( IiII1I11i1I1I , "w" ) as oo0O000OoO :
  oo0O000OoO . write ( str ( uuid . uuid1 ( ) ) )
  if 83 - 83: o00O0oo / OOo000
def oOoOo00oOo ( title = "Home" , page = "/" ) :
 iIIIIii1 = "http://www.google-analytics.com/collect"
 oo000OO00Oo = ""
 try :
  with open ( IiII1I11i1I1I , "r" ) as oo0O000OoO :
   oo000OO00Oo = oo0O000OoO . read ( )
  O0OOO0OOoO0O = {
 'v' : '1' ,
 'tid' : 'UA-52209804-5' ,
 'cid' : oo000OO00Oo ,
 't' : 'pageview' ,
 'dp' : "TVHay%s" % page ,
 'dt' : ( "[TVHay] - %s" % title . encode ( "utf8" , 'ignore' ) . decode ( "utf8" ) ) . encode ( "utf8" )
 }
  requests . post ( iIIIIii1 , data = urllib . urlencode ( O0OOO0OOoO0O ) )
 except :
  pass
  if 70 - 70: ooo0Oo0 * iII111i * i11Ii11I1Ii1i / ooO
if __name__ == '__main__' :
 iIIii1IIi . run ( )
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
