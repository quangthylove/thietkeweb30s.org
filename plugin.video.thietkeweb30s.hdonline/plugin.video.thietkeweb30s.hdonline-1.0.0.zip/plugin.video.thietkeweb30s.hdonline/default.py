﻿# -*- coding: utf-8 -*-

'''
Copyright (C) 2016                                                     
Author    : itvplus
fanpage   : https://www.facebook.com/itvplusnet/ 
'''                                                                            

import urllib,urllib2,re,os,sys,json,string
import xbmcplugin,xbmcgui,xbmcaddon
import random

addon = xbmcaddon.Addon(id='plugin.video.thietkeweb30s.hdonline')
profile = xbmc.translatePath( addon.getAddonInfo('profile') ).decode("utf-8")
home = addon.getAddonInfo('path')
icon = xbmc.translatePath( os.path.join( home, 'icon.png' ))
fanart = xbmc.translatePath( os.path.join( home, 'fanart.jpg' ))
dataPatch = xbmc.translatePath(os.path.join(home, 'resources'))
logos = xbmc.translatePath(os.path.join(dataPatch, 'logos\\'))
sys.path.append(os.path.join(home,'resources','lib'));from BeautifulSoup import BeautifulSoup;import urlfetch

def alert(message,title="Thông báo!"):
    xbmcgui.Dialog().ok(title,"",message)

def notification(message, timeout = 5000):
    xbmc.executebuiltin((u'XBMC.Notification("%s", "%s", %s)' % ('Super Movies', message, timeout)).encode("utf-8"))

def home():
    addDir( '[COLOR red]Tìm Kiếm[/COLOR]','Search',1, '', '')
    addDir( 'Phim Mới', 'http://hdonline.vn/', 2, '', '')
    addDir( 'Phim Lẻ', 'http://hdonline.vn/', 2, '', '')
    addDir( 'Phim Bộ', 'http://hdonline.vn/', 2, '', '')
    addDir( 'Phim Đề Cử', 'http://hdonline.vn/hdo-de-cu.html', 3, '', '')
    addDir( 'Phim Chiếu Rạp', 'http://hdonline.vn/danh-sach/phim-chieu-rap.html', 3, '', '')
    addDir( 'Phim Lồng Tiếng', 'http://hdonline.vn/phim-long-tieng.html', 3, '', '')
    addDir( 'Phim Thuyết Minh', 'http://hdonline.vn/phim-thuyet-minh.html', 3, '', '')
    xbmc.executebuiltin('Container.SetViewMode(502)')# Media info 3

def search():
    try:
        keyb = xbmc.Keyboard('', '[COLOR red]Nhâp tên phim cần tìm kiếm[/COLOR]')
        keyb.doModal()
        if (keyb.isConfirmed()):
            searchText = urllib.quote_plus(keyb.getText())
        url = 'http://hdonline.vn/tim-kiem/%s.html' % urllib.quote_plus(searchText.replace('+', '-'))
        medialist(url)
    except:
        pass
	
def categories(url,name):
    if 'Phim Mới' in name:
        addDir('Mới Cập Nhật', 'http://hdonline.vn/danh-sach/phim-moi.html', 3, '', '')
        content = makeRequest(url)
        match = re.compile('<a href="/danh-sach/phim-theo-nam/(.+?)">(.+?)</a>').findall(content)
        for url, title in match:
	        addDir( title, ('%sdanh-sach/phim-theo-nam/%s' % (hdo, url)), 3, '', '')

    elif 'Phim Lẻ' in name:
        addDir('Danh Sách Phim Lẻ', 'http://hdonline.vn/danh-sach/phim-le.html', 3, '', '')
        content = makeRequest(url)
        match = re.compile('<a href=".+?/xem-phim-(.+?)" title=".+?">(.+?)</a>').findall(content)
        for url, title in match:
	        addDir( title, ('%sxem-phim-%s' % (hdo, url)), 3, '', '')
		
    elif 'Phim Bộ' in name:
        addDir('Danh Sách Phim Bộ', 'http://hdonline.vn/danh-sach/phim-bo.html', 3, '', '')
        content = makeRequest(url)
        match = re.compile('<a href=".+?/phim-bo-(.+?)" title=".+?">(.+?)</a>').findall(content)
        for url, title in match:
	        addDir( title, ('%sphim-bo-%s' % (hdo, url)), 3, '', '')

    xbmc.executebuiltin('Container.SetViewMode(502)')# Media info 3

def medialist(url):
    content = makeRequest(url)
    soup = BeautifulSoup(str(content), convertEntities=BeautifulSoup.HTML_ENTITIES)
    items = soup.findAll('div',{'class' : 'tn-bxitem'})
    for item in items:
        title = item.find('p',{'class' : 'name-en'}).text
        href = item.find('a').get('href')
        thumb = item.find('img').get('src')
        addDir( title.encode('utf-8'), 'http://m.hdonline.vn' + href, 4, thumb, '')
    if len(items) <= 21:
            pagelist = re.compile('<li><a.+?href="(.+?)">(.+?)</a></li>').findall(content)
            for href, vpage in pagelist:
                if 'Trang Sau' in vpage:
                    namepage = '[COLOR red]Next >>>[/COLOR] ' + '[COLOR green]' + href.split('/')[-1].split('.')[0] + '[/COLOR]'
                    addDir( namepage, 'http://hdonline.vn' + href.replace('http://hdonline.vn',''), 3, logos + 'NEXT.png', fanart)
    xbmc.executebuiltin('Container.SetViewMode(502)')# Media info 3
	
def episodes(url,iconimage):
    content = makeRequest(url)
    soup = BeautifulSoup(str(content), convertEntities=BeautifulSoup.HTML_ENTITIES)
    items = soup.find('div',{'class' : 'list-episode'}).findAll('a')
    for item in items:
	        id = item.get('id').encode('utf-8')
	        epi = item.find('span').text.encode('utf-8')
	        addDir( name + ' [[COLOR gold]' + epi + '[/COLOR]]', 'plugin://plugin.video.hkn.hdonline/?action=Play&filmid=%s' % id, 100, iconimage, '', '')

    xbmc.executebuiltin('Container.SetViewMode(502)')# Media info		
	
def makeRequest(url, headers=None):
    if headers is None:
        headers = {'User-agent' : 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36',
                 'Referer' : 'http://www.google.com'}
    try:
        req = urllib2.Request(url,headers=headers)
        f = urllib2.urlopen(req)
        body=f.read()
        return body
    except:
        pass

def get_params():
    param=[]
    paramstring=sys.argv[2]
    if len(paramstring)>=2:
        params=sys.argv[2]
        cleanedparams=params.replace('?','')
        if (params[len(params)-1]=='/'):
            params=params[0:len(params)-2]
        pairsofparams=cleanedparams.split('&')
        param={}
        for i in range(len(pairsofparams)):
            splitparams={}
            splitparams=pairsofparams[i].split('=')
            if (len(splitparams))==2:
                param[splitparams[0]]=splitparams[1]
    return param

def addDir(name,url,mode,iconimage,fanart,plot=''):
    u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)
    ok=True
    liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name, "plot":plot } )
    liz.setProperty('Fanart_Image',fanart)
    if 'plugin://' in url:
        u = url
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        return ok
    ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
    return ok  

hdo = 'http://hdonline.vn/'	
params=get_params()
url=None
name=None
mode=None
iconimage=None

try:url=urllib.unquote_plus(params["url"])
except:pass
try:name=urllib.unquote_plus(params["name"])
except:pass
try:mode=int(params["mode"])
except:pass
try:iconimage=urllib.unquote_plus(params["iconimage"])
except:pass 
try:fanart=urllib.unquote_plus(params["fanart"])
except:pass

#xbmcplugin.setContent(int(sys.argv[1]), 'movies')
sysarg=str(sys.argv[1])

if mode==None or url==None or len(url)<1:home()
elif mode==1:search()
elif mode==2:categories(url,name)
elif mode==3:medialist(url)
elif mode==4:episodes(url,iconimage)

xbmcplugin.endOfDirectory(int(sys.argv[1]))