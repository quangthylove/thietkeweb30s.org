#!/usr/bin/python
# -*- coding: utf-8 -*-

DEBUG = True


import xbmc, xbmcaddon, xbmcgui, xbmcplugin
import base64, cookielib, hashlib, json, os, random, re, requests, shutil, string, subprocess, sys, urllib, urlparse
from bs4        import BeautifulSoup
from HTMLParser import HTMLParser


# #################################################################################################### #
#
# META
#
# #################################################################################################### #


addon              = xbmcaddon.Addon()
addonId            = addon.getAddonInfo('id')
addonBase          = sys.argv[0]
addonHandle        = int(sys.argv[1])
addonParams        = urlparse.parse_qs(sys.argv[2][1:])

addonPath          = xbmc.translatePath(addon.getAddonInfo('path'))
userPath           = xbmc.translatePath(addon.getAddonInfo('profile'))

Android            = xbmc.getCondVisibility('System.Platform.Android')
Linux              = xbmc.getCondVisibility('System.Platform.Linux')
Windows            = xbmc.getCondVisibility('System.Platform.Windows')
if Android:
	DEBUG = False


# #################################################################################################### #
#
# GENERAL UTILITIES
#
# #################################################################################################### #


def Log(message):
	message = String(message)
	try:
		xbmc.log(message)
	except:
		try:
			xbmc.log(message.encode('utf-8'))
		except:
			try:
				xbmc.log(message.decode('utf-8').encode('utf-8'))
			except Exception, e:
				xbmc.log('| LOG ERROR | %s' % e)

def Path(path, file=''):
	return os.path.join(path, file)

def String(s):
	try:
		return str(s)
	except:
		try:
			return str(s.encode('utf-8'))
		except:
			try:
				return str(message.decode('utf-8').encode('utf-8'))
			except Exception, e:
				if DEBUG: Log('| String conversion error | %s' % e)
				return s

def Quote(s):
	return urllib.quote(s)

def QuotePlus(s):
	return urllib.quote_plus(s)

def Regex(pattern, source, flags=0):
	source = String(source)
	if flags:
		result = re.compile(pattern, flags=flags).findall(source)
	else:
		result = re.compile(pattern).findall(source)
	return result

def Resub(pattern, replacement, source, count=0, flags=0):
	source = String(source)
	if flags:
		result = re.sub(pattern, replacement, source, count=count, flags=flags)
	else:
		result = re.sub(pattern, replacement, source, count=count)
	return result

def StripFormatting(text):
	text = str(text)
	text = re.sub('(\[COLOR.+?\])', '', text).replace('[/COLOR]', '').replace('[B]', '').replace('[/B]', '')
	return text

def StripTags(text, before='', after='', minify=True):
	text = Minify(text)
	text = re.sub('(<[a-z|A-Z]+\s?[^>]*>)', before, text)
	text = re.sub('(</[a-z|A-Z]+>)', after, text)
	return text

def ParseTags(text):
	from xml.sax import saxutils
	return saxutils(text, {'&quot;': '"'})

def CleanText(text):
	text = String(text)
	try:
		text = HTMLParser().unescape(text)
	except Exception, e:
		if DEBUG: Log('| Clean text error | %s' % e)
	replacements = [
#		('', ''),
		('%20', ' '),
		('&nbsp;', ' '),
	]
	for rep in replacements:
		text = text.replace(rep[0], rep[1])
	return text

# #################################################################################################### #
#
# INTERFACE
#
# #################################################################################################### #

ICON               = os.path.join(addonPath, 'icon.png')
FANART             = os.path.join(addonPath, 'fanart.jpg')

COLOUR0            = '[COLOR white][B]%s[/B][/COLOR]'
COLOUR10           = '[COLOR yellow][B]%s[/B][/COLOR]'
COLOUR11           = '[COLOR cyan][B]%s[/B][/COLOR]'
LANG               = 'EN'

try:    fanart     = addonParams['fanart'][0]
except: fanart     = FANART

def Parameters():
	for param in addonParams:
		try:
			if any(value == addonParams[param][0] for value in ['None', 'True', 'False', '0', '1']):
				addonParams[param][0] = eval(addonParams[param][0])
		except: pass
	#
	try:    mode   = addonParams['mode'][0]
	except: mode   = None
	try:    link   = addonParams['link'][0]
	except: link   = ''
	try:    name   = addonParams['name'][0]
	except: name   = ''
	try:    icon   = addonParams['icon'][0]
	except: icon   = ''
	try:    fanart = addonParams['fanart'][0]
	except: fanart = ''
	try:    vname  = addonParams['vname'][0]
	except: vname  = None
	try:    extra  = addonParams['extra'][0]
	except: extra  = None
	try:    extra2 = addonParams['extra2'][0]
	except: extra2 = None
	try:    extra3 = addonParams['extra3'][0]
	except: extra3 = None
	try:    html   = addonParams['html'][0]
	except: html   = None
	#
	return mode, link, name, icon, vname, extra, extra2, extra3, html


# #################################################################################################### #


currentSkin        = xbmc.getSkinDir()
if currentSkin == 'skin.estuary':
	noView         = '50'
	listView       = '55'
	bigView        = '55'
	panelView      = '54'
	thumbView      = '52'
	posterView     = '500'
	sliderView     = '51'
elif currentSkin == 'skin.supernova.nova':
	noView         = '50'
	listView       = '50'
	bigView        = '52'
	panelView      = '55'
	thumbView      = '53'
	posterView     = '53'
	sliderView     = '53'
else:
	noView         = '500'
	listView       = '500'
	bigView        = '52'
	panelView      = '50'
	thumbView      = '500'
	posterView     = '500'
	sliderView     = '500'


# #################################################################################################### #


icons = {
	'ACCOUNT_BOX'    : 'https://github.com/google/material-design-icons/raw/master/action/drawable-xxxhdpi/ic_account_box_white_48dp.png',
	'BOOK'           : 'https://github.com/google/material-design-icons/raw/master/action/drawable-xxxhdpi/ic_book_white_48dp.png',
	'CATEGORY'       : 'https://github.com/google/material-design-icons/raw/master/maps/drawable-xxxhdpi/ic_category_white_48dp.png',
	'CHAT'           : 'https://github.com/google/material-design-icons/raw/master/communication/drawable-xxxhdpi/ic_chat_white_48dp.png',
	'DATE_RANGE'     : 'https://raw.githubusercontent.com/google/material-design-icons/master/action/drawable-xxxhdpi/ic_date_range_white_48dp.png',
	'EXPLORE'        : 'https://github.com/google/material-design-icons/raw/master/action/drawable-xxxhdpi/ic_explore_white_48dp.png',
	'FIBER_NEW'      : 'https://github.com/google/material-design-icons/raw/master/av/drawable-xxxhdpi/ic_fiber_new_white_48dp.png',
	'FIRST_PAGE'     : 'https://github.com/google/material-design-icons/raw/master/navigation/drawable-xxxhdpi/ic_first_page_white_48dp.png',
	'HD'             : 'https://github.com/google/material-design-icons/raw/master/av/drawable-xxxhdpi/ic_hd_white_48dp.png',
	'HISTORY'        : 'https://github.com/google/material-design-icons/raw/master/action/drawable-xxxhdpi/ic_history_white_48dp.png',
	'LANGUAGE'       : 'https://github.com/google/material-design-icons/raw/master/action/drawable-xxxhdpi/ic_language_white_48dp.png',
	'LAST_PAGE'      : 'https://github.com/google/material-design-icons/raw/master/navigation/drawable-xxxhdpi/ic_last_page_white_48dp.png',
	'LIVE_TV'        : 'https://github.com/google/material-design-icons/raw/master/notification/drawable-xxxhdpi/ic_live_tv_white_48dp.png',
	'MOVIE'          : 'https://github.com/google/material-design-icons/raw/master/av/drawable-xxxhdpi/ic_movie_white_48dp.png',
	'MOVIE_FILTER'   : 'https://github.com/google/material-design-icons/raw/master/image/drawable-xxxhdpi/ic_movie_filter_white_48dp.png',
	'MUSIC_VIDEO'    : 'https://raw.githubusercontent.com/google/material-design-icons/master/av/drawable-xxxhdpi/ic_music_video_white_48dp.png',
	'PLAYLIST_PLAY'  : 'https://raw.githubusercontent.com/google/material-design-icons/master/av/drawable-xxxhdpi/ic_playlist_play_white_48dp.png',
	'REMOVE_RED_EYE' : 'https://github.com/google/material-design-icons/raw/master/image/drawable-xxxhdpi/ic_remove_red_eye_white_48dp.png',
	'SEARCH'         : 'https://github.com/google/material-design-icons/raw/master/action/drawable-xxxhdpi/ic_search_white_48dp.png',
	'SETTINGS'       : 'https://github.com/google/material-design-icons/raw/master/action/drawable-xxxhdpi/ic_settings_white_48dp.png',
	'SORT_BY_ALPHA'  : 'https://github.com/google/material-design-icons/raw/master/av/drawable-xxxhdpi/ic_sort_by_alpha_white_48dp.png',
	'STAR'           : 'https://github.com/google/material-design-icons/raw/master/toggle/drawable-xxxhdpi/ic_star_white_48dp.png',
	'SUBSCRIPTIONS'  : 'https://raw.githubusercontent.com/google/material-design-icons/master/av/drawable-xxxhdpi/ic_subscriptions_white_48dp.png',
	'TAG_FACES'      : 'https://raw.githubusercontent.com/google/material-design-icons/master/image/drawable-xxxhdpi/ic_tag_faces_white_48dp.png',
	'THEATERS'       : 'https://github.com/google/material-design-icons/raw/master/action/drawable-xxxhdpi/ic_theaters_white_48dp.png',
	'THUMB_UP'       : 'https://github.com/google/material-design-icons/raw/master/action/drawable-xxxhdpi/ic_thumb_up_white_48dp.png',
	'TOYS'           : 'https://github.com/google/material-design-icons/raw/master/hardware/drawable-xxxhdpi/ic_toys_white_48dp.png',
	'WARNING'        : 'https://github.com/google/material-design-icons/raw/master/alert/drawable-xxxhdpi/ic_warning_white_48dp.png',
	'WEEKEND'        : 'https://github.com/google/material-design-icons/raw/master/content/drawable-xxxhdpi/ic_weekend_white_48dp.png',
	'WHATSHOT'       : 'https://github.com/google/material-design-icons/raw/master/social/drawable-xxxhdpi/ic_whatshot_white_48dp.png',
}

images = {
#	'BLACK'        : 'https://v137.xyz/py/v137/img/black.png',
#	'WHITE'        : 'https://v137.xyz/py/v137/img/white.png',
	'BLACK'        : xbmc.translatePath('special://home/addons/script.module.v137/resources/black.png'),
	'WHITE'        : xbmc.translatePath('special://home/addons/script.module.v137/resources/white.png'),
}


# #################################################################################################### #


language = {
	'EN' : {
		'OK'            : 'OK',
		'CANCEL'        : 'Cancel',
		'YES'           : 'Yes',
		'NO'            : 'No',
		'NOTICE'        : 'NOTICE',
		'ATTENTION'     : 'ATTENTION',
		'ATTENTION2'    : 'ATTENTION',
		'ERROR'         : 'Error',
		'SORRY'         : 'Sorry',
		'LOADING'       : 'Loading',
		'WATCH'         : 'Watch',
		'TRAILER'       : 'Trailer',
		'MOREVIDEOS'    : 'MORE VIDEOS',
		'SEARCH'        : 'Search',
		'NEWSEARCH'     : 'NEW SEARCH',
		'ENTERKEYWORD'  : 'Enter Keyword(s) to Search',
		'ENTERPAGENUM'  : 'Enter Page Number',
		'DELETELINE'    : 'DELETE',
		'CLEARALL'      : 'CLEAR ALL',
		'NOTFOUND'      : 'No results found. Please try again.',
		'NOTFOUND2'     : '',
		'GOBACK'        : 'Press BACK / RETURN to go back.',
		'CANNOTPLAY'    : 'Video is not available. Please try another video.',
		'COMINGSOON'    : 'Video coming soon. Please try again later.',
		'VIDEOREMOVED'  : 'Video has been removed.',
		'FIRST'         : 'First',
		'PREVIOUS'      : 'Previous',
		'NEXT'          : 'NEXT',
		'LAST'          : 'LAST',
		'PAGE'          : 'PAGE',
		'SERVER'        : 'Server',
		'SOURCE'        : 'Source',
		'LINK'          : 'Link',
		'EPISODE'       : 'Episode',
		'ALL'           : 'All',
		'MOVIES'        : 'Movies',
		'OFFLINE'       : 'Server is offline. Please try again later.',
		'OFFLINE2'      : '',
		'TRYBROWSER'    : 'TRY LINK IN BROWSER',
		'INSTRUCTIONS'  : 'INSTRUCTIONS',
		'INSTRUCTIONS2' : 'INSTRUCTIONS',
		'PRESSPLAY'     : 'Press PLAY button with mouse to watch...',
		'PRESSPLAY2'    : '',
		'RATERS'        : 'raters',
		'OPENINGLINK'   : 'Opening link...',
		'PLEASEWAIT'    : 'PLEASE WAIT',
		'LAUNCHINGEXT'  : 'Launching video in external player...',
		'TRYINGPROXY'   : 'Trying proxy server...',
		'TRYINGPROXY2'  : 'Trying backup proxy server...',
	},
	'VI' : {
		'OK'            : 'OK',
		'CANCEL'        : 'Cancel',
		'YES'           : 'Yes',
		'NO'            : 'No',
		'NOTICE'        : 'NOTICE',
		'ATTENTION'     : 'CHÚ Ý',
		'ATTENTION2'    : 'CHÚ Ý -- ATTENTION',
		'ERROR'         : 'Báo Lỗi',
		'SORRY'         : 'Xin Lỗi',
		'LOADING'       : 'Đang Tải',
		'WATCH'         : 'Xem | Watch',
		'TRAILER'       : 'Trailer',
		'MOREVIDEOS'    : 'THÊM VIDEOS',
		'SEARCH'        : 'Tìm Kiếm',
		'NEWSEARCH'     : 'TÌM KIẾM MỚI',
		'ENTERKEYWORD'  : 'Nhập Từ Khóa Để Tìm',
		'ENTERPAGENUM'  : 'Nhập Số Trang',
		'DELETELINE'    : 'XÓA HÀNG',
		'CLEARALL'      : 'XÓA TẤT CẢ',
		'NOTFOUND'      : 'Tìm kiếm không có kết quả. Vui lòng thử lại.',
		'NOTFOUND2'     : 'No results found. Please try again.',
		'GOBACK'        : 'Bấm nút BACK / RETURN để trở lui.',
		'CANNOTPLAY'    : 'Phim hiện không xem được. Xin vui lòng thử phim khác.',
		'COMINGSOON'    : 'Phim hiện chưa có. Vui lòng thử lại sau.',
		'VIDEOREMOVED'  : 'Video đã bị xóa.',
		'FIRST'         : 'Đầu Tiên',
		'PREVIOUS'      : 'Trước',
		'NEXT'          : 'KẾ TIẾP',
		'LAST'          : 'CUỐI',
		'PAGE'          : 'TRANG',
		'SERVER'        : 'Server',
		'SOURCE'        : 'Nguồn',
		'LINK'          : 'Link',
		'EPISODE'       : 'Tập',
		'ALL'           : 'Tất Cả',
		'MOVIES'        : 'Phim',
		'OFFLINE'       : 'Trang web tạm đang có lỗi kỹ thuật.',
		'OFFLINE2'      : 'Server is offline. Please try again later.',
		'TRYBROWSER'    : 'THỬ LINK VỚI BROWSER',
		'INSTRUCTIONS'  : 'HƯỚNG DẪN',
		'INSTRUCTIONS2' : 'HƯỚNG DẪN -- INSTRUCTIONS',
		'PRESSPLAY'     : 'Bấm nút PLAY với con chuột để xem...',
		'PRESSPLAY2'    : 'Press PLAY button with mouse to watch...',
		'RATERS'        : 'người đánh giá',
		'OPENINGLINK'   : 'Đang tải...',
		'PLEASEWAIT'    : 'XIN CHỜ',
		'LAUNCHINGEXT'  : 'Launching video in external player...',
		'TRYINGPROXY'   : 'Trying proxy server...',
		'TRYINGPROXY2'  : 'Trying backup proxy server...',
	}
}


# #################################################################################################### #


def OK(title='', message='', message2='', message3='', titleColour=COLOUR10, messageColour=COLOUR0, messageColour2=COLOUR0, messageColour3=COLOUR0):
	xbmcgui.Dialog().ok(titleColour % str(title), messageColour % str(message), messageColour2 % str(message2), messageColour3 % str(message3))

def Offline(titleColour=COLOUR10, messageColour=COLOUR0, lang=LANG):
	xbmcgui.Dialog().ok(titleColour % language[lang]['ATTENTION2'], messageColour % language[lang]['OFFLINE'], messageColour % language[lang]['OFFLINE2'])

def Popup2(title='', message='', message2='', message3='', titleColour=COLOUR10, messageColour=COLOUR0, messageColour2=COLOUR0, messageColour3=COLOUR0, lang=LANG):
	xbmcgui.Dialog().ok(titleColour % language[lang][title], messageColour % language[lang][message], messageColour2 % language[lang][message2])

def DialogProgress(msg1='', msg2='', allowCancel=True):
	pDialog = xbmcgui.DialogProgress()
	pDialog.create(msg1, msg2)
	if not allowCancel:
		pDialog_Window = xbmcgui.Window(10101)
		pDialog_cancelButton = pDialog_Window.getControl(10)
		pDialog_cancelButton.setEnabled(False)
	return pDialog

def Notification(title, message='', icon='', time=5000, sound=False):
	popup = xbmcgui.Dialog()
	popup.notification(title, message, icon, time, sound)
	return popup

# #################################################################################################### #


def ParseLink(query):
	return addonBase + '?' + urllib.urlencode(query)

def AddItem(mode, link, name, icon, fanart=fanart, vname=None, extra=None, extra2=None, extra3=None, html=None, folder=True, playable=False, year='', rating='', genre='', plot='', duration='', context=None, contextReplace=False):
	li = xbmcgui.ListItem(name, iconImage=icon, thumbnailImage=icon)
	li.setProperty('fanart_image', fanart)
	# SETS PLAYABLE ITEM / NON-FOLDER
	if playable:
		li.setProperty('IsPlayable', 'true')
	li.setInfo(type='video', infoLabels={'year': year, 'rating': rating, 'genre': genre, 'plot': plot, 'duration': duration})
	# ADD CONTEXT MENU ITEMS
	if context:
		li.addContextMenuItems(context, replaceItems=contextReplace)
	if link.startswith('plugin://'):
		pass
	else:
		link = ParseLink({'mode': mode, 'link': link, 'name': name, 'icon': icon, 'fanart': fanart, 'vname': vname, 'extra': extra, 'extra2': extra2, 'extra3': extra3, 'html': html})
	xbmcplugin.addDirectoryItem(handle=addonHandle, url=link, listitem=li, isFolder=folder)
	return 1

def EndItems(cache=True, contentType='Files', viewMode=listView):
	# SET VIEW MODE
	xbmcplugin.setContent(addonHandle, contentType)
	xbmc.executebuiltin('Container.SetViewMode(%s)' % viewMode)
	# END DIR
	xbmcplugin.endOfDirectory(addonHandle, cacheToDisc=cache)

def SetResolved(link, name='', icon='',  mimeType='', setResolved=True):
	if DEBUG: Log('| Resolved | %s' % link)
	li = xbmcgui.ListItem(name, path=link, thumbnailImage=icon)
	if any(ext in link for ext in videoExtensions) or mimeType == 'video/mp4':
		li.setContentLookup(False)
		li.setMimeType('video/mp4')
	elif any(ext in link for ext in liveExtensions) or mimeType == 'application/x-mpegURL':
		li.setContentLookup(False)
		li.setMimeType('application/x-mpegURL')
	if setResolved:
		xbmcplugin.setResolvedUrl(addonHandle, True, li)
	return li

def Player(link, name='', icon='', mimeType=''):
	li = SetResolved(link, name, icon, mimeType, setResolved=False)
	player = xbmc.Player()
	player.play(link, listitem=li)
	return player

def Playlister(links, mimeType=''):
	# links = {0: {'link': link0, 'name': name0, 'icon': icon0}, 1: {'link': link1, 'name': name1, 'icon': icon1}}
	playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
	player   = xbmc.Player()
	playlist.clear()
	for index in links:
		link = links[index]['link']
		name = links[index]['name']
		icon = links[index]['icon']
		item = SetResolved(link, name, icon, mimeType, setResolved=False)
		playlist.add(link, item)
		if DEBUG: Log('| +Playlist | %s' % link)
	player.play(playlist)
	return player


# #################################################################################################### #


extPlayers = {
	'CHROME'     : {
		'package'  : 'com.android.chrome',
		'activity' : 'com.google.android.apps.chrome.Main',
	},
	'MXPLAYER'     : {
		'package'  : 'com.mxtech.videoplayer.pro',
		'activity' : 'com.mxtech.videoplayer.pro.ActivityScreen',
	},
	'VLC'          : {
		'package'  : 'org.videolan.vlc',
		'activity' : 'org.videolan.vlc.gui.video.VideoPlayerActivity',
	},
	'WISEPLAY'     : {
		'package'  : 'com.wiseplay',
		'activity' : 'com.wiseplay.activities.ExternalPlayerActivity',
	},
	'WISEPLAYLIST' : {
		'package'  : 'com.wiseplay',
		'activity' : 'com.wiseplay.activities.MainActivity',
	},
}

def ExtLauncher(uri, player, lang=LANG):
	package  = extPlayers[player.upper()]['package']
	activity = extPlayers[player.upper()]['activity']
	intent   = 'android.intent.action.VIEW'
	#
	if not ExtPlayer(package, activity, intent, uri):
		if ExtInstaller(package):
			return ExtPlayer(package, activity, intent, uri)
	return ''

def ExtPlayer(package, activity, intent, uri, lang=LANG):
	if DEBUG: Log('| EXTERNAL PLAYER | %s' % uri)
	if Android:
	#	result = subprocess.Popen(['exec su -c "/system/bin/am start -n %s/%s -a %s -d \'%s\'"' % (package, activity, intent, uri)], executable='/system/bin/sh', shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT).communicate()[0]
		result = subprocess.Popen(['/system/bin/am start --user 0 -n %s/%s -a %s -d "%s"' % (package, activity, intent, uri)], executable='/system/bin/sh', shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT).communicate()[0]
		result = result.rstrip('\n')
		if 'Error' in result:
			return False
		else:
			return True
	else:
		xbmcgui.Dialog().ok(COLOUR10 % language[LANG]['NOTICE'], COLOUR0 % language[LANG]['LAUNCHINGEXT'])
		return True

def ExtInstaller(package):
	HELPER = 'special://home/addons/%s/default.py' % re.compile('\((.+?)\)').findall(xbmc.getInfoLabel('Skin.String(Custom_Helper)'))[0]
	result = xbmc.executebuiltin('RunScript(%s, %s)' % (HELPER, 'mode=AUTOINSTALL&link=%s' % package))
	return result


# #################################################################################################### #

def Input(command):
	xbmc.executeJSONRPC('{"jsonrpc": "2.0", "id": 1, "method": "Input.%s"}' % command)

# #################################################################################################### #


MAXHISTORY         = 25

def Search(url, mode, index, colour=COLOUR10, lang=LANG):
	if not mode and not url:
		pass
	elif mode == 'INDEX':
		return url
	elif mode == 'NEW':
		history = GetHistory()
		url = SearchBox(url, history, lang)
		return url
	elif mode == 'DELETE':
		DeleteHistory(url, index, lang)
		return None
	else:
		history = GetHistory()
		if history:
			History(url, history, colour, lang)
			return None
		else:
			url = SearchBox(url, history, lang)
			return url

def GetHistory():
	try:
		history = eval(addon.getSetting('history'))
	except:
		history = []
		addon.setSetting('history', repr(history))
	return history

def History(url, history, colour=COLOUR10, lang=LANG):
	contextMenu = [(COLOUR0 % language[lang]['CLEARALL'], 'XBMC.RunAddon(%s, mode=SEARCH&extra=DELETE)' % addonId)]
	AddItem('SEARCH', url, COLOUR0 % language[lang]['NEWSEARCH'], icons['SEARCH'], extra='NEW', context=contextMenu)
	for i, searchText in enumerate(reversed(history)):
		num = abs(i-len(history))
		searchText = urllib.unquote(searchText)
		contextMenu = [
			(COLOUR0 % language[lang]['DELETELINE'], 'XBMC.Container.Update(plugin://%s?mode=SEARCH&extra=DELETE&extra2=%d)' % (addonId, num)),
			(COLOUR0 % language[lang]['CLEARALL'], 'XBMC.RunAddon(%s, mode=SEARCH&extra=DELETE)' % addonId)
		]
		if '%s' in url:
			AddItem('SEARCH', url % searchText, colour % urllib.unquote(searchText), icons['HISTORY'], extra='INDEX', context=contextMenu)
		else:
			AddItem('SEARCH', url, colour % urllib.unquote(searchText), icons['HISTORY'], extra='INDEX', extra2=searchText, context=contextMenu)
	EndItems(viewMode=listView)

def SearchBox(url, history=[], lang=LANG):
	kb = xbmc.Keyboard('', COLOUR0 % '%s:' % language[lang]['ENTERKEYWORD'])
	kb.doModal()
	if (kb.isConfirmed()):
		searchText = kb.getText()
		if searchText:
			try:
				if len(history) >= MAXHISTORY: del history[0]
				history.append(urllib.quote(searchText))
				addon.setSetting('history', repr(history))
			except Exception, e:
				if DEBUG: Log('| SEARCH ERROR | %s' % e)
			if DEBUG: Log('| SEARCH | %s' % searchText)
			if '%s' in url:
				url = url % searchText
			else:
				url = searchText
			return url
	return None

def DeleteHistory(url, num, lang=LANG):
	try:
		num = int(num)-1
		history = eval(addon.getSetting('history'))
		del history[num]
		addon.setSetting('history', repr(history))
		if not history:
			raise
		else:
			xbmc.executebuiltin('Container.Refresh')
	except:
		history = []
		addon.setSetting('history', repr(history))
		AddItem(None, None, COLOUR0 % language[LANG]['GOBACK'], icons['WARNING'], folder=False)
		EndItems(viewMode=listView)

# #################################################################################################### #


def Info(title, thumb, info, plot, fanart, trailer=None, lang=LANG, offset=0):

	ACTION_MOVE_LEFT     = 1
	ACTION_MOVE_RIGHT    = 2
	ACTION_MOVE_UP       = 3
	ACTION_MOVE_DOWN     = 4
	ACTION_ENTER         = 7
	ACTION_PREVIOUS_MENU = 10
	ACTION_I             = 11
	ACTION_STOP          = 13
	ACTION_TAB           = 18
	ACTION_BACK          = 92

	class InfoWindow(xbmcgui.WindowDialog):
		def __init__(self):
			# MAIN WINDOW
			self.window = xbmcgui.ControlImage(x=0, y=0, width=1280, height=720, filename=fanart, aspectRatio=0, colorDiffuse='0xFF666666')
			self.addControl(self.window)
			# IMAGE
			self.imageWindow = xbmcgui.ControlImage(x=47, y=47, width=321, height=426, filename=images['WHITE'], aspectRatio=0, colorDiffuse='0x55FFFFFF')
			self.addControl(self.imageWindow)
			self.image = xbmcgui.ControlImage(x=50, y=50, width=315, height=420, filename=thumb, aspectRatio=1)
			self.addControl(self.image)
			# TEXT
			self.textWindow = xbmcgui.ControlImage(x=400, y=50, width=830, height=620, filename=images['BLACK'], aspectRatio=0, colorDiffuse='0x88444444')
			self.addControl(self.textWindow)
			self.title = xbmcgui.ControlLabel(x=420, y=60, width=790, height=30, label=title, textColor='', alignment=0)
			self.addControl(self.title)
			self.textbox1 = xbmcgui.ControlTextBox(x=420, y=110, width=790, height=220+offset, textColor='')
			self.addControl(self.textbox1)
			self.textbox1.setText(info)
			self.textbox1.autoScroll(2500, 2500, 2500)
			self.textbox2 = xbmcgui.ControlTextBox(x=420, y=345+offset, width=790, height=305-offset, textColor='')
			self.addControl(self.textbox2)
			self.textbox2.setText(plot)
			self.textbox2.autoScroll(2500, 2500, 2500)
			# BUTTON
			label1 = language[lang]['WATCH']
			label2 = language[lang]['TRAILER']
			self.button1 = xbmcgui.ControlButton(x=50, y=505, width=315, height=70, label=label1, focusTexture=images['WHITE'], noFocusTexture=images['BLACK'], textColor='0x88888888', alignment=6, disabledColor='0x88888888', focusedColor='0xEE1111111')
			self.addControl(self.button1)
			self.setFocus(self.button1)
			if trailer:
				self.button2 = xbmcgui.ControlButton(x=50, y=600, width=315, height=70, label=label2, focusTexture=images['WHITE'], noFocusTexture=images['BLACK'], textColor='0x88888888', alignment=6, disabledColor='0x88888888', focusedColor='0xEE1111111')
				self.addControl(self.button2)

		def onAction(self, action):
			if action == ACTION_PREVIOUS_MENU or action == ACTION_BACK:
				self.close()
				self.prompt = 'BACK'
			if trailer:
				if action == ACTION_MOVE_UP:
					self.setFocus(self.button1)
					self.prompt = 'PLAY'
				if action == ACTION_MOVE_DOWN:
					self.setFocus(self.button2)
					self.prompt = 'PREVIEW'

		def onControl(self, control):
			if control == self.button1:
				self.close()
				self.prompt = 'PLAY'
			if trailer:
				if control == self.button2:
					self.close()
					self.prompt = 'PREVIEW'

		def Response(self):
			return self.prompt

	window = InfoWindow()
	window.setCoordinateResolution(2)
	while True:
		window.doModal()
		prompt = window.Response()
		if prompt == 'PREVIEW':
			url = Resolver(trailer)
			player = Player(url, title, thumb)
			xbmc.sleep(5000)
			playing = player.isPlaying()
			while playing:
				xbmc.sleep(1000)
				playing = player.isPlaying()
		else:
			break
	return prompt


# #################################################################################################### #


xxxFilter = ['phim 18', '18+', '18 +', 'phim xxx', ' ova ', 'hentai', u'cấp 3', u'cap 3',]

def AdultCheck(data):
	if any(keyword in data.lower() for keyword in xxxFilter):
		if xbmc.getCondVisibility('System.HasLocks'):
			if xbmc.getCondVisibility('System.IsMaster'):
				return True
			else:
				profilesXML = os.path.join(xbmc.translatePath('special://userdata'), 'profiles.xml')
				with open(profilesXML, 'rb') as f:
					profiles = f.read()
				code = re.compile('<lockcode>(.+?)</lockcode>').findall(profiles)[0]
				maxtries = 3
				tries = 0
				while tries < maxtries:
					tries += 1
					dialog = xbmcgui.Dialog()
					prompt = dialog.input('Enter Master Lock Code', type=xbmcgui.INPUT_NUMERIC, option=xbmcgui.ALPHANUM_HIDE_INPUT)
					if hashlib.md5(prompt).hexdigest() == code:
						return True
					else:
						if tries == maxtries-1:
							xbmcgui.Dialog().ok('Master Lock Code', 'Access denied', '1 try left')
						elif tries < maxtries:
							xbmcgui.Dialog().ok('Master Lock Code', 'Access denied', '%s tries left' % (maxtries-tries))
				return False
	return True


# #################################################################################################### #
#
# NETWORK
#
# #################################################################################################### #


mirrorUrl          = 'https://v137.xyz/p/px?r=%s&src=%s'
mirrorAgent        = 'V137'
decodeAgent        = 'V137'
userAgent          = 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36'
userAgent_iPad     = 'Mozilla/5.0 (iPad; CPU OS 8_1_3 like Mac OS X) AppleWebKit/600.1.4 (KHTML, like Gecko) Version/8.0 Mobile/12B466 Safari/600.1.4'
userAgent_Pool     = [
'Mozilla/5.0 (iPad; CPU OS 8_1_3 like Mac OS X) AppleWebKit/600.1.4 (KHTML, like Gecko) Version/8.0 Mobile/12B466 Safari/600.1.4',
'Mozilla/5.0 (iPhone; CPU iPhone OS 8_0_2 like Mac OS X) AppleWebKit/600.1.4 (KHTML, like Gecko) Version/8.0 Mobile/12A366 Safari/600.1.4',
'Opera/9.80 (Macintosh; Intel Mac OS X 10.6.8; U; en) Presto/2.9.168 Version/11.52',
'Mozilla/5.0 (compatible; WOW64; MSIE 10.0; Windows NT 6.2)',
'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/535.11 (KHTML, like Gecko) Ubuntu/11.10 Chromium/27.0.1453.93 Chrome/27.0.1453.93 Safari/537.36',
'Opera/9.80 (Windows NT 6.1; WOW64; U; en) Presto/2.10.229 Version/11.62',
'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2486.0 Safari/537.36 Edge/13.10586',
]
proxies_VN1        = {
'http'  : '124.158.4.3:8080',
} # https://www.proxynova.com/proxy-server-list/country-vn/
proxies_VN2        = {
'http'  : '103.74.120.139:3128',
}


# #################################################################################################### #


if not os.path.exists(userPath):
	os.makedirs(userPath)


# PERSIST COOKIES ACROSS SESSIONS
cookieJar          = os.path.join(userPath, 'cookiejar.lwp')
cj                 = cookielib.LWPCookieJar(cookieJar)
if not os.path.exists(cookieJar):
	cj.save()
else:
	try:
		cj.load(ignore_discard=True)
	except:
		os.remove(cookieJar)
		cj.save()

s                  = requests.session()


# #################################################################################################### #


def Request(url,
	allowRedirects = True,
	params         = None,
	getStatus      = False,
	getRedirect    = False,
	getHeaders     = False,
	post           = False,
	data           = None,
	multipart      = False,
	files          = None,
	userAgent      = userAgent,
	referer        = '',
	cleanUrl       = True,
	unicodeUrl     = True,
	pipeHeaders    = False,
	extendHeaders  = None,
	useCookies     = True,
	getCookies     = False,
	encoding       = 'utf-8',
	minify         = False,
	soup           = False,
	parser         = 'html5lib',
	strainer       = None,
	cloudflare     = False,
	mirror         = False,
	mirrorUrl      = mirrorUrl,
	mirrorAgent    = mirrorAgent,
	proxies        = None,
	timeout        = (3.05, 15),
	):
	headers    = {
		'User-Agent'      : userAgent,
		'Accept-Encoding' : 'gzip, deflate, sdch',
		'Referer'         : referer
	}
	if pipeHeaders:
		url, piped = PipeHeaders(baseUrl, getHeaders=True)
		headers.update(piped)
	else:
		url = PipeHeaders(url, getHeaders=False)
	if extendHeaders:
		headers.update(extendHeaders)
	try:
		if cleanUrl:
			url = CleanUrl(url, unicodeUrl)
		if useCookies:
			s.cookies = cj
		if not getRedirect and not getStatus and not getHeaders:
			if DEBUG: Log('| Requesting URL | %s%s%s%s' % (url, ' | %s' % params if params else '', ' | %s' % data if data else '', ' | %s' % files if files else ''))
			if cloudflare:
				import cfscrape
				scraper = cfscrape.create_scraper()
				r = scraper.get(url).content
				src = r.decode(encoding)
			else:
				if post:
					headers.update({'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'})
					if proxies:
						if DEBUG: Log('| Proxying... | %s' % proxies)
						r = s.post(url=url, params=params, headers=headers, data=data, verify=False, timeout=timeout, proxies=proxies)
					else:
						r = s.post(url=url, params=params, headers=headers, data=data, verify=False, timeout=timeout)
				elif multipart:
					if proxies:
						if DEBUG: Log('| Proxying... | %s' % proxies)
						r = s.post(url=url, params=params, headers=headers, files=files, data=data, verify=False, timeout=timeout, proxies=proxies)
					else:
						r = s.post(url=url, params=params, headers=headers, files=files, data=data, verify=False, timeout=timeout)
				else:
					if mirror:
						rd = ''.join(random.SystemRandom().choice(string.ascii_uppercase + string.digits) for _ in range(505))
						url = mirrorUrl % (rd,  urllib.quote(url))
						headers.update({
							'User-Agent': mirrorAgent
						})
					if proxies:
						if DEBUG: Log('| Proxying... | %s' % proxies)
						r = s.get(url=url, allow_redirects=allowRedirects, params=params, headers=headers, verify=False, timeout=timeout, proxies=proxies)
					else:
						r = s.get(url=url, allow_redirects=allowRedirects, params=params, headers=headers, verify=False, timeout=timeout)
					if DEBUG: 
						status = r.history
						response = r.url
						if any(s in str(status) for s in ['300', '301', '302', '303', '304', '305', '306', '307', '308']):
							Log('| %s Redirected | %s' % (status, response))
				if DEBUG: Log('| Response | %s' % r.status_code)
				r.encoding = encoding
				src = r.text
			if soup:
				response = Soup(src, parser=parser, strainer=strainer)
			else:
				if minify:
					response = Minify(src)
				else:
					response = src
		elif getStatus:
			r = s.get(url=url, headers=headers, stream=True, verify=False, timeout=timeout)
			response = r.status_code
			if DEBUG: Log('| Status: %s | %s' % (response, url))
		elif getRedirect:
			if DEBUG: Log('| Checking for Redirect... | %s' % url)
			r = s.get(url=url, headers=headers, stream=True, allow_redirects=False, verify=False, timeout=timeout)
			status = r.status_code
			if status >= 300 and status <= 308:
				response = r.headers['location']
				if DEBUG: Log('| %s Redirection | %s' % (status, response))
			else:
				response = url
		elif getHeaders:
			r = s.get(url=url, headers=headers, stream=True, verify=False, timeout=timeout)
			response = r.headers
		if getCookies:
			try:
				cj.save()
			except:
				pass
			return response, r.cookies
		else:
			if useCookies:
				try:
					cj.save()
				except:
					pass
			return response
	except Exception, e:
		if DEBUG: Log('| REQUEST ERROR | %s' % e)
		return ''


# #################################################################################################### #


def Soup(src, parser='html5lib', strainer=None):
	# CLEAN UP BEFORE MAKING SOUP
#	src = re.sub('(<!\[CDATA\[.+?\]\]\>)', '', src)
	replacements = [
		('h"+"tml', 'html'),
		('ht"+"ml', 'html'),
		('htm"+"l', 'html'),
		('b"+"ody', 'body'),
		('bo"+"dy', 'body'),
		('bod"+"y', 'body'),
		("s'+'cript", "script"),
		("sc'+'ript", "script"),
		("scr'+'ipt", "script"),
		("scri'+'pt", "script"),
		("scrip'+'t", "script"),
	]
	for rep in replacements:
		src = src.replace(rep[0], rep[1])
	#
	soup = BeautifulSoup(src, parser, parse_only=strainer)
	return soup

def JSON(src):
	try:
		result = json.loads(src)
	except Exception, e:
		if DEBUG: Log('| JSON ERROR | %s' % e)
		result = []
	return result

def PreJSON(src, force=False):
	src = Minify(src, doQuotes=True, removeSpaces=True)
	# STANDARDIZE ALL
	try:
		src = src.decode('unicode_escape')
	except: pass
	# STANDARDIZE BEFORE COLON
	src = src.replace('default:', '"default":').replace('file:', '"file":').replace('label:', '"label":').replace('link:', '"link":').replace('sources:', '"sources":').replace('src:', '"src":').replace('type:', '"type":').replace('url:', '"url":')
	# STANDARDIZE AFTER COLON
	src = src.replace(':Auto', ':"Auto"').replace(':auto', ':"auto"').replace(':True', ':"True"').replace(':False', ':"False"').replace(':1080', ':"1080"').replace(':720', ':"720"').replace(':576', ':"576"').replace(':480', ':"480"').replace(':360', ':"360"').replace(':240', ':"240"')
	if force:
		# PLACEHOLDER FOR EMPTY STRINGS
		src = src.replace('""', '@NULL@')
		# PAD QUOTES TO START CHARACTERS
		src = src.replace('[', '["').replace('{', '{"')
		# PAD QUOTES TO MIDDLE CHARACTERS
		src = src.replace(',', '","').replace(':', '":"')
		# PAD QUOTES TO END CHARACTERS
		src = src.replace(']', '"]').replace('}', '"}')
		# CLEAN UP PADDING
		while '""' in src:
			src = src.replace('""', '"')
		# CLEAN UP FOR START CHARACTERS
		src = src.replace('["{', '[{')
		# CLEAN UP FOR MIDDLE CHARACTERS
		src = src.replace('}","{', '},{').replace(':"[', ':[')
		# CLEAN UP FOR END CHARACTERS
		src = src.replace('}"}', '}}').replace(']"}', ']}').replace('}"]', '}]')
		# PUT BACK PLACEHOLDER FOR EMPTY STRINGS
		src = src.replace('@NULL@', '')
	return src

def Minify(src, doQuotes=False, removeSpaces=False):
	src = String(src)
	if doQuotes:
		src = ''.join(src.splitlines()).replace('\'', '"')
	src = src.replace('\n', '')
	src = src.replace('\t', '')
	src = re.sub('  +', ' ', src)
	src = src.replace('> <', '><')
	if removeSpaces:
		src = src.replace(' ', '')
	return src

def FormatUrl(url, domain='', cleanUrl=True, unicodeUrl=True):
	url = url.strip()
	if not url:
		url = domain
	if url.startswith('http') or url.startswith('rtmp'):
		pass
	elif url.startswith('//'):
		url = 'http://%s' % url.lstrip('//')
	elif url.startswith('/'):
		url = '%s/%s' % ('%s://%s' % (urlparse.urlparse(domain).scheme, urlparse.urlparse(domain).netloc), url.lstrip('/'))
	elif url.startswith('./'):
		return '%s/%s' % ('%s://%s' % (urlparse.urlparse(domain).scheme, urlparse.urlparse(domain).netloc), url.lstrip('./'))
	else:
		if domain.count('/') > 2:
			url = '%s/%s' % (domain.rsplit('/', 1)[0], url.lstrip('/'))
		else:
			url = '%s/%s' % (domain, url)
	if cleanUrl:
		url = CleanUrl(url, unicodeUrl)
	return url

def CleanUrl(url, unicodeUrl=True):
	url = url.replace('\/', '/')
	url = url.replace(' ', '%20')
	if unicodeUrl:
		url = UnicodeUrl(url)
	return url

def GetDomain(url):
	return urlparse.urlparse(url).netloc

def PipeHeaders(baseUrl, getHeaders=False):
	baseUrl = urllib.unquote(baseUrl)
	if any(header.lower() in baseUrl.lower() for header in ['|Cookie', '|Referer', '|User-Agent', '|X-Forwarded-For',]):
		url, params = baseUrl.split('|')
		params = urlparse.parse_qs(params)
		if getHeaders:
			headers = {}
			for param in params:
				headers.update({param:params[param][0]})
			return url, headers
		else:
			return url
	else:
		return baseUrl

def UnicodeUrl(url):
	# https://stackoverflow.com/questions/804336/best-way-to-convert-a-unicode-url-to-ascii-utf-8-percent-escaped-in-python
	# TURN STRING INTO UNICODE
	if not isinstance(url,unicode):
		url = url.decode('utf8')
	# PARSE IT
	parsed = urlparse.urlsplit(url)
	# DIVIDE THE NETLOC FURTHER
	userpass,at,hostport = parsed.netloc.rpartition('@')
	user,colon1,pass_ = userpass.partition(':')
	host,colon2,port = hostport.partition(':')
	# ENCODE EACH COMPONENT
	scheme = parsed.scheme.encode('utf8')
	user = urllib.quote(user.encode('utf8'))
	colon1 = colon1.encode('utf8')
	pass_ = urllib.quote(pass_.encode('utf8'))
	at = at.encode('utf8')
	host = host.encode('idna')
	colon2 = colon2.encode('utf8')
	port = port.encode('utf8')
	path = '/'.join(  # COULD BE ENCODED SLASHES!
		urllib.quote(urllib.unquote(pce).encode('utf8'),'')
		for pce in parsed.path.split('/')
	)
	query = urllib.quote(urllib.unquote(parsed.query).encode('utf8'),'=&?/~*')
	fragment = urllib.quote(urllib.unquote(parsed.fragment).encode('utf8'))
	# PUT IT BACK TOGETHER
	netloc = ''.join((user,colon1,pass_,at,host,colon2,port))
	return urlparse.urlunsplit((scheme,netloc,path,query,fragment))


# #################################################################################################### #
#
# RESOLVE
#
# #################################################################################################### #


videoExtensions    = [
'.avi', 'mkv', '.mp4', '.ts',
]

liveExtensions     = [
'.ism', '.m3u8', '.mpd', '.f4m', '.smil', '.ts',
]

popoutDomains      = [
'oload',
'openload.',
]


def Resolver(url, name='', icon='', referer=userAgent, lang=LANG):
	if url.startswith('resolve://'):
		resolver, url = re.compile('resolve:\/\/(.+?)@(.*)').findall(url)[0]
		if resolver.lower() == 'youtube':
			src = YouTubeLinkFinder(url)
		else:
			src = url
	elif any(domain in url for domain in ['openload.co/stream/']): # PASS THROUGH
		src = CleanUrl(url, unicodeUrl=False)
	elif '4sync.' in url:
		src = FourSync(url)
	elif 'bp.blogspot.' in url:
		src = Blogspot(url, lang)
	elif 'docs.googleusercontent.com/docs/securesc/' in url:
		ExtLauncher(url, 'WISEPLAY', lang=lang)
		src = None
#	elif 'drivez.' in url:
#		src = Drivez(url)
	elif 'fbcdn.net' in url:
		src = FBCDN(url)
	elif 'fembed.' in url:
		src = Fembed(url)
	elif any(domain in url for domain in ['docs.google.', 'drive.google.', 'video.google.', 'googleusercontent.', 'googlevideo.', 'youtube.googleapis.']):
		src = GoogleDocs(url)
	elif 'h265.se' in url:
		src = H265SE(url)
	elif 'hdplay.se' in url:
		src = HDPlaySE(url)
	elif 'matchat.' in url:
		src = Matchat(url)
	elif 'mediafire.' in url:
		src = MediaFire(url, iframe='')
	elif 'mycujoo.' in url:
		src = Mycujoo(url)
	elif 'ndha.' in url:
		src = NDHA(url)
	elif any(domain in url for domain in ['oload.', 'openload.']):
		url = PipeHeaders(url)
		src = Openload(url, name, icon, lang=lang)
	elif 'ok.ru' in url:
		if DEBUG:
			src = OKRU(url)
		else:
			try:
				src = OKRU(url)
			except:
				OK(title=language[LANG]['SORRY'], message=language[LANG]['VIDEOREMOVED'])
				sys.exit()
	elif 'rapidvideo.' in url:
		src = RapidVideo(url)
	elif 'streamable.' in url:
		src = Streamable(url)
	elif 'userscloud.' in url:
		src = UsersCloud(url)
	elif 'vcstream.' in url:
		src = VCStream(url)
	elif 'vev.io' in url:
		src = VEVIO(url)
	elif any(domain in url for domain in ['youtube.', 'youtu.be']):
		src =  YouTube(url)
	elif 'zing.vn' in url:
		src = ZingVN(url)
	elif any(domain in url for domain in ['dailymotion.', 'drivez', 'oload.', 'openload.', 'streamango.']):
		src = UrlResolver(url, lang)
	else:
		src = CleanUrl(url, unicodeUrl=False)
	return src

def LinkFinder(baseSrc, url='', forcePreJSON=False, formatUrl=True):
	src = String(baseSrc)
	items = []
	file  = None
	src = PreJSON(src, force=forcePreJSON)
	if '<source' in src:
		soup = Soup(src)
		items.extend([soup.find('source')['src']])
	if '"file":"' in src:
		items.extend(re.compile('"file":"([^"]*)"').findall(src))
	if '"link":"' in src:
		items.extend(re.compile('"link":"([^"]*)"').findall(src))
	if '"source":"' in src:
		items.extend(re.compile('"source":"([^"]*)"').findall(src))
	if '"src":"' in src:
		items.extend(re.compile('"src":"([^"]*)"').findall(src))
	if '"url":"' in src:
		items.extend(re.compile('"url":"([^"]*)"').findall(src))
	if not items:
		try:
			vars = re.compile('"([^"]*)"').findall(src)
			for var in vars:
				if any(ext in var for ext in videoExtensions) or any(ext in var for ext in liveExtensions):
					items.extend([var])
		except Exception, e:
			if DEBUG: Log('| RE ERROR | %s' % e)
	if not items:
		return url
	elif len(items) == 1:
		file = items[0]
	else:
		for item in items:
			if any(ext in item for ext in videoExtensions) or any(ext in item for ext in liveExtensions):
				file = item
		if not file:
			file = items[-1] # CHOOSE LAST
	if formatUrl:
		src = FormatUrl(file, url)
	else:
		src = file
	if DEBUG: Log('| Link Found | %s' % src)
	return src

def LinksFinder(baseSrc, url='', forcePreJSON=False, chooseRes=True, formatUrl=True):
	src = String(baseSrc)
	src = PreJSON(src, force=forcePreJSON)
	j = []
	if not j and '"sources":' in src:
		sources = re.compile('"sources":\s?(\[.+?\])').findall(src)
		for source in sources:
			if DEBUG: Log('| SOURCES: | %s' % source)
			j = JSON(source)
			if j: break
	if not j and any(s in src for s in ['sources=', 'sources =']):
		sources = re.compile('sources\s?=\s?(\[[^;]*)').findall(src)
		for source in sources:
			if DEBUG: Log('| SOURCES= | %s' % source)
			j = JSON(source)
			if j: break
	if not j:
		j = JSON(src)
	links = []
	for i, source in enumerate(j):
		if 'label' in source:
			label = source['label']
		else:
			label = 'Link %s' % i
		if 'file' in source:
			file = source['file']
		elif 'link' in source:
			file = source['link']
		elif 'source' in source:
			file = source['source']
		elif 'src' in source:
			file = source['src']
		elif 'url' in source:
			file = source['url']
		else:
			file = ''
		if DEBUG: Log('| %s | %s' % (label, file))
		links.append((label, file))
	if not links:
		return url
	else:
		if chooseRes:
			link = ChooseRes(links)
			if formatUrl:
				link = FormatUrl(link, url)
			if DEBUG: Log('| Link Found | %s' % link)
			return link
		else:
			if DEBUG: Log('| Links Found | %s' % str(links))
			return links

def iFrameFinder(baseSrc, url='', formatUrl=True):
	links = []
	src = Minify(baseSrc)
	iframes = re.compile('<iframe.+?src="?([^"|\s]*)').findall(src)
	for iframe in iframes:
		links.append(iframe)
	if len(links) == 0:
		return None
	elif len(links) == 1:
		link = links[0]
	else:
		link = max(links, key=len)
	if formatUrl:
		link = FormatUrl(link, url)
	if DEBUG: Log('| iFrame Found | %s' % link)
	return link

def ChooseRes(src, maxres=15, auto=True):
	if DEBUG: auto = False
	resolution    = {
		16 : 'FULL',
		15 : '1080',
		14 : '720',
		13 : 'HD',
		12 : 'HQ',
		11 : '576',
		10 : '540',
		9  : 'MQ',
		8  : '480',
		7  : '360',
		6  : 'SD',
		5  : 'Auto',
		4  : '240',
		3  : 'LQ',
		2  : 'LOW',
		1  : 'LOWEST',
		0  : 'MOBILE',
		-1 : None,
	}
	# Forces order: 0. Label, 1. Link
	src2 = []
	if '//' in str(src[0][0]):
		for link, label in src:
			src2.append((label, link))
	else:
		src2 = src
	# Passes single Link
	if len(src2) == 1:
		return src2[0][1]
	else:
		if auto:
		# Auto chooses maximum resolution from settings
			for res in reversed(range(len(resolution))):
				if res <= maxres:
					for i, (label, link) in enumerate(src2):
						if resolution[res].upper() in str(label).upper():
							return link
		# Prompts user to choose resolution
		labels = [('[COLOR white][B]%s[/B][/COLOR]' % label) for label, link in src2]
		dialog = xbmcgui.Dialog()
		prompt = -1
		prompt = dialog.select('Choose / Chọn:', labels)
		if prompt == -1:
			link = None
		else:
			link = src2[prompt][1]
		return link

def FourSync(baseUrl):
	html = Request(baseUrl)
	link = LinkFinder(html)
	link = '%s|Referer=%s' % (link, baseUrl)
	return link

def Blogspot(baseUrl, lang=LANG):
	dialog = DialogProgress(msg1=language[lang]['PLEASEWAIT'], msg2=language[lang]['OPENINGLINK'])
	for i in range(0,30):
		src = Request(baseUrl, userAgent=random.choice(userAgent_Pool), useCookies=False, getRedirect=True, cleanUrl=False)
		if src == baseUrl:
			xbmc.sleep(1000)
		else:
			break
		if dialog.iscanceled():
			sys.exit()
		if DEBUG: Log('| %s |' % i)
	dialog.close()
	del dialog
	return src

def Drivez(baseurl):
	soup = Request(baseurl, soup=True)
	if '{file:' in str(soup):
		url = LinkFinder(baseurl, str(soup))
	elif '<source' in str(soup):
		url = soup.find('source')['src']
	elif '<iframe' in str(soup):
		url = soup.find('iframe')['src']
	else:
		url = ''
	return url

def FBCDN(baseUrl):
	url = CleanUrl(baseUrl, unicodeUrl=False)
#	if '//scontent' in url:
#		return url
#	elif '//video' in url:
#		return url.replace('video', 'scontent', 1)
#	else: # I DON'T KNOW WHAT TO DO
	return url

def Fembed(baseurl):
	id = re.compile('/v/(.+)').findall(baseurl)[0]
	html = Request('https://www.fembed.com/api/sources/%s' % id, referer=baseurl, post=True)
	try:
		j = json.loads(html)
		sources = j['data']
		links = []
		for source in sources:
			links.append((source['label'], source['file']))
		link = ChooseRes(links)
		link = '%s|Referer=%s' % (link, baseurl)
		return link
	except Exception, e:
		if DEBUG: Log('| FEMBED ERROR | %s' % e)
		if DEBUG: Log(html.encode('utf-8'))
		return baseurl

def GoogleDocs(url):
	if DEBUG: Log('| GOOGLE DOCS | %s' % url)
	gd_bug     = 0 # 0 = None | 1 = Basic | 2 = Detailed
	if DEBUG: gd_bug = 2
	gd_agent   = 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36'
	gd_session = requests.session()
	gd_headers = {
		'User-Agent': gd_agent,
		'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
		'Accept-Encoding': 'gzip, deflate, sdch'
	}
	# Resolve redirect if GoogleUserContent
	if 'googleusercontent.' in url:
		# Get final URL
		gd_headers.update({'Referer': url})
		r = gd_session.get(url=url, headers=gd_headers, stream=True)
		if any(s in str(r.history) for s in ['300', '301', '302', '303', '304', '305', '306', '307', '308']):
			url = r.url
			if gd_bug >= 1: Log('| GD: REDIRECTION | %s' % url)
	# Extract video ID
	if 'open?id=' in url:
		id = re.compile('open\?id=(.+?[^"|\s|\'|\?|&|/]*)').findall(url)[0]
	elif 'docid=' in url:
		id = re.compile('docid=(.+?[^"|\s|\'|\?|&|/]*)').findall(url)[0]
	elif 'driveid=' in url:
		id = re.compile('driveid=(.+?[^"|\s|\'|\?|&|/]*)').findall(url)[0]
	elif '/file/d/' in url:
		id = re.compile('/file/d/(.+?[^"|\s|\'|\?|&|/]*)').findall(url)[0]
	else:
		id = None
	if id:
		url = 'https://docs.google.com/leaf?id=%s' % id
	else:
		return url
	# Initial request
	try:
		if gd_bug >= 1: Log('| GD: REQUEST | %s' % url)
		r = gd_session.get(url=url, headers=gd_headers); r.encoding = 'utf-8'
		cookie = urllib.urlencode(dict(r.cookies)).replace('&',';')
		src = r.text.encode('utf-8')
		if gd_bug >= 2: Log('| GD: COOKIE | %s' %s)
		if gd_bug >= 2: Log(src)
	except Exception, e:
		if DEBUG: Log('| ERROR | %s' % str(e))
		src = ''
		cookie = ''
	resolved = ''
	# Method 1: parse JSON data
	if 'fmt_stream_map' in src:
		links  = re.compile('(\["fmt_stream_map",.+?\])').findall(src)[0]
		links  = re.compile('(\d+)\|(.+?)[,|"|\]]').findall(links)
		if gd_bug >= 2: Log(links)
		labels = re.compile('(\["fmt_list",.+?\])').findall(src)[0]
		labels = re.compile('["|,](\d+)/.+?x(.+?)/').findall(labels)
		if gd_bug >= 2: Log(labels)
		links2 = []
		for i, (linkdigit, link) in enumerate(links):
			for labeldigit, label in labels:
				if labeldigit == linkdigit:
					links2.append((label, link))
			resolved = ChooseRes(links2)
		if resolved:
			resolved = resolved.decode('unicode-escape') + '|Cookie=%s' % cookie
	# Method 2: get download link
	if not 'fmt_stream_map'in src or not resolved:
		url2 = 'https://drive.google.com/uc?id=%s&export=download' % id
		if gd_bug >= 1: Log('| GD: REQUEST | %s' % url2)
		gd_headers.update({'Referer': url})
		r = gd_session.get(url=url2, headers=gd_headers); r.encoding = 'utf-8'
		cookie = urllib.urlencode(dict(r.cookies)).replace('&',';')
		src = r.text.encode('utf-8')
		if gd_bug >= 2: Log('| GD: COOKIE | %s' %s)
		if gd_bug >= 2: Log(src)
		url3 = re.compile('<a id="uc-download-link".+?href="(.+?)">').findall(src)[0]
		url3 = url3.replace('&amp;', '&')
		url3 = 'https://drive.google.com%s' % url3 if not url3.startswith('http') else url3
		# Get final URL
		if gd_bug >= 1: Log('| GD: REDIRECTION | %s' % url3)
		gd_headers.update({'Referer': url2})
		r = gd_session.head(url=url3, headers=gd_headers, allow_redirects=True)
		if any(s in str(r.history) for s in ['300', '301', '302', '303', '304', '305', '306', '307', '308']):
			resolved = r.url
		else:
			if gd_bug >= 1: Log('| GD: NO REDIRECT |')
			resolved = url3
	if gd_bug >= 1: Log('| GD: RESOLVED | %s' % resolved)
	return resolved

def H265SE(baseUrl):
	html = Request(baseUrl)
	links = re.compile('"([^"]*)",function\(\){jwplayer\(\)\.load\({file: "(.+?)"').findall(html)
	if len(links) == 0:
		src = ''
	elif len(links) == 1:
		src = links[0][1]
	else:
		links2 = []
		for label, link in links:
			links2.append((label, link))
			src = ChooseRes(links2)
	return src

def HDPlaySE(baseUrl):
	html = Request(baseUrl)
	if 'urlVideo' in html:
		src = re.compile('urlVideo = "([^"]*)"').findall(html)[0]
	elif 'var hlsfile' in html:
		src = re.compile('var hlsfile = "(.+?)"').findall(html)[0]
	elif 'file:"' in html:
		src = re.compile('file:"(.+?)"').findall(html)[0]
	else:
		data = re.compile('"(\[{.+?\])";').findall(html)[0]
		links = eval(data)[1]
		if len(links) == 0:
			return baseUrl
		elif len(links) == 1:
			src = links[0]['url']
		else:
			links2 = []
			for link in links:
				links2.append((link['quality'], link['url']))
				src = ChooseRes(links2)
	src = FormatUrl(src)
	src = '%s|Referer=%s' % (src, baseUrl)
	return src

def Matchat(baseurl):
	html = Request(baseurl, minify=True)
	url = re.compile('{hls:"(.+?)"}').findall(html)[0]
	url = FormatUrl(url, baseurl)
	return '%s|Referer=%s' % (url, baseurl)

def MediaFire(baseUrl, iframe=''):
	if not '/file/' in baseUrl:
		id = re.compile('mediafire.com/.+?/(.*)').findall(baseUrl)[0]
		baseUrl = 'http://www.mediafire.com/file/%s' % id
	if DEBUG: Log('| Mediafire | %s' % baseUrl)
	try:
		html = Request(baseUrl, minify=True)
		url = re.compile("kNO = '([^']*)'").findall(html)[0]
		return '%s|Referer=%s' % (url, baseUrl)
	except Exception, e:
		try:
			url = re.compile("href='([^']*)' onclick='DLP_mOnDownload\(this\);").findall(html)[0]
			return '%s|Referer=%s' % (url, baseUrl)
		except:
			if DEBUG: Log('| MEDIAFIRE ERROR | %s' % e)
			if iframe:
				url = PopoutFrame(iframe, mirror=False)
				return url

def Mycujoo(baseurl):
	html = Request(baseurl, minify=True)
	url = re.compile('"filename":"(.+?)"').findall(html)[0]
	return url + ('|Referer=%s' % baseurl)

def NDHA(baseurl):
	soup = Request(baseurl, soup=True)
	if '<source' in str(soup):
		url = soup.find('source')['src']
	elif '<iframe' in str(soup):
		url = soup.find('iframe')['src']
	else:
		url = ''
	return url

def Openload(baseUrl, name, icon, html=None, lang=LANG):
	baseUrl = baseUrl.replace('/f/', '/embed/')
	if not html:
		dialog = DialogProgress(msg1=language[lang]['PLEASEWAIT'], msg2='%s...' % language[lang]['LOADING'], allowCancel=False)
		html = Request(baseUrl)
		html = html.encode('utf-8')
		if any(message in html for message in ['We’re Sorry!']):
			return None
		else:
		#	IMPORTANT: 'return...' is required at start of javascript code
		#	js       = 'return document.body.innerHTML.match(/>\s*([\w-]+~\d{10,}~\d+\.\d+\.0\.0~[\w-]+)\s*</)[1];'
			js       = 'return />\s*([\w-]+~\d{10,}~\d+\.\d+\.0\.0~[\w-]+)\s*</.exec(document.documentElement.innerHTML)[1];'
			headers  = {'User-Agent': userAgent}
			meta     = {
				'addon' : addonId,
				'mode'  : 'OPENLOAD',
				'link'  : baseUrl,
				'name'  : name,
				'icon'  : icon,
			}
			loadtime = 10
			runtime  = 2
			port     = None
			HeadlessParser(js, baseUrl, headers, meta, loadtime, runtime, port, DEBUG)
			xbmc.sleep(10000)
			del dialog
			sys.exit()
	else:
		try:
			url = 'https://openload.co/stream/%s?mime=true' % re.compile('([\w-]+~\d{10,}~\d+\.\d+\.0\.0~[\w-]+)').findall(html)[0]
			Player(url, name, icon)
		except Exception, e:
			if DEBUG: Log('| %s' % e)
			url = UrlResolver(baseUrl)
			Play(url, name, icon)

def OKRU(baseurl):
	baseurl = baseurl.replace('/video/', '/videoembed/')
	soup = Request(baseurl, soup=True)
	src = soup.find('div', {'data-module': 'OKVideo'})['data-options']
	j = json.loads(json.loads(src)['flashvars']['metadata'])
	sources = j['videos']
	links = []
	for source in sources:
		links.append((source['name'], source['url']))
	link = ChooseRes(links, maxres=11)
	return link

def RapidVideo(baseUrl):
	data = {
		'confirm.x' : int(random.random()*100),
		'confirm.y' : int(random.random()*100),
		'block'     : 1,
	}
	soup = Request(baseUrl, soup=True)
	try:
		src = soup.find('source')['src']
		src = '%s|Referer=%s' % (src, baseUrl)
	except:
		src = None
	count =0 
	while not src:
		count += 1
		try:
			soup = Request(baseUrl, userAgent=random.choice(userAgent_Pool), post=True, data=data, soup=True)
			src = soup.find('source')['src']
			src = '%s|Referer=%s' % (src, baseUrl)
		except Exception, e:
			if DEBUG: Log('| %s' % e)
		if count == 5:
			break
	return src

def Streamable(baseurl):
	soup = Request(baseurl, soup=True)
	url = soup.find('video')['src']
	url = FormatUrl(url, baseurl)
	return '%s|Referer=%s' % (url, baseurl)

def UsersCloud(baseurl):
	html = Request(baseurl)
	src = re.compile('<source src="([^"]*)" type="video/mp4">').findall(html)[0]
	src = FormatUrl(src)
	src = '%s|Referer=%s&User-Agent=%s' % (src, baseurl, urllib.quote(userAgent))
	return src

def VCStream(baseUrl):
	if '/embed/' in baseUrl:
		id = re.compile('/embed/(.+?)/').findall(baseUrl)[0]
		url = 'https://vcstream.to/player?fid=%s&page=embed&owner=' % id
	else:
		url = baseUrl
	html = Request(url)
	src = LinksFinder(html)
	src = '%s|Referer=%s&User-Agent=%s' % (src, baseUrl, urllib.quote(userAgent))
	return src

def VEVIO(url):
	# https://vev.io/embed/j0omnkxvm73m
	id = url.split('/')[-1]
	url2 = 'https://vev.io/api/serve/video/%s' % id
	data = Request(url2, referer=url, post=True, data={})
	sources = JSON(data)['qualities']
	links = []
	for source in sources:
		links.append((source, sources[source]))
	src = ChooseRes(links)
	src = FormatUrl(src, url)
	return '%s|Referer=%s' % (src, url)

def YouTube(url, getLink=False):
	if 'watch?v=' in url:
		youtubeID = re.compile('watch\?v=(.+?[^"|\s|\'|\?]*)').findall(url)[0]
	elif '/embed/' in url:
		youtubeID = re.compile('/embed/(.+?[^"|\s|\'|\?]*)').findall(url)[0]
	elif '/v/' in url:
		youtubeID = re.compile('/v/(.+?[^"|\s|\'|\?]*)').findall(url)[0]
	elif 'youtu.be/' in url:
		youtubeID = re.compile('youtu.be/(.+?[^"|\s|\'|\?]*)').findall(url)[0]
	else:
		if url.startswith('http'):
			return url
		else:
			return ''
	if getLink:
		return 'https://www.youtube.com/watch?v=%s' % youtubeID
	else:
		return 'plugin://plugin.video.youtube/play/?video_id=%s' % youtubeID

def YouTubeLinkFinder(url, referer='', getLink=False):
	if url.startswith('http'):
		src = Request(url, referer=referer)
	else:
		src = url
	return YouTube(src, getLink)

def ZingVN(url):
	html = Request(url, minify=True)
	sources = re.compile('<source src="(.+?)" type="video/mp4" data-res="(.+?)"').findall(html)
	links = []
	for src, res in sources:
		links.append((src, res))
	link = ChooseRes(links)
	return link

def UrlResolver(url, lang=LANG):
	if DEBUG: Log('| .: RESOLVE URL :. | %s' % url)
	url = PipeHeaders(url)
	try:
		import resolveurl
		link = resolveurl.resolve(url)
		if not link:
			raise
	except Exception, e:
		if 'File Not Available' in e:
			OK(title=language[LANG]['SORRY'], message=language[LANG]['VIDEOREMOVED'])
			sys.exit()
		if any(keywords.lower() in url.lower() for keywords in popoutDomains):
			link = PopoutFrame(url, lang=lang)
		else:
			link = url
	return link

def PopoutFrame(url, mirror=True, index=505, lang=LANG):
	xbmcgui.Dialog().ok(COLOUR10 % language[lang]['INSTRUCTIONS2'], COLOUR0 % language[lang]['PRESSPLAY'], COLOUR0 % language[lang]['PRESSPLAY2'])
	url = String(url)
	url = CleanUrl(url)
	url = PipeHeaders(url)
	if DEBUG: Log('| Loading Popout... | %s' % url)
	if mirror:
		rnd = ''.join(random.SystemRandom().choice(string.ascii_uppercase + string.digits) for _ in range(index))
		xbmc.executebuiltin('StartAndroidActivity("com.android.chrome","android.intent.action.VIEW","","http://v137.xyz/p/if?r=%s&src=%s")' % (rnd, url))
	else:
		xbmc.executebuiltin('StartAndroidActivity("com.android.chrome","android.intent.action.VIEW","","%s")' % url)
	return ''


# #################################################################################################### #
#
# DECODE
#
# #################################################################################################### #

decodeUrl          = 'https://v137.xyz/p/gb?r=%s&s=%s&p=%s'
evaluateUrl        = 'http://js.v137.xyz/'
#evaluateUrl        = 'http://localhost:80'
evaluateKey        = 'djEzNyh7djonVkVFIE9ORSBUSFJFRSBTRVZFTiBTRVZFTiBTRVZFTiBTRVZFTiBTRVZFTid9KVs6MTM3XS52MTM3KCk='

def Decode(s, p, d=None, index=505):
	r = ''.join(random.SystemRandom().choice(string.ascii_uppercase + string.digits) for _ in range(index))
	s = s.replace('\/', '/').replace('\\/', '/')
	d = d.replace('https://', '').replace('http://', '').replace('www.', '').replace('/', '')
	if DEBUG: Log('| S | %s' % s)
	if DEBUG: Log('| P | %s' % p)
	if d: url = (decodeUrl + '&d=%s') % (urllib.quote(r), urllib.quote(s), urllib.quote(p), urllib.quote(d))
	else: url = decodeUrl % (urllib.quote(r), urllib.quote(s), urllib.quote(p))
	src = Request(url, userAgent=decodeAgent)
	if DEBUG: Log('| D | %s' % src)
	return src

def BlindDecode(baseSrc, url=''):
	if ('<' and '>') or ('<' and '/>') in baseSrc:
		src = LinkFinder(baseSrc, url)
	else:
		baseSrc = str(baseSrc)
	try:
		if base64.b64encode(base64.b64decode(baseSrc)) == baseSrc:
			src = base64.b64decode(baseSrc)
	except:
		src = baseSrc
	return src

def B64Decode(src):
	try:
		if base64.b64encode(base64.b64decode(src)) == src:
			return base64.b64decode(src)
	except:
		return src

def B64Encode(src):
	return base64.b64encode(str(src))

def MD5Hash(src):
	return hashlib.md5(str(src)).hexdigest()

def UnWise(src):
#	import resolveurl
#	from resolveurl.plugins.lib import unwise
	import urlresolver
	from urlresolver.plugins.lib import unwise
	return unwise.unwise_process(src)

def JSunpack(src):
#	import resolveurl
#	from resolveurl.plugins.lib import jsunpack
	import urlresolver
	from urlresolver.plugins.lib import jsunpack
	return jsunpack.unpack(src)

def EvalJS(js1, js2, submit='evaluate'):
	form = {
		'key'  : evaluateKey,
		'js1'  : base64.b64encode(js1),
		'js2'  : base64.b64encode(js2),
		submit : 1,
	}
	if DEBUG: Log('| JS1 | %s' % js1)
	if DEBUG: Log('| JS2 | %s' % js2)
	src = Request(evaluateUrl, userAgent=decodeAgent, multipart=True, files={'':''}, data=form)
	src = B64Decode(src)
	if DEBUG: Log('| %s' % src)
	return src

def randomString(length, chars='alphanumeric'):
	if chars == 'alphanumeric':
		chars = string.ascii_letters + string.digits
	if chars == 'alpha':
		chars = string.ascii_letters + string.digits
	if chars == 'numeric':
		chars = string.digits,
	return ''.join(random.choice(chars) for i in range(length))

# #################################################################################################### #
#
# HEADLESS
#
# #################################################################################################### #


HEADLESSCRIPT      = 'script.com.headless.parser'

def HeadlessParser(js, url='', headers={}, meta='', loadtime=0, runtime=0, port=None, debug=False):
#	if DEBUG: Log('| METADATA | %s' % str(meta))
#	if DEBUG: xbmcgui.Dialog().ok('PARSING JS...', 'JS: %s' % js, 'URL: %s' % url if url else '', 'Meta: %s' % meta if meta else '')
	xbmc.executebuiltin('RunScript(%s, %s)' % ('special://home/addons/%s/default.py' % HEADLESSCRIPT, 'js=%s, url=%s, headers=%s, meta=%s, loadtime=%s, runtime=%s, port=%s, mode=PARSE, debug=%s' % (urllib.quote_plus(js, safe='~()*!.\''), url, urllib.quote_plus(str(headers)), urllib.quote_plus(str(meta)), loadtime, runtime, port, debug)))


# #################################################################################################### #
#
# SETTINGS
#
# #################################################################################################### #

def DefineSettings(settingsXML='Bare', stringsXML='Full'):
	settingsFile   = xbmc.translatePath('special://home/addons/{addonid}/resources/settings.xml'.format(addonid=addonId))
	stringsFile    = xbmc.translatePath('special://home/addons/{addonid}/resources/language/english/strings.xml'.format(addonid=addonId))

	settingsData   = {
	'Full' :
"""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<settings>
	<!-- General Settings -->
	<category label="30000">
		<setting id="viewmode" type="enum" lvalues="30011|30012" label="30010" default="0"/>
		<setting id="resolution" type="enum" lvalues="30021|30022|30023|30024|30025|30026|30027" label="30020" default="0"/>
		<setting id="history" value="[]"/>
	</category>
</settings>
""",
	'Bare' :
"""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<settings>
	<setting id="history" value="[]"/>
</settings>
""",
	}

	stringsData    = {
	'Full' :
"""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<strings>
	<string id="30000">Default</string>
	<string id="30010">Select a view mode for displaying movies:</string>
	<string id="30011">List view</string>
	<string id="30012">Poster view</string>
	<string id="30020">Video quality:</string>
	<string id="30021">1080p HD (High)</string>
	<string id="30022">720p HD (High)</string>
	<string id="30023">576p SD (Medium)</string>
	<string id="30024">480p SD (Medium)</string>
	<string id="30025">360p SD (Low)</string>
	<string id="30026">240p SD (Low)</string>
	<string id="30027">Ask</string>
</strings>
""",
	}

	WriteFile(settingsData[settingsXML], settingsFile, overwrite=True)
	WriteFile(stringsData[stringsXML], stringsFile, overwrite=True)

# #################################################################################################### #
#
# FILE / FOLDER OPERATIONS
#
# #################################################################################################### #

def MakeFolder(dst):
	if os.path.isdir(dst):
		return True
	else:
		try:
			os.makedirs(dst)
			if not os.path.isdir(dst):
				raise('Folder not created')
		except Exception, e:
			if DEBUG: Log('| Un-zip file failed | %s | %s' % (src, e))
			return False
		else:
			return True

def ReadFile(file):
	try:
		with open(file, 'rb') as f:
			data = f.read()
	except Exception, e:
		if DEBUG: Log('| Cannot read file | %s | %s' % (file, e))
		return ''
	else:
		return data

def WriteFile(src, file, overwrite=True):
	path = os.path.dirname(file)
	try:
		if not os.path.isdir(path):
			os.makedirs(path)
		if not overwrite:
			data = ReadFile(file)
			if data:
				if DEBUG: Log('| File exists | %s' % file)
				return False
		with open(file, 'wb') as f:
			f.write(src)
	except Exception, e:
		if DEBUG: Log('| Cannot write file | %s | %s' % (file, e))
		return False
	else:
		return True

def DeleteFile(file):
	try:
		os.remove(file)
	except Exception, e:
		if DEBUG: Log('| File not deleted | %s | %s' % (file, e))
		return False
	else:
		return True


# #################################################################################################### #
#
# SYSTEM
#
# #################################################################################################### #


def MacAddress():
	try:
		mac = open('/sys/class/net/eth0/address').read(17).upper()
	except:
		while True:
			mac = xbmc.getInfoLabel ('Network.MacAddress').upper()
			if re.match('[0-9A-F]{2}([-:])[0-9A-F]{2}(\\1[0-9A-F]{2}){4}$', mac):
				break
	finally:
		return hashlib.sha512(mac).hexdigest()


# #################################################################################################### #
#
# GEO CHALLENGE
#
# #################################################################################################### #


def GeoChallenge(soup, url, proxies1=proxies_VN1, proxies2=proxies_VN2, lang=LANG):
	try:
		body = soup.body.contents
	except:
		body = []

	titles           = ['are you with me', 'xác minh quốc gia']
	correctAnswers   = ['Có', 'Việt Nam', 'Hà Nội', 'Tiến Quân Ca', 'Hồ Chí Minh', 'Chữ S']
	incorrectAnswers = ['Không', 'TP Hồ Chí Minh']

	# ATTEMPT ONE: ANSWER CHALLENGE QUESTIONS
	try:    title = str(soup.find('title'))
	except: title = ''
	if any(text.lower() in title.lower() for text in titles):
		answers = {}
		inputs = soup.find_all('input')
		for input in inputs:
			name  = input['name']
			text  = input.parent.text.strip().encode('utf-8')
			value = input['value']
			if any(s in text for s in correctAnswers) and not any(s in text for s in incorrectAnswers):
				answers.update({name: value})
		soup = Request(url, referer=url, post=True, data=answers, soup=True)
		try:    title = str(soup.find('title'))
		except: title = ''

	# ATTEMPT TWO AND THREE: USE PROXY
	if any(text.lower() in title.lower() for text in titles) or not body:
		Notification(language[lang]['TRYINGPROXY'])
		soup = Request(url, referer=url, proxies=proxies1, soup=True)
		try:
			body = soup.body.contents
		except:
			body = []
		if not body:
			Notification(language[lang]['TRYINGPROXY2'])
			soup = Request(url, referer=url, proxies=proxies2, soup=True)

	return soup
