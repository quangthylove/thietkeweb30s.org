﻿#!/usr/bin/python
# -*- coding: utf-8 -*-
import urllib , requests , re , os , json , uuid , base64 , urlresolver
from xbmcswift2 import Plugin , xbmc , xbmcgui , xbmcaddon
from operator import itemgetter
oo000 = Plugin ( )
ii = "plugin://plugin.video.thietkeweb30s.org.xemphimmienphi"
oOOo = "https://dl.dropboxusercontent.com/s/amgdv2xi88b4nx8/NEXT.png"
O0 = "https://dl.dropboxusercontent.com/s/qelguyfz39uwoqx/temp0206.jpg"
o0O = "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.75 Safari/537.36"
if 10 - 10: O0O0OO0O0O0
iiiii = '<div class="quality">(.+?)</div><a class="poster" href="(.+?)"><img src="(.+?)" alt="(.+?)"></a>'
ooo0OO = 'href="(xem-phim.+?)"'
II1 = '<i class="fa fa-server"></i>(.+?)</label>(.+?)</div>'
O00ooooo00 = '&file=/xml.php\?id=(\d+)'
I1IiiI = '<div class="list_episodes content">.*?<td[^>]*class="name">%s</td><td valign="top" class="ep">(.+?)</td></tr>'
if 27 - 27: iIiiiI1IiI1I1 * IIiIiII11i * IiIIi1I1Iiii - Ooo00oOo00o
I1IiI = 56
if 73 - 73: OOooOOo / ii11ii1ii
@ oo000 . route ( '/' )
def O00ooOO ( ) :
 xbmc . executebuiltin ( "ShowPicture(%s)" % O0 )
 if 47 - 47: oO0ooO % iI1Ii11111iIi + ii1II11I1ii1I + oO0o0ooO0 - iiIIIII1i1iI
@ oo000 . route ( '/search' )
def o0oO0 ( ) :
 oo00 = oo000 . keyboard ( heading = 'Tìm kiếm' )
 if oo00 :
  o00 = 'http://xemphimmienphi.net/search/movie=' + urllib . quote_plus ( oo00 ) + '&page=%s'
  Oo0oO0ooo = oo000 . get_storage ( 'search_history' )
  if 'keywords' in Oo0oO0ooo :
   Oo0oO0ooo [ "keywords" ] = [ oo00 ] + Oo0oO0ooo [ "keywords" ]
  else :
   Oo0oO0ooo [ "keywords" ] = [ oo00 ]
  o0oOoO00o = {
 "title" : "Search: %s" % oo00 ,
 "url" : o00 ,
 "page" : 1
 }
  i1 = '%s/list_media/%s' % (
 ii ,
 urllib . quote_plus ( json . dumps ( o0oOoO00o ) )
 )
  oo000 . redirect ( i1 )
  if 64 - 64: oo % O0Oooo00
@ oo000 . route ( '/searchlist' )
def Ooo0 ( ) :
 oo00000o0 (
 '[Search List]' ,
 '/searchlist/'
 )
 I11i1i11i1I = [ ]
 Iiii = [ {
 "label" : "[B]Search[/B]" ,
 "path" : "%s/search" % ( ii ) ,
 "thumbnail" : "https://dl.dropboxusercontent.com/s/oref22w16pngim1/timkiem.png"
 } ]
 Oo0oO0ooo = oo000 . get_storage ( 'search_history' )
 if 'keywords' in Oo0oO0ooo :
  for OOO0O in Oo0oO0ooo [ 'keywords' ] :
   o00 = 'http://xemphimmienphi.net/search/movie=' + urllib . quote_plus ( OOO0O ) + '&page=%s'
   o0oOoO00o = {
 "title" : "Search: %s" % OOO0O ,
 "url" : o00 ,
 "page" : 1
 }
   oo0ooO0oOOOOo = { }
   oo0ooO0oOOOOo [ "label" ] = OOO0O
   oo0ooO0oOOOOo [ "path" ] = "%s/list_media/%s" % (
 ii ,
 urllib . quote_plus ( json . dumps ( o0oOoO00o ) )
 )
   oo0ooO0oOOOOo [ "thumbnail" ] = "https://dl.dropboxusercontent.com/s/oref22w16pngim1/timkiem.png"
   I11i1i11i1I . append ( oo0ooO0oOOOOo )
 I11i1i11i1I = Iiii + I11i1i11i1I
 return oo000 . finish ( I11i1i11i1I )
 if 71 - 71: O00OoOoo00
@ oo000 . route ( '/list_media/<args_json>' )
def iIiiI1 ( args_json = { } ) :
 I11i1i11i1I = [ ]
 OoOooOOOO = json . loads ( args_json )
 oo00000o0 (
 "[Browse Media of] %s - Page %s" % (
 OoOooOOOO [ "title" ] if "title" in OoOooOOOO else "Unknow Title" ,
 OoOooOOOO [ "page" ] if "page" in OoOooOOOO else "1"
 ) ,
 '/list_media/%s/%s' % (
 OoOooOOOO [ "url" ] % OoOooOOOO [ "page" ] if "page" in OoOooOOOO else "1" ,
 json . dumps ( OoOooOOOO [ "payloads" ] ) if "payloads" in OoOooOOOO else "{}"
 )
 )
 i11iiII = I1iiiiI1iII ( OoOooOOOO [ "url" ] % OoOooOOOO [ "page" ] )
 IiIi11i = re . compile ( iiiii ) . findall ( i11iiII )
 for iIii1I111I11I , o00 , OO00OooO0OO , iiiIi in IiIi11i :
  o0oOoO00o = {
 "title" : iiiIi ,
 "quality_label" : iIii1I111I11I ,
 "url" : o00
 }
  oo0ooO0oOOOOo = { }
  oo0ooO0oOOOOo [ "label" ] = "%s (%s)" % (
 o0oOoO00o [ "title" ] ,
 o0oOoO00o [ "quality_label" ]
 )
  oo0ooO0oOOOOo [ "path" ] = "%s/list_mirrors/%s" % (
 ii ,
 urllib . quote_plus ( json . dumps ( o0oOoO00o ) )
 )
  oo0ooO0oOOOOo [ "thumbnail" ] = OO00OooO0OO
  if "HD" in iIii1I111I11I :
   oo0ooO0oOOOOo [ "label" ] = "[COLOR yellow]%s[/COLOR]" % oo0ooO0oOOOOo [ "label" ]
  I11i1i11i1I . append ( oo0ooO0oOOOOo )
 if len ( I11i1i11i1I ) == I1IiI :
  IiIIIiI1I1 = int ( OoOooOOOO [ "page" ] ) + 1
  OoOooOOOO [ "page" ] = IiIIIiI1I1
  I11i1i11i1I . append ( {
 'label' : 'Next >>' ,
 'path' : '%s/list_media/%s' % (
 ii ,
 urllib . quote_plus ( json . dumps ( OoOooOOOO ) )
 ) ,
 'thumbnail' : oOOo
 } )
 return oo000 . finish ( I11i1i11i1I )
 if 86 - 86: i11I1IIiiIi + oOo + iiIiIiIi - o0oooO0OO0O / Oooo
@ oo000 . route ( '/list_mirrors/<args_json>' )
def O00o ( args_json = { } ) :
 I11i1i11i1I = [ ]
 OoOooOOOO = json . loads ( args_json )
 oo00000o0 (
 "[Browse Mirrors of] %s (%s)" % (
 OoOooOOOO [ "title" ] if "title" in OoOooOOOO else "Unknow Title" ,
 OoOooOOOO [ "quality_label" ] if "quality_label" in OoOooOOOO else ""
 ) ,
 '/list_mirrors/%s/%s' % (
 OoOooOOOO [ "url" ] ,
 json . dumps ( OoOooOOOO [ "payloads" ] ) if "payloads" in OoOooOOOO else "{}"
 )
 )
 i11iiII = I1iiiiI1iII ( OoOooOOOO [ "url" ] )
 IiIi11i = re . compile ( II1 ) . findall ( i11iiII )
 for O00 , i11I1 in IiIi11i :
  o0oOoO00o = {
 "title" : OoOooOOOO [ "title" ] ,
 "quality_label" : OoOooOOOO [ "quality_label" ] ,
 "mirror" : O00 ,
 "url" : OoOooOOOO [ "url" ]
 }
  oo0ooO0oOOOOo = { }
  oo0ooO0oOOOOo [ "label" ] = "%s - %s" % (
 O00 ,
 OoOooOOOO [ "title" ] . encode ( "utf8" )
 )
  oo0ooO0oOOOOo [ "path" ] = '%s/list_eps/%s' % (
 ii ,
 urllib . quote_plus ( json . dumps ( o0oOoO00o ) )
 )
  I11i1i11i1I . append ( oo0ooO0oOOOOo )
 return oo000 . finish ( I11i1i11i1I )
 if 8 - 8: IIiIiII11i - iiIiIiIi % IIiIiII11i - i11I1IIiiIi * ii11ii1ii
@ oo000 . route ( '/list_eps/<args_json>' )
def iI11i1I1 ( args_json = { } ) :
 I11i1i11i1I = [ ]
 OoOooOOOO = json . loads ( args_json )
 oo00000o0 (
 "[Browse Episodes of] %s (%s) [%s]" % (
 OoOooOOOO [ "title" ] if "title" in OoOooOOOO else "Unknow Title" ,
 OoOooOOOO [ "quality_label" ] if "quality_label" in OoOooOOOO else "" ,
 OoOooOOOO [ "mirror" ] if "mirror" in OoOooOOOO else ""
 ) ,
 '/list_mirrors/%s/%s' % (
 OoOooOOOO [ "url" ] ,
 json . dumps ( OoOooOOOO [ "payloads" ] ) if "payloads" in OoOooOOOO else "{}"
 )
 )
 i11iiII = I1iiiiI1iII ( OoOooOOOO [ "url" ] )
 IiIi11i = re . compile ( II1 ) . findall ( i11iiII )
 for O00 , i11I1 in IiIi11i :
  if O00 == OoOooOOOO [ "mirror" ] . encode ( "utf8" ) :
   for o0o0OOO0o0 , ooOOOo0oo0O0 in re . compile ( '<a[^>]*href="(.+?)"[^>]*>(.+?)</a>' ) . findall ( i11I1 ) :
    o0oOoO00o = {
 "title" : OoOooOOOO [ "title" ] ,
 "quality_label" : OoOooOOOO [ "quality_label" ] ,
 "mirror" : O00 ,
 "url" : o0o0OOO0o0 ,
 "eps" : ooOOOo0oo0O0
 }
    oo0ooO0oOOOOo = { }
    oo0ooO0oOOOOo [ "label" ] = "Part %s - %s" % (
 ooOOOo0oo0O0 ,
 OoOooOOOO [ "title" ]
 )
    oo0ooO0oOOOOo [ "path" ] = '%s/play/%s' % (
 ii ,
 urllib . quote_plus ( json . dumps ( o0oOoO00o ) )
 )
    oo0ooO0oOOOOo [ "is_playable" ] = True
    I11i1i11i1I . append ( oo0ooO0oOOOOo )
   break
 return oo000 . finish ( I11i1i11i1I )
 if 71 - 71: o0oooO0OO0O . iIiiiI1IiI1I1
@ oo000 . route ( '/play/<args_json>' )
def o0OO0oo0oOO ( args_json = { } ) :
 OoOooOOOO = json . loads ( args_json )
 oo00000o0 (
 "[Play] %s (%s) - Part %s [%s]" % (
 OoOooOOOO [ "title" ] if "title" in OoOooOOOO else "Unknow Title" ,
 OoOooOOOO [ "quality_label" ] if "quality_label" in OoOooOOOO else "" ,
 OoOooOOOO [ "eps" ] if "eps" in OoOooOOOO else "" ,
 OoOooOOOO [ "mirror" ] if "mirror" in OoOooOOOO else ""
 ) ,
 '/list_mirrors/%s/%s' % (
 OoOooOOOO [ "url" ] ,
 json . dumps ( OoOooOOOO [ "payloads" ] ) if "payloads" in OoOooOOOO else "{}"
 )
 )
 oo0oooooO0 = xbmcgui . DialogProgress ( )
 oo0oooooO0 . create ( 'XemPhimMienPhi.net' , 'Loading video. Please wait...' )
 oo000 . set_resolved_url ( i11Iiii ( OoOooOOOO [ "url" ] ) , subtitles = "https://dl.dropboxusercontent.com/s/oa2yn7vqgfrmpb1/advertisement.srt" )
 oo0oooooO0 . close ( )
 del oo0oooooO0
 if 23 - 23: oO0o0ooO0 . OOooOOo
def i11Iiii ( url ) :
 i11iiII = I1iiiiI1iII ( url )
 Oo0O0OOOoo = None
 oOoOooOo0o0 = "http://xemphimmienphi.net/ajax/player"
 OOOO = re . compile ( '(youtu\.be\/|youtube-nocookie\.com\/|youtube\.com\/(watch\?(.*&)?v=|(embed|v|user)\/))([^\?&"\'>]+)' ) . findall ( i11iiII )
 OOO00 = re . compile ( '; var params = "lnk=(.+?)&type=(.+?)"' ) . findall ( i11iiII )
 if 21 - 21: IiIIi1I1Iiii - IiIIi1I1Iiii
 if len ( OOO00 ) > 0 :
  iIii11I , OOO0OOO00oo = OOO00 [ 0 ]
  Iii111II = {
 'lnk' : iIii11I ,
 'type' : OOO0OOO00oo
 }
  i11iiII = I1iiiiI1iII ( oOoOooOo0o0 , Iii111II )
  if "openload.co" in i11iiII :
   try :
    Oo0O0OOOoo = re . compile ( '"(https://openload.+?)"' ) . findall ( i11iiII ) [ 0 ]
    Oo0O0OOOoo = urlresolver . resolve ( Oo0O0OOOoo )
   except :
    pass
  else :
   iiii11I = json . loads ( re . compile ( "sources\:(\[.+?\])," ) . findall ( i11iiII ) [ 0 ] )
   Ooo0OO0oOO = [ "=18" , "=m18" ]
   ii11i1 = [ "=22" , "=m22" ]
   if 29 - 29: iiIIIII1i1iI % ii11ii1ii + Oooo / oO0o0ooO0 + O0Oooo00 * oO0o0ooO0
   for i1I1iI in iiii11I :
    if any ( lq_word in i1I1iI [ "file" ] for lq_word in Ooo0OO0oOO ) :
     Oo0O0OOOoo = i1I1iI [ "file" ]
     break
   if oo000 . get_setting ( 'HQ' , bool ) and ( len ( iiii11I ) > 1 ) :
    for i1I1iI in iiii11I :
     if any ( hq_word in i1I1iI [ "file" ] for hq_word in ii11i1 ) :
      Oo0O0OOOoo = i1I1iI [ "file" ]
      break
 elif len ( OOOO ) > 0 :
  oo0OooOOo0 = OOOO [ 0 ] [ len ( OOOO [ 0 ] ) - 1 ] . replace ( 'v/' , '' )
  Oo0O0OOOoo = 'plugin://plugin.video.youtube/?action=play_video&videoid=%s' % oo0OooOOo0
 return Oo0O0OOOoo
 if 92 - 92: oOo . O00OoOoo00 + oO0o0ooO0
 if 28 - 28: Ooo00oOo00o * oO0ooO - oO0o0ooO0 * iiIiIiIi * i11I1IIiiIi / iI1Ii11111iIi
def I1iiiiI1iII ( url , data = { } ) :
 OooO0OoOOOO = {
 'User-Agent' : o0O ,
 'Accept-Encoding' : 'gzip, deflate, sdch' ,
 }
 if data == { } :
  i1Ii = requests . get (
 url ,
 headers = OooO0OoOOOO )
 else :
  OooO0OoOOOO [ "Content-Type" ] = "application/x-www-form-urlencoded"
  i1Ii = requests . post (
 url ,
 headers = OooO0OoOOOO ,
 data = data )
 i1Ii . encoding = "utf-8"
 i11iiII = o00OO00OoO ( i1Ii . text . encode ( "utf8" ) )
 return i11iiII
 if 60 - 60: iI1Ii11111iIi * ii1II11I1ii1I - iI1Ii11111iIi % IiIIi1I1Iiii - Oooo + ii11ii1ii
def o00OO00OoO ( s ) :
 s = '' . join ( s . splitlines ( ) ) . replace ( '\'' , '"' )
 s = s . replace ( '\n' , '' )
 s = s . replace ( '\t' , '' )
 s = re . sub ( '  +' , ' ' , s )
 s = s . replace ( '> <' , '><' )
 return s
 if 70 - 70: iiIiIiIi * oO0ooO * O00OoOoo00 / i11I1IIiiIi
def oO ( s ) :
 OOoO0O00o0 = re . compile ( r'<.*?>' , re . IGNORECASE )
 s = re . sub ( OOoO0O00o0 , '' , s )
 return s . strip ( )
 if 30 - 30: oO0o0ooO0 . i11I1IIiiIi - IiIIi1I1Iiii
def oo00000o0 ( title = "Home" , page = "/" ) :
 try :
  Ii1iIiii1 = "http://www.google-analytics.com/collect"
  OOO = open ( Oo0oOOo ) . read ( )
  Oo0OoO00oOO0o = {
 'v' : '1' ,
 'tid' : 'UA-52209804-5' ,
 'cid' : OOO ,
 't' : 'pageview' ,
 'dp' : "XemPhimMienPhi.net%s" % page ,
 'dt' : "[XemPhimMienPhi.net] - %s" % title . encode ( "utf8" )
 }
  requests . post ( Ii1iIiii1 , data = urllib . urlencode ( Oo0OoO00oOO0o ) )
 except :
  pass
  if 80 - 80: oo + O0Oooo00 - O0Oooo00 % oOo
OoOO0oo0o = xbmc . translatePath ( 'special://userdata' )
if os . path . exists ( OoOO0oo0o ) == False :
 os . mkdir ( OoOO0oo0o )
Oo0oOOo = os . path . join ( OoOO0oo0o , 'cid' )
II11i1I11Ii1i = os . path . join ( OoOO0oo0o , 'search.p' )
if 97 - 97: Oooo % oOo * i11I1IIiiIi + oO0o0ooO0 . O0Oooo00 + O0Oooo00
if os . path . exists ( Oo0oOOo ) == False :
 with open ( Oo0oOOo , "w" ) as Oooo0O0oo00oO :
  Oooo0O0oo00oO . write ( str ( uuid . uuid1 ( ) ) )
  if 14 - 14: ii1II11I1ii1I / iiIiIiIi . ii1II11I1ii1I . O00OoOoo00 % iI1Ii11111iIi * O00OoOoo00
if __name__ == '__main__' :
 oo000 . run ( )
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
