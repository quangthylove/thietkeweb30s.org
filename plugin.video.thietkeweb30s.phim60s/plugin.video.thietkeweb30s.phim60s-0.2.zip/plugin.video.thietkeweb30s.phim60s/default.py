﻿#!/usr/bin/python
# -*- coding: utf-8 -*-
import urllib , requests , re , os , json , uuid , base64 , time
from xbmcswift2 import Plugin , xbmc , xbmcgui , xbmcaddon
from operator import itemgetter
oo000 = Plugin ( )
ii = "plugin://plugin.video.thietkeweb30s.phim60s"
oOOo = "http://thietkeweb30s.org/files/assets/kodi/next.png"
O0 = ""
o0O = "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.75 Safari/537.36"
if 10 - 10: O0O0OO0O0O0
iiiii = '<li class="movie-item"><a[^>]*title="(.+?)" href="(.+?)"><div.+?url=(.+?)\).+?></div>.+?<span class="process">(.+?)</span></span>'
ooo0OO = 'href="(xem-phim.+?)"'
II1 = '<h3 class="server-name"(.+?)</h3><ul class="list-episode">(.+?)</ul>'
O00ooooo00 = '&file=/xml.php\?id=(\d+)'
I1IiiI = '<div class="list_episodes content">.*?<td[^>]*class="name">%s</td><td valign="top" class="ep">(.+?)</td></tr>'
if 27 - 27: iIiiiI1IiI1I1 * IIiIiII11i * IiIIi1I1Iiii - Ooo00oOo00o
I1IiI = 33
if 73 - 73: OOooOOo / ii11ii1ii
@ oo000 . route ( '/' )
def O00ooOO ( ) :
 xbmc . executebuiltin ( "ShowPicture(%s)" % O0 )
 if 47 - 47: oO0ooO % iI1Ii11111iIi + ii1II11I1ii1I + oO0o0ooO0 - iiIIIII1i1iI
@ oo000 . route ( '/search' )
def o0oO0 ( ) :
 oo00 = oo000 . keyboard ( heading = 'Tìm kiếm' )
 if oo00 :
  o00 = 'http://phimno1.net/tim-kiem/' + urllib . quote_plus ( oo00 ) + '/page-%s.html'
  Oo0oO0ooo = oo000 . get_storage ( 'search_history' )
  if 'keywords' in Oo0oO0ooo :
   Oo0oO0ooo [ "keywords" ] = [ oo00 ] + Oo0oO0ooo [ "keywords" ]
  else :
   Oo0oO0ooo [ "keywords" ] = [ oo00 ]
  o0oOoO00o = {
 "title" : "Search: %s" % oo00 ,
 "url" : o00 ,
 "page" : 1
 }
  i1 = '%s/list_media/%s' % (
 ii ,
 urllib . quote_plus ( json . dumps ( o0oOoO00o ) )
 )
  oo000 . redirect ( i1 )
  if 64 - 64: oo % O0Oooo00
@ oo000 . route ( '/searchlist' )
def Ooo0 ( ) :
 oo00000o0 (
 '[Search List]' ,
 '/searchlist/'
 )
 I11i1i11i1I = [ ]
 Iiii = [ {
 "label" : "[B]Search[/B]" ,
 "path" : "%s/search" % ( ii ) ,
 "thumbnail" : "http://thietkeweb30s.org/files/assets/kodi/timkiem.png"
 } ]
 Oo0oO0ooo = oo000 . get_storage ( 'search_history' )
 if 'keywords' in Oo0oO0ooo :
  for OOO0O in Oo0oO0ooo [ 'keywords' ] :
   o00 = 'http://phimno1.net/tim-kiem/' + urllib . quote_plus ( OOO0O ) + '/page-%s.html'
   o0oOoO00o = {
 "title" : "Search: %s" % OOO0O ,
 "url" : o00 ,
 "page" : 1
 }
   oo0ooO0oOOOOo = { }
   oo0ooO0oOOOOo [ "label" ] = OOO0O
   oo0ooO0oOOOOo [ "path" ] = "%s/list_media/%s" % (
 ii ,
 urllib . quote_plus ( json . dumps ( o0oOoO00o ) )
 )
   oo0ooO0oOOOOo [ "thumbnail" ] = "http://thietkeweb30s.org/files/assets/kodi/timkiem.png"
   I11i1i11i1I . append ( oo0ooO0oOOOOo )
 I11i1i11i1I = Iiii + I11i1i11i1I
 return oo000 . finish ( I11i1i11i1I )
 if 71 - 71: O00OoOoo00
@ oo000 . route ( '/list_media/<args_json>' )
def iIiiI1 ( args_json = { } ) :
 I11i1i11i1I = [ ]
 OoOooOOOO = json . loads ( args_json )
 oo00000o0 (
 "[Browse Media of] %s - Page %s" % (
 OoOooOOOO [ "title" ] if "title" in OoOooOOOO else "Unknow Title" ,
 OoOooOOOO [ "page" ] if "page" in OoOooOOOO else "1"
 ) ,
 '/list_media/%s/%s' % (
 OoOooOOOO [ "url" ] % OoOooOOOO [ "page" ] if "page" in OoOooOOOO else "1" ,
 json . dumps ( OoOooOOOO [ "payloads" ] ) if "payloads" in OoOooOOOO else "{}"
 )
 )
 i11iiII = I1iiiiI1iII ( OoOooOOOO [ "url" ] % OoOooOOOO [ "page" ] )
 IiIi11i = re . compile ( iiiii ) . findall ( i11iiII )
 for iIii1I111I11I , o00 , OO00OooO0OO , iiiIi in IiIi11i :
  iiiIi = IiIIIiI1I1 ( iiiIi )
  o00 = "http://phimno1.net/" + o00
  o0oOoO00o = {
 "title" : iIii1I111I11I ,
 "quality_label" : iiiIi ,
 "url" : o00
 }
  oo0ooO0oOOOOo = { }
  oo0ooO0oOOOOo [ "label" ] = "%s (%s)" % (
 o0oOoO00o [ "title" ] ,
 o0oOoO00o [ "quality_label" ]
 )
  oo0ooO0oOOOOo [ "path" ] = "%s/list_mirrors/%s" % (
 ii ,
 urllib . quote_plus ( json . dumps ( o0oOoO00o ) )
 )
  oo0ooO0oOOOOo [ "thumbnail" ] = OO00OooO0OO
  if "HD" in iiiIi :
   oo0ooO0oOOOOo [ "label" ] = "[COLOR yellow]%s[/COLOR]" % oo0ooO0oOOOOo [ "label" ]
  I11i1i11i1I . append ( oo0ooO0oOOOOo )
 I11i1i11i1I = I11i1i11i1I [ : 33 ]
 if len ( I11i1i11i1I ) == I1IiI :
  OoO000 = int ( OoOooOOOO [ "page" ] ) + 1
  OoOooOOOO [ "page" ] = OoO000
  I11i1i11i1I . append ( {
 'label' : 'Next >>' ,
 'path' : '%s/list_media/%s' % (
 ii ,
 urllib . quote_plus ( json . dumps ( OoOooOOOO ) )
 ) ,
 'thumbnail' : oOOo
 } )
 return oo000 . finish ( I11i1i11i1I )
 if 42 - 42: oOoO - iiIiIIi % iI - I11iii / OO0O00
@ oo000 . route ( '/list_mirrors/<args_json>' )
def ii1 ( args_json = { } ) :
 I11i1i11i1I = [ ]
 OoOooOOOO = json . loads ( args_json )
 oo00000o0 (
 "[Browse Mirrors of] %s (%s)" % (
 OoOooOOOO [ "title" ] if "title" in OoOooOOOO else "Unknow Title" ,
 OoOooOOOO [ "quality_label" ] if "quality_label" in OoOooOOOO else ""
 ) ,
 '/list_mirrors/%s/%s' % (
 OoOooOOOO [ "url" ] ,
 json . dumps ( OoOooOOOO [ "payloads" ] ) if "payloads" in OoOooOOOO else "{}"
 )
 )
 i11iiII = I1iiiiI1iII ( OoOooOOOO [ "url" ] )
 IiIi11i = re . compile ( ooo0OO ) . findall ( i11iiII )
 o0oO0o00oo = "http://phimno1.net/" + IiIi11i [ 0 ]
 i11iiII = I1iiiiI1iII ( "http://phimno1.net/" + IiIi11i [ 0 ] )
 IiIi11i = re . compile ( II1 ) . findall ( i11iiII )
 for II1i1Ii11Ii11 , iII11i in IiIi11i :
  o0oOoO00o = {
 "title" : OoOooOOOO [ "title" ] ,
 "quality_label" : OoOooOOOO [ "quality_label" ] ,
 "mirror" : II1i1Ii11Ii11 ,
 "url" : o0oO0o00oo
 }
  oo0ooO0oOOOOo = { }
  oo0ooO0oOOOOo [ "label" ] = "%s %s" % (
 II1i1Ii11Ii11 ,
 OoOooOOOO [ "title" ] . encode ( "utf8" )
 )
  oo0ooO0oOOOOo [ "path" ] = '%s/list_eps/%s' % (
 ii ,
 urllib . quote_plus ( json . dumps ( o0oOoO00o ) )
 )
  I11i1i11i1I . append ( oo0ooO0oOOOOo )
 return oo000 . finish ( I11i1i11i1I )
 if 97 - 97: O00OoOoo00 % O00OoOoo00 + OOooOOo * iiIiIIi
@ oo000 . route ( '/list_eps/<args_json>' )
def o0o00o0 ( args_json = { } ) :
 I11i1i11i1I = [ ]
 OoOooOOOO = json . loads ( args_json )
 oo00000o0 (
 "[Browse Episodes of] %s (%s) [%s]" % (
 OoOooOOOO [ "title" ] if "title" in OoOooOOOO else "Unknow Title" ,
 OoOooOOOO [ "quality_label" ] if "quality_label" in OoOooOOOO else "" ,
 OoOooOOOO [ "mirror" ] if "mirror" in OoOooOOOO else ""
 ) ,
 '/list_mirrors/%s/%s' % (
 OoOooOOOO [ "url" ] ,
 json . dumps ( OoOooOOOO [ "payloads" ] ) if "payloads" in OoOooOOOO else "{}"
 )
 )
 i11iiII = I1iiiiI1iII ( OoOooOOOO [ "url" ] )
 IiIi11i = re . compile ( II1 ) . findall ( i11iiII )
 for II1i1Ii11Ii11 , iII11i in IiIi11i :
  if II1i1Ii11Ii11 == OoOooOOOO [ "mirror" ] . encode ( "utf8" ) :
   for iIi1ii1I1 , o0 in re . compile ( '<a href="(.+?)"[^>]*>(.+?)</a>' ) . findall ( iII11i ) :
    o0oOoO00o = {
 "title" : OoOooOOOO [ "title" ] ,
 "quality_label" : OoOooOOOO [ "quality_label" ] ,
 "mirror" : II1i1Ii11Ii11 ,
 "url" : "http://phimno1.net/" + iIi1ii1I1 ,
 "eps" : o0
 }
    oo0ooO0oOOOOo = { }
    oo0ooO0oOOOOo [ "label" ] = "Part %s - %s" % (
 o0 ,
 OoOooOOOO [ "title" ]
 )
    oo0ooO0oOOOOo [ "path" ] = '%s/play/%s' % (
 ii ,
 urllib . quote_plus ( json . dumps ( o0oOoO00o ) )
 )
    oo0ooO0oOOOOo [ "is_playable" ] = True
    I11i1i11i1I . append ( oo0ooO0oOOOOo )
   break
 return oo000 . finish ( I11i1i11i1I )
 if 9 - 9: oOoO + oo % oOoO + Ooo00oOo00o . O0Oooo00
@ oo000 . route ( '/play/<args_json>' )
def III1i1i ( args_json = { } ) :
 OoOooOOOO = json . loads ( args_json )
 oo00000o0 (
 "[Play] %s (%s) - Part %s [%s]" % (
 OoOooOOOO [ "title" ] if "title" in OoOooOOOO else "Unknow Title" ,
 OoOooOOOO [ "quality_label" ] if "quality_label" in OoOooOOOO else "" ,
 OoOooOOOO [ "eps" ] if "eps" in OoOooOOOO else "" ,
 OoOooOOOO [ "mirror" ] if "mirror" in OoOooOOOO else ""
 ) ,
 '/list_mirrors/%s/%s' % (
 OoOooOOOO [ "url" ] ,
 json . dumps ( OoOooOOOO [ "payloads" ] ) if "payloads" in OoOooOOOO else "{}"
 )
 )
 iiI1 = xbmcgui . DialogProgress ( )
 iiI1 . create ( 'Phim60s' , 'Loading video. Please wait...' )
 oo000 . set_resolved_url ( i11Iiii ( OoOooOOOO [ "url" ] ) , subtitles = "https://dl.dropboxusercontent.com/s/oa2yn7vqgfrmpb1/advertisement.srt" )
 iiI1 . close ( )
 del iiI1
 if 23 - 23: oO0o0ooO0 . OOooOOo
def i11Iiii ( url ) :
 i11iiII = I1iiiiI1iII ( url )
 Oo0O0OOOoo = ""
 IiIi11i = re . compile ( 'link:"(.+?)"' ) . findall ( i11iiII )
 oOoOooOo0o0 , OOOO = [ "player3" , "gkphp/drive" ]
 OOO00 = re . compile ( 'src="(player\d*)/(.+?)/gkpluginsphp.js' ) . findall ( i11iiII )
 if len ( OOO00 ) > 0 :
  oOoOooOo0o0 , OOOO = OOO00 [ 0 ]
 iiiiiIIii = time . time ( )
 O000OO0 = "http://%s.phimno1.net/%s/gkpluginsphp.php?%s" % ( oOoOooOo0o0 , OOOO , iiiiiIIii )
 if 43 - 43: I11iii - iIiiiI1IiI1I1 % ii11ii1ii . O00OoOoo00
 if len ( IiIi11i ) > 0 :
  o00OooOooo = IiIi11i [ 0 ]
  O000oo0O = {
 "link" : o00OooOooo
 }
  if "/drive/" in O000OO0 :
   O000OO0 = O000OO0 . replace ( "/drive/" , "/photos/" )
   OOOOi11i1 = json . loads ( I1iiiiI1iII ( O000OO0 , O000oo0O ) ) [ "link" ]
   return IIIii1II1II ( OOOOi11i1 , oo000 . get_setting ( 'HQ' , bool ) )
  else :
   try :
    i1I1iI = json . loads ( I1iiiiI1iII ( O000OO0 , O000oo0O ) )
   except :
    return ""
   if "link" not in i1I1iI [ "link" ] [ 0 ] :
    Oo0O0OOOoo = i1I1iI [ "link" ]
   else :
    if oo000 . get_setting ( 'HQ' , bool ) and ( len ( i1I1iI [ "link" ] ) > 1 ) :
     Oo0O0OOOoo = i1I1iI [ "link" ] [ - 1 ] [ "link" ]
    else :
     Oo0O0OOOoo = i1I1iI [ "link" ] [ 0 ] [ "link" ]
 else :
  IiIi11i = re . compile ( '(youtu\.be\/|youtube-nocookie\.com\/|youtube\.com\/(watch\?(.*&)?v=|(embed|v|user)\/))([^\?&"\'>]+)' ) . findall ( i11iiII )
  oo0OooOOo0 = IiIi11i [ 0 ] [ len ( IiIi11i [ 0 ] ) - 1 ] . replace ( 'v/' , '' )
  Oo0O0OOOoo = 'plugin://plugin.video.youtube/?action=play_video&videoid=%s' % oo0OooOOo0
 return Oo0O0OOOoo
 if 92 - 92: iiIiIIi . O00OoOoo00 + oO0o0ooO0
def IIIii1II1II ( url , hq ) :
 IiII1I11i1I1I = {
 'User-Agent' : o0O ,
 'Accept-Encoding' : 'gzip, deflate, sdch' ,
 }
 if 83 - 83: iiIIIII1i1iI / OO0O00
 iIIIIii1 = requests . get ( url , headers = IiII1I11i1I1I )
 oo000OO00Oo = re . compile ( '(\["fmt_stream_map".+?\])' ) . findall ( iIIIIii1 . text ) [ 0 ]
 O0OOO0OOoO0O = [ "38" , "37" , "46" , "22" , "45" , "18" , "43" ]
 if not hq : O0OOO0OOoO0O . reverse ( )
 O00Oo000ooO0 = json . loads ( oo000OO00Oo ) [ 1 ] . split ( "," )
 for OoO0O00 in O0OOO0OOoO0O :
  for IIiII in O00Oo000ooO0 :
   if IIiII . startswith ( OoO0O00 + "|" ) :
    url = IIiII . split ( "|" ) [ 1 ]
    o0ooOooo000oOO = "|User-Agent=%s&Cookie=%s" % ( urllib . quote ( o0O ) , urllib . quote ( iIIIIii1 . headers [ 'set-cookie' ] ) )
    return url + o0ooOooo000oOO
    if 59 - 59: OOooOOo + IiIIi1I1Iiii * ii1II11I1ii1I + Ooo00oOo00o
    if 58 - 58: OOooOOo * O0Oooo00 * iiIIIII1i1iI / O0Oooo00
def I1iiiiI1iII ( url , data = { } ) :
 IiII1I11i1I1I = {
 'User-Agent' : o0O ,
 'Accept-Encoding' : 'gzip, deflate, sdch' ,
 }
 if data == { } :
  iIIIIii1 = requests . get (
 url ,
 headers = IiII1I11i1I1I )
 else :
  IiII1I11i1I1I [ "Content-Type" ] = "application/x-www-form-urlencoded"
  iIIIIii1 = requests . post (
 url ,
 headers = IiII1I11i1I1I ,
 data = data )
 iIIIIii1 . encoding = "utf-8"
 i11iiII = oO0o0OOOO ( iIIIIii1 . text . encode ( "utf8" ) )
 return i11iiII
 if 68 - 68: iiIiIIi - I11iii - ii11ii1ii - iiIIIII1i1iI + O00OoOoo00
def oO0o0OOOO ( s ) :
 s = '' . join ( s . splitlines ( ) ) . replace ( '\'' , '"' )
 s = s . replace ( '\n' , '' )
 s = s . replace ( '\t' , '' )
 s = re . sub ( '  +' , ' ' , s )
 s = s . replace ( '> <' , '><' )
 return s
 if 10 - 10: IiIIi1I1Iiii % IIiIiII11i
def IiIIIiI1I1 ( s ) :
 OoO0O00 = re . compile ( r'<.*?>' , re . IGNORECASE )
 s = re . sub ( OoO0O00 , '' , s )
 return s . strip ( )
 if 54 - 54: I11iii - OOooOOo % ii1II11I1ii1I % O00OoOoo00 % IIiIiII11i + OO0O00
def oo00000o0 ( title = "Home" , page = "/" ) :
 try :
  I1111I1iII11 = "http://www.google-analytics.com/collect"
  Oooo0O0oo00oO = open ( IIi1i ) . read ( )
  I1I1iIiII1 = {
 'v' : '1' ,
 'tid' : 'UA-52209804-5' ,
 'cid' : Oooo0O0oo00oO ,
 't' : 'pageview' ,
 'dp' : "Phim60s%s" % page ,
 'dt' : "[Phim60s] - %s" % title . encode ( "utf8" )
 }
  requests . post ( I1111I1iII11 , data = urllib . urlencode ( I1I1iIiII1 ) )
 except :
  pass
  if 4 - 4: OO0O00 + iIiiiI1IiI1I1 * O0Oooo00
OOoo0O = xbmc . translatePath ( 'special://userdata' )
if os . path . exists ( OOoo0O ) == False :
 os . mkdir ( OOoo0O )
IIi1i = os . path . join ( OOoo0O , 'cid' )
Oo0ooOo0o = os . path . join ( OOoo0O , 'search.p' )
if 22 - 22: IIiIiII11i / O0O0OO0O0O0 * IIiIiII11i * OOooOOo . O0Oooo00 / O0O0OO0O0O0
if os . path . exists ( IIi1i ) == False :
 with open ( IIi1i , "w" ) as IiiiOO0OoO0o00 :
  IiiiOO0OoO0o00 . write ( str ( uuid . uuid1 ( ) ) )
  if 53 - 53: iIiiiI1IiI1I1 * iI1Ii11111iIi + O0Oooo00
if __name__ == '__main__' :
 oo000 . run ( )
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
