#!/usr/bin/python
# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import urllib , requests , re , os , json , uuid , kodi4vn , cfscrape
import concurrent . futures
from xbmcswift2 import Plugin , xbmc , xbmcgui , xbmcaddon
from operator import itemgetter
from cookielib import LWPCookieJar
requests . packages . urllib3 . disable_warnings ( )
oo000 = cfscrape . create_scraper ( )
oo000 . cookies = LWPCookieJar ( )
if 9 - 9: Ii . o0o00Oo0O - iI11I1II1I1I
oooo = '41f5812679f97c83e27c539ac68c0dc6'
iIIii1IIi = Plugin ( )
o0OO00 = xbmc . translatePath ( 'special://userdata' )
oo = os . path . join ( o0OO00 , 'search.p' )
i1iII1IiiIiI1 = "plugin://plugin.video.kodi4vn.tvhay"
iIiiiI1IiI1I1 = i1iII1IiiIiI1 . split ( "/" ) [ - 1 ]
o0OoOoOO00 = "https://docs.google.com/drawings/d/12OjbFr3Z5TCi1WREwTWECxNNwx0Kx-FTrCLOigrpqG4/pub?w=256&h=256"
I11i = "Mozilla/5.0 (iPhone; CPU iPhone OS 8_0_2 like Mac OS X) AppleWebKit/600.1.4 (KHTML, like Gecko) Version/8.0 Mobile/12A366 Safari/600.1.4"
O0O = '<img class="lazy" src=".+?url=(.+?)"[^>]*></a>.+?<a href="(.+?)" title="Xem Phim (.+?)">.+?<div class="status">(.+?)</div>.+?<div class="year">(.+?)</div>'
if 78 - 78: i11ii11iIi11i . oOoO0oo0OOOo + IiiI / Iii1ii1II11i
iI111iI = 40
if 34 - 34: iii1I1I / O00oOoOoO0o0O . O0oo0OO0 + Oo0ooO0oo0oO . I1i1iI1i - II
Oo = {
 'Referer' : 'http://tvhay.org/' ,
 'Content-Type' : 'application/x-www-form-urlencoded'
 }
if 27 - 27: o00 * O0 - Ooo / IiIiI11iIi - O0OOo . II1Iiii1111i
@ iIIii1IIi . route ( '/' )
def i1IIi11111i ( ) :
 xbmc . executebuiltin ( "ShowPicture(%s)" % addon_popup )
 if 74 - 74: Oo0o00o0Oo0 * oOoO0oo0OOOo
@ iIIii1IIi . route ( '/search' )
def i11iI ( ) :
 I1i1i1ii = iIIii1IIi . keyboard ( heading = 'Tìm kiếm' )
 if I1i1i1ii :
  IIIII = 'http://tvhay.org/search/' + urllib . quote_plus ( I1i1i1ii ) + '/page/%s'
  with open ( oo , "a" ) as I1 :
   I1 . write ( I1i1i1ii + "\n" )
  O0OoOoo00o = {
 "title" : "Search: %s" % I1i1i1ii ,
 "url" : IIIII ,
 "page" : 1
 }
  iiiI11 = '%s/list_media/%s' % (
 i1iII1IiiIiI1 ,
 urllib . quote_plus ( json . dumps ( O0OoOoo00o ) )
 )
  iIIii1IIi . redirect ( iiiI11 )
  if 91 - 91: Oo0ooO0oo0oO / IiiI . I1i1iI1i + o00
@ iIIii1IIi . route ( '/searchlist' )
def iI11 ( ) :
 iII111ii (
 '[Search List]' ,
 '/searchlist/'
 )
 i1iIIi1 = [ ]
 ii11iIi1I = [ {
 "label" : "[B]Search[/B]" ,
 "path" : "%s/search" % ( i1iII1IiiIiI1 ) ,
 "thumbnail" : "https://docs.google.com/drawings/d/1uP5xm3I5KRZsnoliqJDkYJXYz1MznecVqWg3e-Gue48/pub?w=256&h=256"
 } ]
 iI111I11I1I1 = [ ]
 if os . path . exists ( oo ) :
  with open ( oo , "r" ) as I1 :
   iI111I11I1I1 = I1 . read ( ) . strip ( ) . split ( "\n" )
  for OOooO0OOoo in reversed ( iI111I11I1I1 ) :
   IIIII = 'http://tvhay.org/search/' + urllib . quote_plus ( OOooO0OOoo ) + '/page/%s'
   O0OoOoo00o = {
 "title" : "Search: %s" % OOooO0OOoo ,
 "url" : IIIII ,
 "page" : 1
 }
   iIii1 = { }
   iIii1 [ "label" ] = OOooO0OOoo
   iIii1 [ "path" ] = "%s/list_media/%s" % (
 i1iII1IiiIiI1 ,
 urllib . quote_plus ( json . dumps ( O0OoOoo00o ) )
 )
   iIii1 [ "thumbnail" ] = "https://docs.google.com/drawings/d/1uP5xm3I5KRZsnoliqJDkYJXYz1MznecVqWg3e-Gue48/pub?w=256&h=256"
   i1iIIi1 . append ( iIii1 )
 i1iIIi1 = ii11iIi1I + i1iIIi1
 return iIIii1IIi . finish ( i1iIIi1 )
 if 71 - 71: O00oOoOoO0o0O
@ iIIii1IIi . route ( '/list_media/<args_json>' )
def oO0O ( args_json = { } ) :
 i1iIIi1 = [ ]
 OOoO000O0OO = json . loads ( args_json )
 iII111ii (
 "[Browse Media of] %s - Page %s" % (
 OOoO000O0OO [ "title" ] if "title" in OOoO000O0OO else "Unknow Title" ,
 OOoO000O0OO [ "page" ] if "page" in OOoO000O0OO else "1"
 ) ,
 '/list_media/%s/%s' % (
 OOoO000O0OO [ "url" ] % OOoO000O0OO [ "page" ] if "page" in OOoO000O0OO else "1" ,
 json . dumps ( OOoO000O0OO [ "payloads" ] ) if "payloads" in OOoO000O0OO else "{}"
 )
 )
 iiI1IiI = kodi4vn . Request ( OOoO000O0OO [ "url" ] % OOoO000O0OO [ "page" ] , session = oo000 )
 IIooOoOoo0O = re . compile ( O0O , re . S ) . findall ( iiI1IiI . text )
 for OooO0 , IIIII , II11iiii1Ii , OO0o , OooO0o0Oo in IIooOoOoo0O :
  OO0o = OO0o . strip ( )
  OooO0o0Oo = OooO0o0Oo . strip ( )
  IIIII = IIIII . replace ( "tvhay.org/" , "tvhay.org/xem-phim-" ) . strip ( ) [ : - 1 ] + "-%20"
  II11iiii1Ii = "%s (%s %s)" % ( II11iiii1Ii , OooO0o0Oo , OO0o )
  O0OoOoo00o = {
 "title" : II11iiii1Ii ,
 "quality_label" : OO0o ,
 "url" : IIIII
 }
  iIii1 = { }
  iIii1 [ "label" ] = II11iiii1Ii
  iIii1 [ "path" ] = "%s/list_mirrors/%s" % (
 i1iII1IiiIiI1 ,
 urllib . quote_plus ( json . dumps ( O0OoOoo00o ) )
 )
  iIii1 [ "thumbnail" ] = OooO0
  if "HD" in OO0o :
   iIii1 [ "label" ] = "[COLOR yellow]%s[/COLOR]" % iIii1 [ "label" ]
  i1iIIi1 . append ( iIii1 )
 if len ( i1iIIi1 ) == iI111iI :
  Oo00OOOOO = int ( OOoO000O0OO [ "page" ] ) + 1
  OOoO000O0OO [ "page" ] = Oo00OOOOO
  i1iIIi1 . append ( {
 'label' : 'Next >>' ,
 'path' : '%s/list_media/%s' % (
 i1iII1IiiIiI1 ,
 urllib . quote_plus ( json . dumps ( OOoO000O0OO ) )
 ) ,
 'thumbnail' : o0OoOoOO00
 } )
 return iIIii1IIi . finish ( i1iIIi1 )
 if 85 - 85: Oo0o00o0Oo0 . IiIiI11iIi - O00oOoOoO0o0O % Oo0o00o0Oo0 % IiiI
@ iIIii1IIi . route ( '/list_mirrors/<args_json>' )
def OO0o00o ( args_json = { } ) :
 i1iIIi1 = [ ]
 OOoO000O0OO = json . loads ( args_json )
 iII111ii (
 "[Browse Mirrors of] %s (%s)" % (
 OOoO000O0OO [ "title" ] if "title" in OOoO000O0OO else "Unknow Title" ,
 OOoO000O0OO [ "quality_label" ] if "quality_label" in OOoO000O0OO else ""
 ) ,
 '/list_mirrors/%s/%s' % (
 OOoO000O0OO [ "url" ] ,
 json . dumps ( OOoO000O0OO [ "payloads" ] ) if "payloads" in OOoO000O0OO else "{}"
 )
 )
 iiI1IiI = kodi4vn . Request ( OOoO000O0OO [ "url" ] , session = oo000 )
 IIooOoOoo0O = re . compile ( '<div class="label">(.+?)</div>' , re . S ) . findall ( iiI1IiI . text )
 for oOOo0oo in IIooOoOoo0O :
  O0OoOoo00o = {
 "title" : OOoO000O0OO [ "title" ] ,
 "mirror" : oOOo0oo ,
 "quality_label" : OOoO000O0OO [ "quality_label" ] ,
 "url" : OOoO000O0OO [ "url" ]
 }
  iIii1 = { }
  iIii1 [ "label" ] = "Server %s" % ( oOOo0oo . strip ( ) )
  iIii1 [ "path" ] = "%s/list_eps/%s" % (
 i1iII1IiiIiI1 ,
 urllib . quote_plus ( json . dumps ( O0OoOoo00o ) )
 )
  i1iIIi1 . append ( iIii1 )
 return iIIii1IIi . finish ( i1iIIi1 )
 if 80 - 80: O0 * Ii / II1Iiii1111i
@ iIIii1IIi . route ( '/list_eps/<args_json>' )
def I11II1i ( args_json = { } ) :
 i1iIIi1 = [ ]
 OOoO000O0OO = json . loads ( args_json )
 iII111ii (
 "[Browse Episodes of] %s (%s) [%s]" % (
 OOoO000O0OO [ "title" ] if "title" in OOoO000O0OO else "Unknow Title" ,
 OOoO000O0OO [ "quality_label" ] if "quality_label" in OOoO000O0OO else "" ,
 OOoO000O0OO [ "mirror" ] if "mirror" in OOoO000O0OO else ""
 ) ,
 '/list_mirrors/%s/%s' % (
 OOoO000O0OO [ "url" ] ,
 json . dumps ( OOoO000O0OO [ "payloads" ] ) if "payloads" in OOoO000O0OO else "{}"
 )
 )
 iiI1IiI = kodi4vn . Request ( OOoO000O0OO [ "url" ] , session = oo000 )
 IIIIIooooooO0oo = re . search ( '<div class="label">%s</div>(.+?)</ul>' % OOoO000O0OO [ "mirror" ] , iiI1IiI . text ) . group ( 1 )
 for IIiiiiiiIi1I1 , I1IIIii in re . compile ( '<a[^>]*href="(.+?)">(.+?)</a>' ) . findall ( IIIIIooooooO0oo ) :
  O0OoOoo00o = {
 "title" : OOoO000O0OO [ "title" ] ,
 "quality_label" : OOoO000O0OO [ "quality_label" ] ,
 "mirror" : OOoO000O0OO [ "mirror" ] ,
 "url" : IIiiiiiiIi1I1 ,
 "eps" : I1IIIii
 }
  iIii1 = { }
  iIii1 [ "label" ] = "Part %s - %s [%s]" % (
 I1IIIii . decode ( "utf8" ) ,
 OOoO000O0OO [ "title" ] ,
 OOoO000O0OO [ "mirror" ] . replace ( ":" , "" )
 )
  iIii1 [ "path" ] = '%s/play/%s' % (
 i1iII1IiiIiI1 ,
 urllib . quote_plus ( json . dumps ( O0OoOoo00o ) )
 )
  iIii1 [ "is_playable" ] = True
  i1iIIi1 . append ( iIii1 )
 return iIIii1IIi . finish ( i1iIIi1 )
 if 95 - 95: O00oOoOoO0o0O % II . o0o00Oo0O
 if 15 - 15: Oo0o00o0Oo0 / Ooo . Ooo - oOoO0oo0OOOo
def o00oOO0 ( ) :
 iiI1IiI = kodi4vn . Request ( "http://tvhay.org/playergk/hza.php" , session = oo000 ) . text
 oOoo , vars = re . compile ( 'var ([^\s|=]*)\s?=(\[.+?\])' , re . S ) . findall ( iiI1IiI ) [ 0 ]
 iIii11I = eval ( vars )
 OOO0OOO00oo = iiI1IiI
 for Iii111II , iiii11I in enumerate ( iIii11I ) :
  OOO0OOO00oo = OOO0OOO00oo . replace ( '%s[%s]' % ( oOoo , Iii111II ) , '"%s"' % iiii11I . decode ( 'unicode-escape' ) )
 OOO0OOO00oo = OOO0OOO00oo . replace ( vars , '' )
 if 96 - 96: IiiI % Ooo . o00 + i11ii11iIi11i * II - O0oo0OO0
 i11i1 = '%s%s' % ( oooo , sorted ( iIii11I , key = len )
 [ - 2 ] . decode ( 'unicode-escape' ) )
 IIIii1II1II = sorted ( iIii11I , key = len ) [ - 1 ] . decode ( 'unicode-escape' )
 i1I1iI = re . search ( 'var a=(-?\d+)' , IIIii1II1II ) . group ( 1 )
 oo0OooOOo0 = re . search ( 'var b=(-?\d+)' , IIIii1II1II ) . group ( 1 )
 o0O = re . search ( 'return -?(\d+)' , IIIii1II1II ) . group ( 1 )
 IIIii1II1II = '%s.%s' % ( o0O , int ( i1I1iI ) + int ( oo0OooOOo0 ) )
 O00oO = "aHR0cHM6Ly9lY2hpcHN0b3JlLmNvbS9wYXJzZXIvZGVjcnlwdC90dmhheT90a2s9JXMmZnA9JXM=" . decode ( "base64" )
 I11i1I1I = kodi4vn . Request ( O00oO % ( IIIii1II1II , oooo ) ) . text . encode ( "utf8" )
 return i11i1 , IIIii1II1II , I11i1I1I
 if 83 - 83: I1i1iI1i / Oo0o00o0Oo0
@ iIIii1IIi . route ( '/play/<args_json>' )
def iIIIIii1 ( args_json = { } ) :
 OOoO000O0OO = json . loads ( args_json )
 iII111ii (
 "[Play] %s (%s) - Part %s [%s]" % (
 OOoO000O0OO [ "title" ] if "title" in OOoO000O0OO else "Unknow Title" ,
 OOoO000O0OO [ "quality_label" ] if "quality_label" in OOoO000O0OO else "" ,
 OOoO000O0OO [ "eps" ] if "eps" in OOoO000O0OO else "" ,
 OOoO000O0OO [ "mirror" ] if "mirror" in OOoO000O0OO else ""
 ) ,
 '/play/%s/%s' % (
 OOoO000O0OO [ "url" ] ,
 json . dumps ( OOoO000O0OO [ "payloads" ] ) if "payloads" in OOoO000O0OO else "{}"
 )
 )
 iIIii1IIi . set_resolved_url ( oo000OO00Oo ( OOoO000O0OO [ "url" ] ) )
 if 51 - 51: O0OOo * Oo0ooO0oo0oO + O0 + O00oOoOoO0o0O
def oo000OO00Oo ( url ) :
 iiI1IiI = kodi4vn . Request ( url , session = oo000 ) . text . encode ( "utf8" )
 if 66 - 66: O0oo0OO0
 try :
  url = re . search ( "link=(https*\://www.ok.ru/videoembed/\d+)" , iiI1IiI ) . group ( 1 )
  return kodi4vn . resolve ( url )
 except : pass
 iiI1IiI = kodi4vn . UnWise ( iiI1IiI )
 oO000Oo000 = re . search ( 'link:"([^"]*)"' , iiI1IiI ) . group ( 1 )
 i11i1 , IIIii1II1II , I11i1I1I = o00oOO0 ( )
 i111IiI1I = {
 'link' : oO000Oo000 ,
 'kt' : i11i1 ,
 'tkk' : IIIii1II1II ,
 'tk' : I11i1I1I ,
 }
 if 70 - 70: Ooo . iii1I1I / Oo0ooO0oo0oO . Ooo - o0o00Oo0O / O0OOo
 iiI1IiI = kodi4vn . Request ( "http://tvhay.org/playergk/plugins/gkpluginsphp.php" , data = i111IiI1I , additional_headers = Oo , session = oo000 ) . json ( )
 try :
  ooOooo000oOO = kodi4vn . sort_gk_links ( iiI1IiI [ "link" ] ) [ 0 ] [ "link" ]
  Oo0oOOo = "|Referer:%s&User-Agent:%s" % ( urllib . quote_plus ( url ) , urllib . quote_plus ( chrome_user_agent ) )
  ooOooo000oOO += Oo0oOOo
  return ooOooo000oOO
 except :
  ooOooo000oOO = iiI1IiI [ "link" ]
  return ooOooo000oOO
 return None
 if 58 - 58: IiiI * o00 * I1i1iI1i / o00
o0OO00 = xbmc . translatePath ( 'special://userdata' )
oo = os . path . join ( o0OO00 , 'search.p' )
if 75 - 75: II
global I1III
I1III = os . path . join ( o0OO00 , 'cid' )
if not os . path . exists ( I1III ) :
 with open ( I1III , "w" ) as I1 :
  I1 . write ( str ( uuid . uuid1 ( ) ) )
  if 63 - 63: o00 % II * II * O00oOoOoO0o0O / I1i1iI1i
def iII111ii ( title = "Home" , page = "/" ) :
 o0ooO = "http://www.google-analytics.com/collect"
 O0o0O00Oo0o0 = ""
 try :
  with open ( I1III , "r" ) as I1 :
   O0o0O00Oo0o0 = I1 . read ( )
  i111IiI1I = {
 'v' : '1' ,
 'tid' : 'UA-52209804-5' ,
 'cid' : O0o0O00Oo0o0 ,
 't' : 'pageview' ,
 'dp' : "TVHay%s" % page ,
 'dt' : ( "[TVHay] - %s" % title . encode ( "utf8" , 'ignore' ) . decode ( "utf8" ) ) . encode ( "utf8" )
 }
  requests . post ( o0ooO , data = urllib . urlencode ( i111IiI1I ) )
 except :
  pass
  if 87 - 87: Oo0o00o0Oo0 * iii1I1I % Ii % O0oo0OO0 - o00
if __name__ == '__main__' :
 iIIii1IIi . run ( )
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
